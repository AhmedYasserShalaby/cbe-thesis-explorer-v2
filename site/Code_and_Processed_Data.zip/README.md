# Research code and processed data

Current scope: only the first actual trading session after each MPC meeting.
The original study and all current results are retrospective; publication
clocks and text vintages remain unverified, and historical outcomes were
inspected. Full-history and modern-live samples overlap.

## Reproduce the saved-result checks

Extract this ZIP to a new folder. From that folder run:

```sh
python3 START_HERE.py
```

The entry point uses Python's standard library, reads the saved data and
predictions, prints a JSON check receipt, and writes no study files. It checks
all 40 main metric groups, 16 paired point differences, 310 expanding means,
930 target/input return ratios and all 3,100 retained forecasts against the
corrected parent predictions. It does not import a model, train an encoder,
replay bootstrap intervals or install dependencies. The exact member hashes
are recorded in ARCHIVE_MANIFEST.json. The extracted entry point was executed
for this handover; see SAVED_RESULTS_CHECK.json.

## Files to read

- 04_data/processed/first_session_only_2026-10-28/: current event panel,
  chronological splits, dictionary, source and exclusion records.
- 06_results/first_session_only_2026-10-28/: current saved forecasts, metrics,
  paired estimates, uncertainty intervals and the selection manifest.
- 03_methodology/first_session_only_2026-10-28/: current scope record.
- 05_analysis/model_comparison_corrected_2026-10-27/: full executable model,
  text-feature, metric and chronological-evaluation source, with runtime gate.
- 05_analysis/word2vec_backend_fix_2026-10-27/: exact patch, dependency pins,
  source tarball, isolated rebuild recipe and mathematical regression source.
- 03_methodology/model_comparison_corrected_2026-10-27/: frozen settings,
  exact inputs and training/test event identities of the accepted parent run.

The historical frozen parent records also contain superseded horizons.
Those records explain provenance; current thesis outcomes are first-session
only. They are not additional current forecast targets.

## Full model reproduction and software bounds

The full training implementation is included for inspection. The accepted
local runtime is .venv_word2vec_corrected_2026-10-27/bin/python in Ahmed's
original workspace; the older .venv_thesis_data backend is defective for this
Word2Vec path. BUILD_AND_TEST.md documents the patch and rebuild. Native
extension bytes and gate receipts are platform/toolchain-specific. This ZIP
does not include the installed environment, all trained binary artifacts,
all upstream raw-file paths or an independently certified fresh-machine
training environment. It is a source/processed-evidence handover with an
executed portable saved-result check, not a standalone certified retraining
distribution. The complete accepted runtime, raw inputs, encoders and model
artifacts remain preserved in the local thesis workspace.

Do not replay historical preparation scripts or run freeze/finalize against
existing destinations. A future full training reproduction requires new
output/artifact directories and independently checked runtime bindings.
Do not change a frozen protocol or substitute a new backend to force a gate
to pass. No model fitting is needed to review the current results.

## Original sources and private review

The companion Raw_Data.zip contains 176 preserved CBE originals and three
Refinitiv price exports. The review workbook is Thesis_Data.xlsx. The review
HTML explains source excerpts and settings; the complete executable model
source is here. Keep this package for private academic review under the
applicable source/data terms. A local archive is not evidence of permission
to publish vendor data, an off-device backup, submission or academic approval.
