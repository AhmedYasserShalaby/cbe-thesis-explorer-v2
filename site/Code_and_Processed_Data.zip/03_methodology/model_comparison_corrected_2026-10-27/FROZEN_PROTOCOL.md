# Corrected-backend frozen forecast protocol

Frozen at 2026-10-26T22:37:26.593940+00:00 before empirical fitting. Original frozen protocol SHA-256: `9684e4d8daf076c6f71700fde57206fa7a862ed301220776963e6dac4046ca0e`. Dataset manifest SHA-256: `0a92956bf44404b11f3ab7502e1af690a0e7e84456d6f2eca52dbd9c006dee73`.

The original specification, eligible event IDs and every grouped training ID and cutoff are reproduced exactly in the adjacent machine-readable frozen protocol. All original input, code and output artifact hashes were verified before this freeze. No earlier encoder, PCA, scaler or model is reused.

Derived from the frozen plan: 155 origins, 7440 learned fits and 9300 forecasts. Backend readiness and independent acceptance are bound by exact bytes and runtime fingerprints in the JSON.

All forecasts use the same pre-first-session information set; labels in the training history must end before the origin statement date. Existing historical tests were inspected. Publication clocks and historical text vintages remain unverified; the comparison is retrospective. Legacy and live index definitions differ, and modern 2019 backcasts are not invented. No hyperparameter search, new features or sources are authorized.
