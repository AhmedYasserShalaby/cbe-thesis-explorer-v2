# First-session scope

On 28 October Ahmed requested only the first actual trading session after each
meeting. This replaces the previous reporting scope. The same 155-event cohort
and every retained training ID were verified under first-session eligibility
and label availability. The saved corrected first-session predictions, metrics
and descriptive intervals were selected; no new model fitting occurred.
There are 2,480 retained learned forecasts, 620 references, 40 metric groups and
16 paired comparisons. Results had been inspected before this scope decision.
The historical frozen protocol and all earlier raw/data/result versions remain
unchanged. This selection is not represented as a newly preregistered run.
