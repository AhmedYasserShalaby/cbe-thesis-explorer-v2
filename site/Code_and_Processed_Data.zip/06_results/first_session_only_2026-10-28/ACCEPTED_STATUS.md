# First-session corrected results

Current scope is only the first actual trading session after each meeting.
The accepted corrected first-session forecasts are selected without refitting.
Every retained numerical forecast, actual return, metric and descriptive
interval is unchanged. The same 155-event eligible cohort and all training IDs
were verified under the first-session rule.

There are 3,100 forecasts, 2,480 learned forecasts, 40 main metric groups and
16 paired comparisons. Text reduces MAE in 3/16 pairs; 15/16 descriptive
intervals include zero. Zero beats all 32 learned variants on MAE and RMSE.
The scope was narrowed after inspection of historical outcomes. This remains
a retrospective exploratory comparison, without causal or profit claims.

Original frozen data/protocol/run and earlier review packages are preserved.
Current verification is in 04_data/verification/first_session_only_2026-10-28/.
