# Refinitiv-only CBE event dataset — version 1

Version: `refinitiv_only_2026-10-26_v1`. Static inputs are validated for the **explicitly retrospective** comparison. This is not verified real-time forecast data. The immutable computational handover is `dataset_manifest.json` (SHA-256 `0a92956bf44404b11f3ab7502e1af690a0e7e84456d6f2eca52dbd9c006dee73`). No model is fitted by the data pipeline.

## Contents and independent observations

| File | Grain and coverage |
|---|---|
| `daily_prices.csv` | 21,051 instrument/date rows on 7,017 observed-union dates, including explicit missing cells and ineligible raw bars. All 16,594 observed close values come from three matching Refinitiv exports. |
| `original_text_inventory.csv` | All 176 retained documents, full working transcriptions and original-file links/hashes: 174 policy candidates, of which 173 are official English and one official Arabic; two administrative records. |
| `event_sector_modeling.csv` | All 352 document/sector rows, including excluded records; three targets, exact price-input dates/cells, text, action, source/timing status and exclusion reasons. |
| `common_event_cohort.csv` | 155 independent events: 99 legacy and 56 modern-live. Two sectors produce 310 rows; three horizons produce 930 sector/horizon observations, **not 930 independent announcements**. |
| `target_coverage.csv` | Each sector/horizon has 159 raw ratios in the full inventory, 157 original-English policy ratios, and 155 modeling-eligible events after the prolonged/shared reopening-window exclusions. Each sector/horizon has 18 missing/excluded events out of 173 English policy candidates. |
| `event_exclusions.csv` | All 126 excluded document/sector/horizon records, with reasons. No deletion from the full inventory. |
| `calendar_register.csv` | Complete civil-date register covering the exported span, distinguishing weekends, observed session proxies, documented suspension, provisional bar, and unverified weekday non-observations. |
| `timing_register_preserved.csv` | Entire earlier 176-record timing register; matching-copy clocks retain their source meaning. |
| `policy_rate_corrections_applied.csv` | Seven earlier audited missing after-rate corrections, applied in the new `deposit_after_proposed_pct` column; inherited fields preserved. |
| `data_dictionary.csv` / `DATA_DICTIONARY.md` | Every static table column, its unit, meaning and missing-value convention. |
| `source_manifest.json` | 374 pinned source files, raw RIC profiles, original PDFs/extractions/review files and retained audit evidence. |

## Source authority and units

Prices use only `egbank.xlsx` (.EGBANK), `egreal.xlsx` (.EGREAL) and `egx30.xlsx` (.EGX30), preserved under `04_data/raw/refinitiv_2026-10-19/exchange_exports/`. Their exact header field is `TRDPRC_1`, aggregation `Close`. Sector exports have 4,789 observations each from 3 January 2007; EGX30 has 7,016 from 1 January 1998. Each ends 19 October 2026. The duplicate Cairo-named Banks file is one byte-identical source, not a second independent observation or timezone verification.

Levels are **index points with EGP currency basis**, supported by the retained quote identity and index-methodology evidence. The XLSX itself provides Date, RIC/field and Close; it does not provide a currency, historical-constituent, adjustment, total-return, release-time or finality header. ISO-midnight date storage in XLSX XML is a date representation, not a news/market publication clock. Returns are unadjusted ratios of the selected Close levels. No total-return series or separately certified vendor adjustment convention is claimed.

Returns use numeric **percentage points**: `1.0` is a 1% price change. Policy action uses signed **basis points**: +100 is a one-percentage-point hike, −100 a cut and zero a hold. It is an observed decision, not an identified surprise. Eighteen before/after arithmetic reconciliations reuse the earlier source/implied distinctions; they do not establish universal independent before-rate verification.

The text source is the retained **original CBE statement** and its existing working transcription, with earlier reviewed OCR derivatives preserved. Text is not reacquired, recleaned or replaced by news summaries. Full original identity/date/hash linkage covers all 176 records. Identity checks and retained review receipts do not certify every body, OCR passage, translation or historical version.

## Sessions, cutoff and returns

The common session grid is the union of observed matching-RIC dates, accepting Sunday–Thursday and excluding the documented 8 July 2025 suspension, the pre-base-date EGX30 observation on 1 January 1998, and bars after the completed-close cutoff of **18 October 2026**. The 19 October bars remain in raw/daily tables but are excluded because finality was not established. No missing close is imputed, carried or borrowed. The two missing sector cells on 11 October 2020 stay missing; the missing EGX30 cell on the suspended 8 July 2025 stays missing. Instrument absence never shifts the common session dates.

This observed-session grid handles recorded holiday/closure gaps without assuming Monday–Friday or blindly choosing Sunday/Monday. It is **not a fully certified historical exchange calendar**. Weekdays with no observation in any export remain explicitly unverified holiday/missing-date cases. The inherited modeling restriction of at most seven calendar days from preceding close to first-session close is retained. The 27 January and 10 March 2011 meetings share the 23–24 March reopening windows after the long closure; their raw ratios are visible but both meetings are excluded, also under an explicit shared-window rule.

For each meeting date, the first target session is the first accepted observed date **strictly after** the meeting; the second is its next accepted date. The preceding close is the final accepted date on or before the meeting. Thus an ordinary Thursday example is Thursday→Sunday, Sunday→Monday, Thursday→Monday. Irregular meetings follow actual observed dates. These daily labels do not isolate an intraday announcement effect.

For preceding close P0, first close P1 and second close P2:

```text
first_session_return_pct        = 100 * (P1/P0 - 1)
second_session_return_pct       = 100 * (P2/P1 - 1)
combined_two_session_return_pct = 100 * (P2/P0 - 1)
                               = 100 * ((1+r1/100)*(1+r2/100) - 1)
```

The common conceptual forecast origin is **before the first session opens**, with the same information set for all three targets. No historical open clock is fabricated. Sector/EGX30 lagged returns use the last two accepted sessions **strictly before the meeting date**, conservatively retaining the existing predictor convention. Realized first-session closes/returns are outcome-side fields and must never enter a second-session forecast issued at that common origin. The manifest identifies allowed numerical predictors and prohibited outcome-side fields. Text encoders, PCA and scalers must be learned within permitted training subsets; none is globally fitted here.

## Definitions, availability and exclusions

Sector construction is labelled `legacy_2007` through 31 December 2019 and `modern_live_from_2020_01_02` thereafter. No ordinary return is computed across that level/definition break, and modeling context spanning the break is excluded. Current methodology documents do not prove historical homogeneity or the old construction. **The separate historical modern-backcast case is not reconstructed:** unavailable modern 2019 Refinitiv observations are not synthesized from legacy values. EGX30 remains a separate broad-market instrument.

All **174 exact original clocks remain unverified**. The 32 matching reproduction records are retained as copy evidence. No copy clock, URL component, date-only label or PDF-generation timestamp is promoted to first CBE release. First-original release date/time fields remain blank. `rate_effective_date` also remains blank with a not-systematically-extracted/verified status; meeting, availability, rate-effective and session dates are distinct. The earlier ordering diagnostic applies to its historical target version, not automatic certification of new windows. The written-feedback allowance for retrospective reporting permits this qualified computational handover; real-time/tradability claims remain unsupported.

The common cohort is selected mechanically from original-English policy candidates with observed signed action, both sectors' complete conservative lagged returns, all three targets, definition-consistent contexts, acceptable initial close gaps and no shared reopening windows. Exclusions include missing pre-2007 sector data, administrative records, the Arabic-only unresolved-action record and the two prolonged/shared reopening events. Previously inspected history stays inspected; a source/window change does not create an untouched test.

## Validation and reproduction

`04_data/verification/refinitiv_only_2026-10-26/validation_summary.json` records nine passing computational groups and zero failures. Sixteen focused tests cover closure/weekend/holiday mapping, absent sessions, the 2020 boundary, cumulative compounding, provisional bars, same-cutoff inputs, nonfinite values, sign and missing-versus-zero errors, prolonged closures and shared reopening windows. Independent raw XLSX XML/Decimal replay checked 16,594 observed raw closes, 16,581 daily ratios, 2,294 event input/target close links, 954 available target ratios, 670 predictor ratios and 318 compounding identities. Both included and excluded records were checked. Source hashes were checked before and after building; earlier source reviews remain labelled inherited.

See `05_analysis/refinitiv_only_2026-10-26/REPRODUCE.md` for a non-overwriting rebuild and the executed data-only notebook. Semantic/timing/index/calendar and actual license limits remain explicit; computational PASS is not perfection or universal source certification.

## Access and external handover

The complete core local package contains raw exports, all 176 original CBE PDFs, full retained texts, processed tables, evidence, code and guides. The 31 MB world-corpus snapshot referenced only by the two excluded administrative transcriptions is represented by its hash/access manifest; it is preserved in the original workspace and is required only for strict replay of that inherited administrative provenance. No modeled text or price is sourced from it. No credentials or private correspondence are included. A prepared package is not a thesis submission. The applicable university/LSEG storage/redistribution agreement is not retained. The raw and derived licensed price material stays local pending that exact entitlement check; any separate private Drive companion contains only authored code/documentation/metadata and is labelled accordingly. No recipients or public/link-wide access are authorized.
