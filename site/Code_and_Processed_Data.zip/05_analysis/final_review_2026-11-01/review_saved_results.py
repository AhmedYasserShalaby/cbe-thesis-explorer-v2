"""Verify current first-session outputs without importing or fitting any model.

From the thesis root, or the extracted research archive:
    python3 05_analysis/final_review_2026-11-01/review_saved_results.py

Uses Python's standard library. Reads files only; prints a JSON receipt.
It does not retrain encoders, replay bootstrap intervals or modify results.
"""
from pathlib import Path
from collections import defaultdict, Counter
import csv
import hashlib
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[2]
RESULT = ROOT / '06_results/first_session_only_2026-10-28/run_001'
DATA = ROOT / '04_data/processed/first_session_only_2026-10-28'


def rows(path):
    with path.open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(actual, expected, label):
    if not math.isclose(float(actual), float(expected), rel_tol=1e-10, abs_tol=2e-10):
        raise AssertionError((label, actual, expected))


def main():
    predictions = rows(RESULT / 'predictions.csv')
    metrics = rows(RESULT / 'metrics.csv')
    pairs = rows(RESULT / 'paired_text_differences.csv')
    panel_rows = rows(DATA / 'event_sector_modeling.csv')
    panel = {(r['doc_id'], r['sector']): r for r in panel_rows}
    assert len(panel) == len(panel_rows), 'Duplicate announcement-sector records'
    splits = json.loads((DATA / 'chronological_splits.json').read_text())
    plans = {(case, p['doc_id']): p for case, ps in splits.items() for p in ps}
    groups = defaultdict(list)
    keys = set()
    means = {}
    for p in predictions:
        key = (p['case'], p['doc_id'], p['sector'], p['family'], p['variant'])
        assert key not in keys, ('Duplicate prediction', key)
        keys.add(key)
        assert p['horizon'] == 'first_session'
        assert p['last_training_label_end'] < p['event_date']
        source = panel[(p['doc_id'], p['sector'])]
        assert source['in_common_event_cohort'] == 'True'
        assert p['first_session_date'] == source['first_session_date']
        assert p['target_label_end'] == p['first_session_date']
        close(p['actual_pp'], source['first_session_return_pct'], (key, 'target'))
        mk = (p['case'], p['doc_id'], p['sector'])
        plan = plans[(p['case'], p['doc_id'])]
        if mk not in means:
            ids = plan['training_doc_ids']
            assert len(ids) == len(set(ids))
            training = [panel[(i, p['sector'])] for i in ids]
            assert all(t['first_session_date'] < p['event_date'] for t in training)
            means[mk] = math.fsum(float(t['first_session_return_pct']) for t in training) / len(training)
        close(p['historical_mean_pp'], means[mk], (key, 'training mean'))
        assert int(p['training_events']) == len(plan['training_doc_ids'])
        groups[(p['case'], p['sector'], p['family'], p['variant'])].append(p)

    checked_values = 0
    for m in metrics:
        key = (m['case'], m['sector'], m['family'], m['variant'])
        g = groups[key]
        actual = [float(p['actual_pp']) for p in g]
        forecast = [float(p['prediction_pp']) for p in g]
        e = [a-f for a, f in zip(actual, forecast)]
        sse = math.fsum(x*x for x in e)
        denominator = math.fsum((float(p['actual_pp'])-float(p['historical_mean_pp']))**2 for p in g)
        up = [i for i, a in enumerate(actual) if a > 0]
        down = [i for i, a in enumerate(actual) if a < 0]
        correct_up = sum(forecast[i] > 0 for i in up)
        correct_down = sum(forecast[i] < 0 for i in down)
        expected = {
            'test_events': len(g), 'MAE_pp': math.fsum(map(abs, e))/len(g),
            'RMSE_pp': math.sqrt(sse/len(g)), 'model_SSE_pp2': sse,
            'expanding_mean_SSE_pp2': denominator, 'R2_OS': 1-sse/denominator,
            'actual_up': len(up), 'actual_down': len(down),
            'actual_flat': sum(a == 0 for a in actual),
            'predicted_flat': sum(f == 0 for f in forecast),
            'direction_scored': len(up)+len(down),
            'direction_correct': correct_up+correct_down,
            'direction_accuracy': (correct_up+correct_down)/(len(up)+len(down)),
            'up_recall': correct_up/len(up), 'down_recall': correct_down/len(down),
            'balanced_direction_accuracy': (correct_up/len(up)+correct_down/len(down))/2,
        }
        for field, value in expected.items():
            close(m[field], value, (key, field))
            checked_values += 1

    for p in pairs:
        variants = {}
        for variant in ['numerical', 'text_added']:
            key = (p['case'], p['sector'], p['family'], variant)
            variants[variant] = {r['doc_id']: r for r in groups[key]}
        a, b = variants['numerical'], variants['text_added']
        assert set(a) == set(b)
        absolute = []
        square = []
        for identity in a:
            close(a[identity]['actual_pp'], b[identity]['actual_pp'], 'paired actual')
            y = float(a[identity]['actual_pp'])
            ea = y-float(a[identity]['prediction_pp'])
            eb = y-float(b[identity]['prediction_pp'])
            absolute.append(abs(eb)-abs(ea))
            square.append(eb*eb-ea*ea)
        close(p['MAE_difference_pp'], math.fsum(absolute)/len(a), 'paired MAE')
        close(p['MSE_difference_pp2'], math.fsum(square)/len(a), 'paired MSE')
        assert int(p['test_events']) == len(a)
        assert int(p['block_length']) == 5 and int(p['replicates']) == 2000

    common = [r for r in panel_rows if r['in_common_event_cohort'] == 'True']
    assert len(common) == 310 and len({r['doc_id'] for r in common}) == 155
    return_ratios = 0
    for r in common:
        for out, before, after in [
            ('first_session_return_pct', 'preceding_session_sector_close', 'first_session_sector_close'),
            ('pre_event_sector_return_pct', 'pre_return_start_sector_close', 'pre_return_end_sector_close'),
            ('pre_event_egx30_return_pct', 'pre_return_start_egx30_close', 'pre_return_end_egx30_close'),
        ]:
            close(r[out], 100*(float(r[after])/float(r[before])-1), (r['doc_id'], r['sector'], out))
            return_ratios += 1
        assert r['pre_return_end_date'] < r['event_date'] < r['first_session_date']

    # This archive route deliberately verifies saved outputs, without model imports.
    parent = ROOT / '06_results/model_comparison_corrected_2026-10-27/run_001/predictions.csv'
    preserved = None
    if parent.exists():
        prior = {(r['case'], r['doc_id'], r['sector'], r['family'], r['variant']): r
                 for r in rows(parent) if r['horizon'] == 'first_session'}
        for p in predictions:
            old = prior[(p['case'], p['doc_id'], p['sector'], p['family'], p['variant'])]
            assert all(v == old[k] for k, v in p.items() if k != 'last_training_label_end')
        preserved = len(predictions)
    assert len(predictions) == 3100 and len(metrics) == 40 and len(pairs) == 16
    improved = sum(float(p['MAE_difference_pp']) < 0 for p in pairs)
    include_zero = sum(float(p['MAE_difference_pp_low']) <= 0 <= float(p['MAE_difference_pp_high']) for p in pairs)
    zero_wins = 0
    for m in metrics:
        if m['variant'] == 'reference':
            continue
        z = next(x for x in metrics if x['case'] == m['case'] and x['sector'] == m['sector'] and x['family'] == 'zero_return')
        assert float(z['MAE_pp']) < float(m['MAE_pp']) and float(z['RMSE_pp']) < float(m['RMSE_pp'])
        zero_wins += 1
    print(json.dumps({
        'status': 'PASS_WITH_BOUNDS', 'scope': 'Saved first-session arithmetic and chronological identities',
        'model_fits': 0, 'bootstrap_recalculations': 0,
        'forecast_rows': len(predictions), 'metric_groups': len(metrics),
        'metric_values_recomputed': checked_values, 'paired_comparisons': len(pairs),
        'training_means_checked': len(means), 'return_ratios_checked': return_ratios,
        'saved_parent_forecasts_unchanged': preserved,
        'text_MAE_improvements': improved, 'descriptive_intervals_including_zero': include_zero,
        'learned_variants_beaten_by_zero_on_MAE_and_RMSE': zero_wins,
        'case_origins': dict(Counter(case for case, _ in plans)),
        'bounds': ['Does not certify original publication clocks, historical text vintages, complete source semantics or data-use permission.',
                   'Does not establish a new holdout, causality, profitability, a fresh-machine retraining test or academic approval.'],
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in [RESULT/'predictions.csv', RESULT/'metrics.csv', RESULT/'paired_text_differences.csv', DATA/'event_sector_modeling.csv', DATA/'chronological_splits.json']},
    }, indent=2))


if __name__ == '__main__':
    main()
