"""Fail closed unless the validator-approved corrected environment is intact."""
from __future__ import annotations
import hashlib, importlib, importlib.metadata, json, os, sys
from pathlib import Path
from utils import ROOT, sha256, canonical_hash

BACKEND=ROOT/'05_analysis/word2vec_backend_fix_2026-10-27'
REVIEW=ROOT/'04_data/verification/word2vec_corrected_review_2026-10-27'
READY=BACKEND/'ready.json'
ACCEPTANCE=REVIEW/'backend_acceptance.json'
CANDIDATE=BACKEND/'candidate.json'


def require_hash(path, digest, label):
    path=Path(path)
    if not path.is_file() or sha256(path)!=digest:
        raise ValueError(f'{label} missing or changed: {path}')


def verify_candidate(candidate):
    if Path(sys.executable).absolute()!=Path(candidate['python_executable']).absolute() or sys.version!=candidate['python_version']:
        raise ValueError('Interpreter is not the corrected candidate runtime')
    require_hash(sys.executable,candidate['python_sha256'],'Python binary')
    require_hash(candidate['pyvenv_cfg'],candidate['pyvenv_cfg_sha256'],'virtual environment config')
    require_hash(candidate['runtime_inventory'],candidate['runtime_inventory_sha256'],'runtime inventory')
    inventory=json.loads(Path(candidate['runtime_inventory']).read_text())
    files=inventory['files_sha256'];site=Path(inventory['site_packages'])
    if canonical_hash(files)!=inventory['files_canonical_sha256'] or inventory['files_canonical_sha256']!=candidate['runtime_files_canonical_sha256']:
        raise ValueError('Dependency inventory fingerprint changed')
    actual_names={str(p.relative_to(site)) for p in site.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if actual_names!=set(files) or len(files)!=inventory['file_count']:
        raise ValueError('Installed dependency inventory membership changed')
    for name,digest in files.items():
        require_hash(site/name,digest,'installed runtime file')
    actual_packages={d.metadata['Name']:d.version for d in importlib.metadata.distributions()}
    if actual_packages!=candidate['package_versions'] or actual_packages!=inventory['packages']:
        raise ValueError('Installed package versions differ from candidate')
    for name, expected_path in candidate['module_import_paths'].items():
        module=importlib.import_module(name)
        if str(Path(module.__file__).resolve())!=expected_path:
            raise ValueError(f'Unexpected module import path: {name}')
    from gensim.models import word2vec_inner
    if word2vec_inner.FAST_VERSION!=1 or word2vec_inner.FAST_VERSION!=candidate['word2vec_inner']['FAST_VERSION']:
        raise ValueError('Unexpected Word2Vec backend')
    for obj,label in [(candidate['word2vec_inner'],'Word2Vec binary'),(candidate['scipy_fblas'],'BLAS binary'),(candidate['patch'],'source patch')]:
        require_hash(obj['path'],obj['sha256'],label)
    source=candidate['source']
    require_hash(source['tarball'],source['tarball_sha256'],'source distribution')
    require_hash(source['supplemental_tag_file'],source['supplemental_tag_file_sha256'],'supplemental tagged source')
    require_hash(BACKEND/'source/patched/gensim/models/word2vec_inner.c',source['generated_word2vec_c_sha256'],'generated C')
    for name, hashes in source['all_pyx_pxd_differences'].items():
        require_hash(BACKEND/'source/patched'/name,hashes['patched_sha256'],'patched source')
        require_hash(BACKEND/'source/unpatched'/name,hashes['control_sha256'],'control source')
    require_hash(candidate['regression_script'],candidate['regression_script_sha256'],'backend regression script')
    corrected=candidate['self_tests']['corrected']
    for name in ['stdout','stderr']:
        require_hash(corrected[name],corrected[name+'_sha256'],f'corrected regression {name}')
    report=json.loads(Path(corrected['stdout']).read_text())
    if report['counts']!=corrected['counts'] or any(v['failed']!=0 or v['passed']!=v['total'] for v in corrected['counts'].values()):
        raise ValueError('Arithmetic/public-API regression receipt fails')
    if Path(corrected['stderr']).stat().st_size!=0 or corrected['FAST_VERSION']!=1 or corrected['word2vec_sha256']!=candidate['word2vec_inner']['sha256']:
        raise ValueError('Regression stderr, backend or binary mismatch')
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:
        if os.environ.get(name)!='1': raise ValueError(f'Native thread limit not set: {name}')
    if os.environ.get('PYTHONHASHSEED')!='42': raise ValueError('PYTHONHASHSEED must be 42 before interpreter startup')
    return inventory


def verify_runtime():
    if not READY.is_file() or not ACCEPTANCE.is_file() or not CANDIDATE.is_file():
        raise RuntimeError('Corrected backend readiness and matching independent backend acceptance are required; no fit is permitted')
    ready=json.loads(READY.read_text()); acceptance=json.loads(ACCEPTANCE.read_text());candidate=json.loads(CANDIDATE.read_text())
    if ready.get('ready_for_corrected_rerun') is not True:
        raise RuntimeError('Corrected backend is not marked ready')
    candidate_hash=sha256(CANDIDATE)
    if acceptance.get('accepted') is not True or acceptance.get('accepted_for_corrected_rerun') is not True or acceptance.get('status')!='PASS_WITH_BOUNDS':
        raise RuntimeError('Independent backend review did not accept this candidate')
    if acceptance.get('candidate_sha256')!=candidate_hash:
        raise ValueError('Independent acceptance references a different candidate')
    for key, expected in [('python_executable',candidate['python_executable']),('python_sha256',candidate['python_sha256']),
                          ('runtime_files_canonical_sha256',candidate['runtime_files_canonical_sha256']),
                          ('runtime_inventory_sha256',candidate['runtime_inventory_sha256']),
                          ('word2vec_inner_sha256',candidate['word2vec_inner']['sha256']),
                          ('scipy_fblas_sha256',candidate['scipy_fblas']['sha256']),('patch_sha256',candidate['patch']['sha256']),
                          ('source_sdist_sha256',candidate['source']['tarball_sha256'])]:
        if acceptance.get(key)!=expected: raise ValueError(f'Independent acceptance mismatch: {key}')
    require_hash(ROOT/acceptance['audit_path'],acceptance['audit_sha256'],'independent backend audit')
    audit=json.loads((ROOT/acceptance['audit_path']).read_text())
    if audit['status']!='PASS' or audit['failure_count']!=0 or audit['candidate_sha256']!=candidate_hash:
        raise ValueError('Independent backend audit failed or differs')
    require_hash(REVIEW/'independent_backend_probe.py',acceptance['probe_script_sha256'],'independent probe script')
    for name in ['original','control','corrected']:
        require_hash(REVIEW/f'{name}_probe_stdout.json',acceptance['probe_stdout_sha256'][name],'independent probe stdout')
        require_hash(REVIEW/f'{name}_probe_stderr.txt',acceptance['probe_stderr_sha256'][name],'independent probe stderr')
    probe=json.loads((REVIEW/'corrected_probe_stdout.json').read_text())
    if not probe['passed_all'] or probe['extension_sha256']!=candidate['word2vec_inner']['sha256'] or probe['public_scoring_passed']!=probe['public_scoring_total'] or (REVIEW/'corrected_probe_stderr.txt').stat().st_size:
        raise ValueError('Independent mathematical/public API regression failed')
    if ready.get('schema')!='word2vec-corrected-backend-ready-v1' or ready.get('independent_acceptance_status')!='PASS_WITH_BOUNDS':
        raise ValueError('Unsupported or unaccepted ready receipt')
    if ready.get('candidate_path')!=str(CANDIDATE.relative_to(ROOT)) or ready.get('candidate_sha256')!=candidate_hash:
        raise ValueError('Ready receipt references a different candidate')
    if ready.get('backend_acceptance_path')!=str(ACCEPTANCE.relative_to(ROOT)) or ready.get('backend_acceptance_sha256')!=sha256(ACCEPTANCE):
        raise ValueError('Ready receipt references a different independent acceptance')
    for key, expected in [('python_executable',candidate['python_executable']),('python_sha256',candidate['python_sha256']),
                          ('python_version',candidate['python_version']),('pyvenv_cfg_sha256',candidate['pyvenv_cfg_sha256']),
                          ('runtime_inventory_sha256',candidate['runtime_inventory_sha256']),
                          ('runtime_files_canonical_sha256',candidate['runtime_files_canonical_sha256']),
                          ('word2vec_inner_path',candidate['word2vec_inner']['path']),('word2vec_inner_sha256',candidate['word2vec_inner']['sha256']),
                          ('scipy_fblas_path',candidate['scipy_fblas']['path']),('scipy_fblas_sha256',candidate['scipy_fblas']['sha256']),
                          ('source_sdist_sha256',candidate['source']['tarball_sha256']),('patch_sha256',candidate['patch']['sha256']),
                          ('package_versions',candidate['package_versions']),('module_import_paths',candidate['module_import_paths']),
                          ('self_tests',candidate['self_tests']),('FAST_VERSION',1),('selected_path','our_dot_float')]:
        if ready.get(key)!=expected: raise ValueError(f'Ready receipt mismatch: {key}')
    for name in ['build_and_test_instructions','dependency_identity','rebuild_check_regression','rebuild_check_regression_stderr',
                 'rebuild_check_stderr','rebuild_check_stdout','rebuild_script','runtime_freeze_permissions','runtime_integrity_after_freeze',
                 'upstream_suite_first_stderr','upstream_suite_first_stdout','upstream_suite_retry_stderr','upstream_suite_retry_stdout']:
        item=ready[name];require_hash(ROOT/item['path'],item['sha256'],f'ready receipt {name}')
    inventory=verify_candidate(candidate)
    return {'ready_path':str(READY.relative_to(ROOT)), 'ready_sha256':sha256(READY),
            'acceptance_path':str(ACCEPTANCE.relative_to(ROOT)), 'acceptance_sha256':sha256(ACCEPTANCE),
            'candidate_path':str(CANDIDATE.relative_to(ROOT)), 'candidate_sha256':candidate_hash,
            'runtime_inventory_sha256':candidate['runtime_inventory_sha256'],
            'runtime_files_canonical_sha256':candidate['runtime_files_canonical_sha256'], 'runtime_file_count':inventory['file_count'],
            'python_executable':candidate['python_executable'], 'python_sha256':candidate['python_sha256'],
            'word2vec_inner_sha256':candidate['word2vec_inner']['sha256'], 'scipy_fblas_sha256':candidate['scipy_fblas']['sha256'],
            'source_sdist_sha256':candidate['source']['tarball_sha256'], 'source_tag_commit':candidate['source']['released_tag_commit'],
            'patch_sha256':candidate['patch']['sha256'], 'generated_word2vec_c_sha256':candidate['source']['generated_word2vec_c_sha256'],
            'package_versions':candidate['package_versions'], 'toolchain':candidate['toolchain'],
            'backend_acceptance_status':acceptance['status'], 'backend_acceptance_bounds':acceptance['bounds'],
            'self_test_counts':candidate['self_tests']['corrected']['counts'],
            'independent_probe_sha256':acceptance['probe_stdout_sha256']['corrected']}

