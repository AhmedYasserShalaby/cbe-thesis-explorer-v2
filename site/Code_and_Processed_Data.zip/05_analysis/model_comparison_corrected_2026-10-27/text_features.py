"""Past-only audited text algorithm, shared legally across models and horizons."""
from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from gensim.models import Word2Vec, KeyedVectors
from sklearn.decomposition import PCA

from utils import sha256, canonical_hash, atomic_json, relative, environment


def stable_hash(token: str) -> int:
    import hashlib
    return int.from_bytes(hashlib.sha256(token.encode()).digest()[:8], 'little')


def tokens(text: str) -> list[str]:
    text = unicodedata.normalize('NFKC', str(text)).lower().replace('\x00', '')
    return re.findall(r"[a-z]+(?:'[a-z]+)?|\d+(?:\.\d+)?|[^\w\s]", text)


def sentence_tokens(text: str) -> list[list[str]]:
    chunks = re.split(r'(?<=[!?])\s+|(?<!\d)\.\s+|\n\s*\n', str(text))
    return [ts for sentence in chunks if len(ts := tokens(sentence)) >= 2]


def language_history(corpus: pd.DataFrame, cutoff: str) -> pd.DataFrame:
    history = corpus.loc[corpus.record_status.eq('policy_statement_candidate') &
                         corpus.source_language.ne('Official_Arabic') &
                         corpus.event_date.lt(cutoff)].sort_values(['event_date', 'doc_id']).copy()
    if history.empty or not history.event_date.lt(cutoff).all():
        raise ValueError('Empty or illegal language history')
    # No translations or external corpus introduced by the loader.
    if not history.source_language.eq('Official_English').all():
        raise ValueError('Non-original-English language history')
    return history


def document_vector(wv: KeyedVectors, text: str) -> tuple[np.ndarray, dict]:
    ts = tokens(text)
    known = [t for t in ts if t in wv]
    if not ts or not known:
        raise ValueError('Zero token or zero past-vocabulary coverage')
    # Same token-occurrence mean as retained implementation (float32 arithmetic),
    # then retain a float64 matrix for explicit PCA/model arithmetic.
    vector = np.mean([wv[t] for t in known], axis=0).astype(np.float64)
    if not np.isfinite(vector).all():
        raise ValueError('Nonfinite document vector')
    return vector, {'total_tokens': len(ts), 'known_tokens': len(known),
                    'unknown_tokens': len(ts) - len(known),
                    'known_token_fraction': len(known) / len(ts)}


class FeatureManager:
    def __init__(self, corpus: pd.DataFrame, text_config: dict, input_hashes: dict,
                 cache_dir: Path, backend_fingerprint: dict):
        self.corpus = corpus
        self.lookup = corpus.set_index('doc_id')
        self.config = text_config
        self.input_hashes = input_hashes
        self.cache_dir = cache_dir
        if not backend_fingerprint:
            raise ValueError("Missing corrected backend fingerprint")
        self.backend_fingerprint = backend_fingerprint
        self.software = environment()['packages']
        self.encoder_fits = 0
        self.encoder_hits = 0

    def encoder(self, cutoff: str, training_doc_ids: list[str]) -> tuple[KeyedVectors, dict, Path]:
        history = language_history(self.corpus, cutoff)
        key = {'cutoff': cutoff,
               'corrected_backend_fingerprint': self.backend_fingerprint,
               'outcome_training_doc_ids': training_doc_ids,
               'input_hashes': self.input_hashes,
               'implementation_sha256': sha256(Path(__file__)),
               'training_documents': history[['doc_id', 'event_date', 'statement_text_sha256']].to_dict('records'),
               'settings': self.config, 'software': self.software}
        fingerprint = canonical_hash(key)
        directory = self.cache_dir / fingerprint
        receipt_path = directory / 'encoder_receipt.json'
        model_path = directory / 'vectors.kv'
        if directory.exists():
            if not receipt_path.exists() or not model_path.exists():
                raise ValueError('Incomplete encoder cache; preserve and investigate')
            receipt = json.loads(receipt_path.read_text())
            if receipt['key'] != key or receipt['key_sha256'] != fingerprint:
                raise ValueError('Encoder cache key mismatch')
            if sha256(model_path) != receipt['learned_bytes_sha256']:
                raise ValueError('Encoder learned bytes mismatch')
            wv = KeyedVectors.load(str(model_path))
            self.encoder_hits += 1
        else:
            sentences = [sentence for text in history.statement_text for sentence in sentence_tokens(text)]
            settings = dict(self.config['word2vec'])
            fitted = Word2Vec(sentences, hashfxn=stable_hash, **settings)
            wv = fitted.wv
            if len(wv) < 4 or not np.isfinite(wv.vectors).all():
                raise ValueError('Insufficient/invalid language vocabulary')
            directory.mkdir(parents=True, exist_ok=False)
            wv.save(str(model_path), separately=[])
            receipt = {'key': key, 'key_sha256': fingerprint,
                       'cutoff': cutoff, 'training_doc_ids': history.doc_id.tolist(),
                       'training_first_date': history.event_date.min(),
                       'training_last_date': history.event_date.max(),
                       'training_documents': len(history),
                       'training_tokens': sum(map(len, sentences)),
                       'vocabulary_size': len(wv),
                       'learned_bytes_sha256': sha256(model_path),
                       'test_document_used_in_language_training': False,
                       'original_release_clock_verified': False,
                       'historical_vintage_verified': False}
            atomic_json(receipt_path, receipt)
            self.encoder_fits += 1
        if not np.isfinite(wv.vectors).all():
            raise ValueError('Nonfinite cached word vectors')
        return wv, receipt, model_path

    def fold(self, plan: dict, directory: Path) -> tuple[np.ndarray, np.ndarray, dict]:
        wv, encoder, model_path = self.encoder(plan['event_date'], plan['training_doc_ids'])
        ids = plan['training_doc_ids']
        training = self.lookup.loc[ids]
        if not training.event_date.lt(plan['event_date']).all() or plan['doc_id'] in ids:
            raise ValueError('Illegal PCA document cohort')
        matrix, coverages = [], []
        for doc_id in ids:
            vector, coverage = document_vector(wv, self.lookup.loc[doc_id, 'statement_text'])
            matrix.append(vector)
            coverages.append({'doc_id': doc_id, **coverage})
        matrix = np.stack(matrix)
        vector, coverage = document_vector(wv, self.lookup.loc[plan['doc_id'], 'statement_text'])
        pca = PCA(**self.config['pca']).fit(matrix)
        train_pcs = pca.transform(matrix)
        test_pcs = pca.transform(vector.reshape(1, -1))
        if not all(np.isfinite(a).all() for a in [train_pcs, test_pcs, pca.mean_,
                                                 pca.components_, pca.explained_variance_ratio_]):
            raise ValueError('Nonfinite PCA output')
        directory.mkdir(parents=True, exist_ok=False)
        np.savez_compressed(directory / 'features.npz',
                            training_doc_ids=np.asarray(ids), training_vectors=matrix,
                            training_components=train_pcs, test_vector=vector,
                            test_components=test_pcs)
        joblib.dump(pca, directory / 'training_pca.joblib', compress=3)
        metadata = {'event_date': plan['event_date'], 'doc_id': plan['doc_id'],
                    'training_doc_ids': ids,
                    'training_cohort_sha256': canonical_hash(ids),
                    'last_training_label_end': plan['last_training_label_end'],
                    'pca_training_last_event': training.event_date.max(),
                    'encoder_path': relative(model_path),
                    'encoder_receipt_path': relative(model_path.parent / 'encoder_receipt.json'),
                    'encoder_sha256': sha256(model_path),
                    'encoder_key_sha256': encoder['key_sha256'],
                    'encoder_training_first_date': encoder['training_first_date'],
                    'encoder_training_last_date': encoder['training_last_date'],
                    'encoder_training_documents': encoder['training_documents'],
                    'encoder_vocabulary_size': len(wv),
                    'pca_settings': self.config['pca'],
                    'pca_explained_variance_ratio': pca.explained_variance_ratio_.tolist(),
                    'test_coverage': coverage, 'training_coverage': coverages,
                    'pca_sha256': sha256(directory / 'training_pca.joblib'),
                    'feature_bytes_sha256': sha256(directory / 'features.npz')}
        atomic_json(directory / 'feature_manifest.json', metadata)
        return train_pcs, test_pcs, metadata
