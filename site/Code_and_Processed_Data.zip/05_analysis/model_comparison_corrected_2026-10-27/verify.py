"""Independent saved-output arithmetic and representative artifact replay.

Imports no scoring helper and never calls fit/train. Separate arithmetic checks
every metric and benchmark, complete candidate grid and chronological split.
"""
from __future__ import annotations

import os
for _name in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
              'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ[_name] = '1'

import argparse
import json
import math
from bisect import bisect_right, bisect_left
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from gensim.models import KeyedVectors

from data import load_snapshot, case_frame, boolean, FEATURES, TARGETS, SECTORS, HORIZONS
from utils import ROOT, METHODOLOGY, RESULTS, atomic_json, sha256, canonical_hash, validate_hashes, relative


def close(observed, expected, label, tol=2e-10):
    if expected is None:
        if not pd.isna(observed):
            raise AssertionError(f'{label}: expected undefined, received {observed}')
    elif not np.isfinite(float(observed)) or not math.isclose(float(observed), float(expected), rel_tol=tol, abs_tol=tol):
        raise AssertionError(f'{label}: {observed} != {expected}')


def independent_direction(actual, predicted):
    up = [i for i, value in enumerate(actual) if value > 0]
    down = [i for i, value in enumerate(actual) if value < 0]
    correct_up = sum(predicted[i] > 0 for i in up)
    correct_down = sum(predicted[i] < 0 for i in down)
    return {'actual_up': len(up), 'actual_down': len(down),
            'actual_flat': sum(value == 0 for value in actual),
            'predicted_flat': sum(value == 0 for value in predicted),
            'direction_scored': len(up) + len(down),
            'direction_correct': correct_up + correct_down,
            'direction_accuracy': (correct_up + correct_down)/(len(up)+len(down)) if up or down else None,
            'up_recall': correct_up/len(up) if up else None,
            'down_recall': correct_down/len(down) if down else None,
            'balanced_direction_accuracy': (correct_up/len(up) + correct_down/len(down))/2 if up and down else None}


def independent_scores(group):
    actual = group.actual_pp.tolist()
    predicted = group.prediction_pp.tolist()
    benchmark = group.historical_mean_pp.tolist()
    squared = math.fsum((p-a)**2 for p, a in zip(predicted, actual))
    denominator = math.fsum((b-a)**2 for b, a in zip(benchmark, actual))
    return {'test_events': len(actual),
            'MAE_pp': math.fsum(abs(p-a) for p, a in zip(predicted, actual))/len(actual),
            'RMSE_pp': math.sqrt(squared/len(actual)),
            'model_SSE_pp2': squared, 'expanding_mean_SSE_pp2': denominator,
            'R2_OS': 1-squared/denominator if denominator != 0 else None,
            **independent_direction(actual, predicted)}


def compare_metric_table(predictions, table, keys):
    expected_keys = set()
    for group_key, group in predictions.groupby(keys, sort=True):
        expected_keys.add(group_key)
        selected = table
        for name, value in zip(keys, group_key):
            selected = selected.loc[selected[name].eq(value)]
        if len(selected) != 1:
            raise AssertionError(f'Missing/duplicate metric row: {group_key}')
        row = selected.iloc[0]
        scores = independent_scores(group)
        for metric, value in scores.items():
            close(row[metric], value, f'{group_key} {metric}')
        expected_status = 'defined' if scores['expanding_mean_SSE_pp2'] != 0 else 'undefined_zero_benchmark_SSE'
        if row.R2_OS_status != expected_status:
            raise AssertionError('Incorrect undefined R2_OS status')
    actual_keys = set(table[keys].itertuples(index=False, name=None))
    if actual_keys != expected_keys or len(table) != len(expected_keys):
        raise AssertionError('Extra/missing/duplicate metric groups')


def check_target_price_alignment(snapshot):
    """Independent ratios and session selection from declared daily source table."""
    daily = snapshot.daily
    if daily.duplicated(['instrument', 'date']).any():
        raise AssertionError('Duplicate declared daily prices')
    prices = daily.set_index(['instrument', 'date'])
    sessions = sorted(daily.loc[boolean(daily.eligible_observed_session), 'date'].unique())
    rows = snapshot.panel.loc[boolean(snapshot.panel.in_common_event_cohort)]
    arithmetic, prices_checked = 0, 0
    for row in rows.itertuples(index=False):
        post = bisect_right(sessions, row.event_date)
        strictly_prior = bisect_left(sessions, row.event_date)
        expected_dates = {'pre_return_start_date': sessions[strictly_prior-2],
                          'pre_return_end_date': sessions[strictly_prior-1],
                          'preceding_session_date': sessions[post-1],
                          'first_session_date': sessions[post],
                          'second_session_date': sessions[post+1]}
        for name, value in expected_dates.items():
            if getattr(row, name) != value:
                raise AssertionError(f'Session target/feature misalignment: {name}')
        def price(instrument, day):
            record = prices.loc[(instrument, day)]
            if not boolean(pd.Series([record.eligible_close])).iloc[0]:
                raise AssertionError('Ineligible daily close in common event')
            value = float(record.close)
            if not math.isfinite(value) or value <= 0:
                raise AssertionError('Invalid source close')
            return value
        levels = {}
        for prefix, day in [(name.removesuffix('_date'), day) for name, day in expected_dates.items()]:
            levels[prefix] = price(row.sector, day)
            close(getattr(row, prefix+'_sector_close'), levels[prefix], 'Daily-sector lineage')
            prices_checked += 1
        for prefix in ['pre_return_start', 'pre_return_end']:
            day = expected_dates[prefix+'_date']
            close(getattr(row, prefix+'_egx30_close'), price('egx30', day), 'Daily-market lineage')
            prices_checked += 1
        comparisons = [
            (row.first_session_return_pct, levels['first_session']/levels['preceding_session']),
            (row.second_session_return_pct, levels['second_session']/levels['first_session']),
            (row.combined_two_session_return_pct, levels['second_session']/levels['preceding_session']),
            (row.pre_event_sector_return_pct, levels['pre_return_end']/levels['pre_return_start']),
            (row.pre_event_egx30_return_pct, price('egx30', row.pre_return_end_date)/price('egx30', row.pre_return_start_date))]
        for observed, ratio in comparisons:
            close(observed, 100*(ratio-1), 'Independent price-return arithmetic')
            arithmetic += 1
    return {'common_sector_rows': len(rows), 'daily_lineage_cells': prices_checked,
            'targets_and_lagged_returns_recomputed': arithmetic,
            'boundary_handling': 'All predictor/target context in one legacy or live regime; loader independently rejects crossing intervals'}


def independent_paired(group, settings):
    numeric = group.loc[group.variant.eq('numerical')].set_index('doc_id')
    text = group.loc[group.variant.eq('text_added')].set_index('doc_id')
    ordered = sorted(numeric.index, key=lambda doc: (numeric.loc[doc, 'event_date'], doc))
    if set(numeric.index) != set(text.index) or len(set(ordered)) != len(ordered):
        raise AssertionError('Unequal paired announcements')
    for doc in ordered:
        for name in ['event_date', 'actual_pp', 'training_cohort_sha256', 'historical_mean_pp']:
            if numeric.loc[doc, name] != text.loc[doc, name]:
                raise AssertionError(f'Paired input mismatch: {name}')
    actual = [float(numeric.loc[d, 'actual_pp']) for d in ordered]
    numeric_error = [float(numeric.loc[d, 'prediction_pp'])-a for d, a in zip(ordered, actual)]
    text_error = [float(text.loc[d, 'prediction_pp'])-a for d, a in zip(ordered, actual)]
    n = len(ordered)
    block = min(settings['block_length'], n)
    def statistics(indices):
        mae = math.fsum(abs(text_error[i])-abs(numeric_error[i]) for i in indices)/n
        numeric_mse = math.fsum(numeric_error[i]**2 for i in indices)/n
        text_mse = math.fsum(text_error[i]**2 for i in indices)/n
        return [mae, text_mse-numeric_mse, math.sqrt(text_mse)-math.sqrt(numeric_mse)]
    estimate = statistics(range(n))
    rng = np.random.default_rng(settings['seed'])
    bootstrap = []
    for _ in range(settings['replicates']):
        starts = rng.integers(0, n, size=math.ceil(n/block))
        indices = [(int(start)+offset) % n for start in starts for offset in range(block)][:n]
        bootstrap.append(statistics(indices))
    percentiles = np.percentile(np.asarray(bootstrap), [2.5, 97.5], axis=0)
    result = {'test_events': n, 'block_length': block,
              'replicates': settings['replicates'], 'seed': settings['seed']}
    for i, label in enumerate(['MAE_difference_pp', 'MSE_difference_pp2', 'RMSE_difference_pp']):
        result.update({label: estimate[i], label+'_low': percentiles[0, i], label+'_high': percentiles[1, i]})
    return result


def check_pair_table(predictions, table, keys, settings):
    groups = list(predictions.loc[predictions.variant.isin(['numerical', 'text_added'])].groupby(keys, sort=True))
    if len(table) != len(groups) or table.duplicated(keys).any():
        raise AssertionError('Incomplete/duplicate paired table')
    for group_key, group in groups:
        selected = table
        for name, value in zip(keys, group_key):
            selected = selected.loc[selected[name].eq(value)]
        if len(selected) != 1:
            raise AssertionError('Missing paired metric row')
        for metric, value in independent_paired(group, settings).items():
            close(selected.iloc[0][metric], value, f'{group_key} {metric}')


def check_pipeline_artifacts(predictions, frozen, snapshot):
    """All fold PCA/scalers/matrices; first/middle/last fold models independently."""
    checks = {'fold_feature_spaces': 0, 'scalers': 0, 'independent_model_replays': 0,
              'replayed_family_counts': {}, 'max_prediction_difference_pp': 0.0}
    for case, plans in frozen['splits'].items():
        frame = case_frame(snapshot, case)
        numeric_names = FEATURES + frozen['specification']['cohorts'][case]['additional_numerical_features']
        for plan in plans:
            rows = predictions.loc[(predictions.case == case) & (predictions.doc_id == plan['doc_id'])]
            directory = ROOT / rows.fold_artifact_directory.iloc[0]
            metadata = json.loads((directory/'feature_manifest.json').read_text())
            if metadata['training_doc_ids'] != plan['training_doc_ids']:
                raise AssertionError('PCA training cohort changed')
            if metadata['encoder_training_last_date'] >= plan['event_date']:
                raise AssertionError('Encoder language cutoff violation')
            if metadata['pca_training_last_event'] >= plan['event_date']:
                raise AssertionError('PCA training cutoff violation')
            encoder_path = ROOT/metadata['encoder_path']
            if sha256(encoder_path) != metadata['encoder_sha256']:
                raise AssertionError('Encoder byte hash mismatch')
            encoder_receipt = json.loads((ROOT/metadata['encoder_receipt_path']).read_text())
            history = snapshot.corpus.loc[snapshot.corpus.record_status.eq('policy_statement_candidate') &
                                          snapshot.corpus.source_language.eq('Official_English') &
                                          snapshot.corpus.event_date.lt(plan['event_date'])].sort_values(['event_date', 'doc_id'])
            if encoder_receipt['training_doc_ids'] != history.doc_id.tolist():
                raise AssertionError('Encoder trained on wrong announcement history')
            if encoder_receipt['key'].get('corrected_backend_fingerprint') != frozen['backend_binding']:
                raise AssertionError('Encoder cache lacks the frozen corrected backend fingerprint')
            if encoder_receipt['key'].get('outcome_training_doc_ids') != plan['training_doc_ids']:
                raise AssertionError('Encoder cache outcome-training cohort differs')
            if not encoder_path.is_relative_to((ROOT/'05_analysis/models/model_comparison_corrected_2026-10-27').resolve()):
                raise AssertionError('Historical encoder reuse is prohibited')
            if canonical_hash(encoder_receipt['key']) != encoder_receipt['key_sha256']:
                raise AssertionError('Encoder cache fingerprint mismatch')
            if encoder_receipt['learned_bytes_sha256'] != metadata['encoder_sha256']:
                raise AssertionError('Encoder cache byte receipt mismatch')
            if not 0 < metadata['test_coverage']['known_token_fraction'] <= 1:
                raise AssertionError('Invalid test vocabulary coverage')
            for name, expected in [('features.npz', metadata['feature_bytes_sha256']),
                                   ('training_pca.joblib', metadata['pca_sha256'])]:
                if sha256(directory/name) != expected:
                    raise AssertionError('Feature artifact bytes changed')
            arrays = np.load(directory/'features.npz', allow_pickle=False)
            if arrays['training_doc_ids'].tolist() != plan['training_doc_ids']:
                raise AssertionError('Saved vector training IDs changed')
            for name in ['training_vectors', 'training_components', 'test_vector', 'test_components']:
                if not np.isfinite(arrays[name]).all():
                    raise AssertionError('Nonfinite learned text arrays')
            pca = joblib.load(directory/'training_pca.joblib')
            if pca.n_samples_ != len(plan['training_doc_ids']):
                raise AssertionError('PCA sample count mismatch')
            np.testing.assert_allclose(pca.mean_, arrays['training_vectors'].mean(axis=0), atol=1e-12)
            for raw, transformed in [('training_vectors', 'training_components'), ('test_vector', 'test_components')]:
                computed = (np.atleast_2d(arrays[raw])-pca.mean_) @ pca.components_.T
                np.testing.assert_allclose(computed, arrays[transformed], atol=1e-10)
            checks['fold_feature_spaces'] += 1
            for sector in SECTORS:
                training_s = frame.loc[frame.doc_id.isin(plan['training_doc_ids']) & frame.sector.eq(sector)].set_index('doc_id').loc[plan['training_doc_ids']]
                test_s = frame.loc[frame.doc_id.eq(plan['doc_id']) & frame.sector.eq(sector)]
                for variant in ['numerical', 'text_added']:
                    matrices = np.load(directory/f'{sector}_{variant}_predictors.npz', allow_pickle=False)
                    scaler = joblib.load(directory/f'{sector}_{variant}_scaler.joblib')
                    x = matrices['training_raw']
                    source_training = training_s[numeric_names].to_numpy(float)
                    source_test = test_s[numeric_names].to_numpy(float)
                    if variant == 'text_added':
                        source_training = np.column_stack([source_training, arrays['training_components']])
                        source_test = np.column_stack([source_test, arrays['test_components']])
                    np.testing.assert_allclose(x, source_training, atol=1e-12)
                    np.testing.assert_allclose(matrices['test_raw'], source_test, atol=1e-12)
                    if not all(np.isfinite(matrices[name]).all() for name in matrices.files):
                        raise AssertionError('Nonfinite learned model matrices')
                    if scaler.n_samples_seen_ != len(plan['training_doc_ids']):
                        raise AssertionError('Scaler fitted to extra/future rows')
                    np.testing.assert_allclose(scaler.mean_, x.mean(axis=0), atol=1e-12)
                    np.testing.assert_allclose(scaler.var_, x.var(axis=0), atol=1e-12)
                    for prefix in ['training', 'test']:
                        np.testing.assert_allclose((matrices[prefix+'_raw']-scaler.mean_)/scaler.scale_,
                                                   matrices[prefix+'_scaled'], atol=1e-12)
                    checks['scalers'] += 1
            # Bounded model replay deliberately samples; all model bytes are hashed separately.
            if plan['fold'] not in {1, len(plans)//2+1, len(plans)}:
                continue
            # Rebuild word-token averages independently of the feature module.
            import re
            import unicodedata
            lookup = snapshot.corpus.set_index('doc_id')
            encoder = KeyedVectors.load(str(encoder_path))
            for doc_id, stored_vector in list(zip(plan['training_doc_ids'], arrays['training_vectors'])) + [(plan['doc_id'], arrays['test_vector'])]:
                body = unicodedata.normalize('NFKC', lookup.loc[doc_id, 'statement_text']).lower().replace('\x00', '')
                ts = re.findall(r"[a-z]+(?:'[a-z]+)?|\d+(?:\.\d+)?|[^\w\s]", body)
                known = [token for token in ts if token in encoder]
                rebuilt = np.asarray([encoder[token] for token in known], dtype=np.float32).mean(axis=0)
                np.testing.assert_allclose(rebuilt, stored_vector, atol=1e-12)
            for row in rows.loc[rows.variant.isin(['numerical', 'text_added'])].itertuples(index=False):
                model = joblib.load(ROOT/row.model_artifact_path)
                xt = np.load(directory/f'{row.sector}_{row.variant}_predictors.npz')['test_scaled'][0]
                if row.family in ['ridge', 'elastic_net']:
                    replay = float(np.dot(xt, model.coef_) + model.intercept_)
                elif row.family == 'rbf_svr':
                    kernel = np.exp(-model._gamma * np.sum((model.support_vectors_-xt)**2, axis=1))
                    replay = float(np.dot(model.dual_coef_[0], kernel) + model.intercept_[0])
                elif row.family == 'random_forest':
                    values = []
                    # sklearn trees compare float32 inputs; traverse saved nodes ourselves.
                    current = xt.astype(np.float32)
                    for tree in model.estimators_:
                        nodes, node = tree.tree_, 0
                        while nodes.children_left[node] != nodes.children_right[node]:
                            feature = nodes.feature[node]
                            node = nodes.children_left[node] if current[feature] <= nodes.threshold[node] else nodes.children_right[node]
                        values.append(float(nodes.value[node, 0, 0]))
                    replay = math.fsum(values)/len(values)
                else:
                    raise AssertionError('Unspecified family')
                close(row.prediction_pp, replay, 'Stored estimator replay', tol=5e-10)
                checks['independent_model_replays'] += 1
                checks['replayed_family_counts'][row.family] = checks['replayed_family_counts'].get(row.family, 0)+1
                checks['max_prediction_difference_pp'] = max(checks['max_prediction_difference_pp'], abs(replay-row.prediction_pp))
    return checks


def verify(output: Path) -> dict:
    output = output.resolve()
    from runtime_gate import verify_runtime
    frozen_path = METHODOLOGY/'frozen_protocol.json'
    frozen = json.loads(frozen_path.read_text())
    computation = json.loads((output/'computation_manifest.json').read_text())
    if verify_runtime() != frozen['backend_binding']:
        raise AssertionError('Runtime differs from accepted frozen backend')
    if computation['protocol_sha256'] != sha256(frozen_path):
        raise AssertionError('Run protocol bytes differ')
    validate_hashes(frozen['input_hashes'])
    validate_hashes(frozen['executable_source_hashes'])
    snapshot = load_snapshot(ROOT/frozen['dataset_manifest_path'])
    target_checks = check_target_price_alignment(snapshot)
    predictions = pd.read_csv(output/'predictions.csv', float_precision='round_trip', keep_default_na=False)
    if not np.isfinite(predictions[['actual_pp', 'prediction_pp', 'historical_mean_pp']].to_numpy(float)).all():
        raise AssertionError('Nonfinite predictions/outcomes')
    if len(predictions) != frozen['derived_expected_counts']['forecasts']:
        raise AssertionError('Incorrect derived forecast count')
    keys = ['case', 'doc_id', 'sector', 'horizon', 'family', 'variant']
    if predictions.duplicated(keys).any():
        raise AssertionError('Duplicate prediction records')
    candidates = [('historical_mean', 'reference'), ('zero_return', 'reference')]
    candidates += [(family, variant) for family in frozen['specification']['models'] for variant in ['numerical', 'text_added']]
    expected_grid = set()
    independent_benchmarks = 0
    for case, plans in frozen['splits'].items():
        frame = case_frame(snapshot, case)
        for plan in plans:
            training = frame.loc[frame.doc_id.isin(plan['training_doc_ids'])]
            if not ((training.event_date < plan['event_date']) & (training.second_session_date < plan['event_date'])).all():
                raise AssertionError('Training label availability violation')
            for sector in SECTORS:
                train_s = training.loc[training.sector.eq(sector)].set_index('doc_id').loc[plan['training_doc_ids']]
                target_s = frame.loc[(frame.sector == sector) & (frame.doc_id == plan['doc_id'])].iloc[0]
                for horizon in HORIZONS:
                    y = train_s[TARGETS[horizon]].to_list()
                    benchmark = math.fsum(y)/len(y)
                    actual = float(target_s[TARGETS[horizon]])
                    for family, variant in candidates:
                        expected_grid.add((case, plan['doc_id'], sector, horizon, family, variant))
                        selected = predictions.loc[(predictions.case == case) & (predictions.doc_id == plan['doc_id']) &
                                                   (predictions.sector == sector) & (predictions.horizon == horizon) &
                                                   (predictions.family == family) & (predictions.variant == variant)]
                        if len(selected) != 1:
                            raise AssertionError('Missing candidate/fold record')
                        row = selected.iloc[0]
                        close(row.actual_pp, actual, 'Target membership')
                        close(row.historical_mean_pp, benchmark, 'Independent expanding benchmark')
                        close(row.training_events, len(y), 'Training announcement count')
                        for name, value in [('training_up', sum(v > 0 for v in y)),
                                            ('training_down', sum(v < 0 for v in y)),
                                            ('training_flat', sum(v == 0 for v in y))]:
                            close(row[name], value, name)
                        expected_majority = 1 if sum(v > 0 for v in y) >= sum(v < 0 for v in y) else -1
                        close(row.training_majority_sign, expected_majority, 'Past majority direction')
                        if row.training_cohort_sha256 != canonical_hash(plan['training_doc_ids']):
                            raise AssertionError('Saved model training cohort differs')
                        if row.last_training_label_end != plan['last_training_label_end']:
                            raise AssertionError('Saved training label end differs')
                        if family == 'historical_mean':
                            close(row.prediction_pp, benchmark, 'Mean reference')
                        elif family == 'zero_return':
                            close(row.prediction_pp, 0, 'Zero reference')
                    independent_benchmarks += 1
    if expected_grid != set(predictions[keys].itertuples(index=False, name=None)):
        raise AssertionError('Prediction grid contains unplanned/missing records')
    metric_keys = ['case', 'sector', 'horizon', 'family', 'variant']
    main = pd.read_csv(output/'metrics.csv', float_precision='round_trip')
    definitions = pd.read_csv(output/'metrics_by_definition.csv', float_precision='round_trip')
    compare_metric_table(predictions, main, metric_keys)
    compare_metric_table(predictions, definitions, metric_keys+['sector_definition'])
    direction = pd.read_csv(output/'direction_baselines.csv', float_precision='round_trip')
    baseline_count = 0
    for group_key, group in predictions.loc[predictions.family.eq('historical_mean')].groupby(metric_keys[:3], sort=True):
        for name, values in [('always_up', [1]*len(group)), ('always_down', [-1]*len(group)),
                             ('past_training_majority', group.training_majority_sign.tolist()),
                             ('historical_mean', group.historical_mean_pp.tolist()), ('zero_return', [0]*len(group))]:
            selected = direction.loc[direction.direction_baseline.eq(name)]
            for key, value in zip(metric_keys[:3], group_key):
                selected = selected.loc[selected[key].eq(value)]
            if len(selected) != 1:
                raise AssertionError('Missing/duplicate directional baseline')
            for metric, value in independent_direction(group.actual_pp.tolist(), values).items():
                close(selected.iloc[0][metric], value, 'Directional baseline '+metric)
            baseline_count += 1
    if len(direction) != baseline_count:
        raise AssertionError('Unexpected direction baseline groups')
    paired = pd.read_csv(output/'paired_text_differences.csv', float_precision='round_trip')
    paired_definition = pd.read_csv(output/'paired_text_differences_by_definition.csv', float_precision='round_trip')
    pair_keys = metric_keys[:3]+['family']
    check_pair_table(predictions, paired, pair_keys, frozen['specification']['paired_comparison'])
    check_pair_table(predictions, paired_definition, pair_keys+['sector_definition'], frozen['specification']['paired_comparison'])
    choices = pd.read_csv(output/'model_choices.csv', keep_default_na=False)
    learned = predictions.loc[predictions.variant.isin(['numerical', 'text_added'])]
    if len(choices) != frozen['derived_expected_counts']['learned_fits']:
        raise AssertionError('Incorrect derived learned fit count')
    if len(choices) != len(learned):
        raise AssertionError('Missing model choices')
    for row in choices.itertuples(index=False):
        expected = frozen['specification']['models'][row.family]
        if json.loads(row.settings_json) != expected or row.settings_sha256 != canonical_hash(expected):
            raise AssertionError('Candidate settings changed')
        if row.search_fits != 0 or row.candidate_configurations != 1:
            raise AssertionError('Unplanned hyperparameter selection')
        if sha256(ROOT/row.model_path) != row.model_sha256:
            raise AssertionError('Fitted model bytes changed')
    artifacts = check_pipeline_artifacts(predictions, frozen, snapshot)
    report = {'status': 'PASS', 'scope': 'Rerun owner self-check using separately coded arithmetic; independent review and source clocks/vintages not certified',
              'source_hashes_pass': True, 'complete_candidate_grid_pass': True,
              'paired_cohort_equality_pass': True, 'chronology_and_all_horizon_label_ends_pass': True,
              'nonfinite_guard_pass': True, 'predictions_checked': len(predictions),
              'independent_expanding_benchmarks': independent_benchmarks,
              'main_metric_rows_independently_recomputed': len(main),
              'definition_metric_rows_independently_recomputed': len(definitions),
              'direction_baseline_rows_independently_recomputed': baseline_count,
              'paired_rows_and_intervals_independently_recomputed': len(paired)+len(paired_definition),
              'model_choices_and_byte_hashes_checked': len(choices),
              'learned_processing': artifacts,
              'independent_target_alignment': target_checks,
              'all_existing_historical_tests_previously_inspected': True,
              'training_or_refitting_during_verification': False,
              'unverified': ['Original full-statement clocks and historical text vintages',
                             'Economic equivalence of legacy/live definitions',
                             'Every original text body and vendor close/source semantics'],
              'result_hashes_at_verification': {relative(p): sha256(p) for p in sorted(output.glob('*')) if p.is_file()}}
    atomic_json(output/'verification.json', report)
    print(json.dumps({k: v for k, v in report.items() if k != 'result_hashes_at_verification'}, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=RESULTS/'run_001')
    verify(parser.parse_args().output)
