"""Build and execute a saved-result companion without fitting or changing source data."""
from __future__ import annotations
import json, os, sys
from pathlib import Path
import nbformat
from nbclient import NotebookClient
from nbconvert import HTMLExporter
from utils import ROOT, RESULTS, METHODOLOGY, sha256, atomic_json, relative

OUT=RESULTS/'run_001'
if (OUT/'comparison.ipynb').exists():
    raise FileExistsError('Notebook already exists; preserve it')
kernels=OUT/'notebook_kernel'/'kernels'/'thesis-corrected'
kernels.mkdir(parents=True,exist_ok=False)
(kernels/'kernel.json').write_text(json.dumps({'argv':[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],'display_name':'Thesis corrected runtime','language':'python'}))
os.environ['JUPYTER_PATH']=str(OUT/'notebook_kernel')
md=nbformat.v4.new_markdown_cell
code=nbformat.v4.new_code_cell
cells=[
md('''# Corrected-backend forecast comparison

## tl;dr
This companion reads the completed corrected run and the retained 26 October results. The code cells below compute the size and direction of changes from the saved forecasts and tables. The independent run review is a separate gate and may still be pending.'''),
md('''## Context & Methods

The only intended empirical change is the corrected Word2Vec backend. All candidate settings, exact announcement splits, targets, inputs, past-only language rules and bootstrap are inherited from the 26 October frozen protocol. Four models use the same numerical inputs with and without four training-only text PCs. Historical mean and zero return are references. First-session return is primary; second session and two-session return are secondary. Negative text-minus-numerical MAE means lower text-added error.

### Key assumptions
The analysis is retrospective: original publication clocks and historical text vintages are not certified, all historical test outcomes have been inspected, and legacy and modern-live index definitions differ. The modern-live sensitivity is an overlapping subset, not an independent sample. The intervals are descriptive circular-block percentiles, not multiplicity-adjusted significance tests. Observed policy changes are not identified surprises; these forecasts do not establish causality, profits or financing constraints.'''),
code('''from pathlib import Path
import json, sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display
ROOT = Path.cwd()
OUT = ROOT/'06_results/model_comparison_corrected_2026-10-27/run_001'
protocol = json.loads((ROOT/'03_methodology/model_comparison_corrected_2026-10-27/frozen_protocol.json').read_text())
assert sys.executable == protocol['environment_at_freeze']['executable'], (sys.executable, protocol['environment_at_freeze']['executable'])
comparison = json.loads((OUT/'old_new_comparison.json').read_text())
metrics = pd.read_csv(OUT/'metrics.csv')
paired = pd.read_csv(OUT/'paired_text_differences.csv')
changes = pd.read_csv(OUT/'forecast_changes_by_group.csv')
plt.rcParams.update({'figure.figsize':(10,6), 'font.size':10, 'axes.spines.top':False, 'axes.spines.right':False, 'axes.grid':True, 'grid.alpha':.2})
print('Runtime:', sys.executable)
print('Original protocol SHA-256:', protocol['original_frozen_protocol_sha256'])
print('Dataset SHA-256:', protocol['dataset_manifest_sha256'])'''),
md('''## Data
The Refinitiv-only price dataset and original CBE statements are hash-pinned by the frozen protocol. Both sectors and all three return windows use the exact original 155-event common cohort; the modern-live case uses its own 56-event subset. Evaluation origins and fit counts are derived from the frozen splits.'''),
code('''display(pd.DataFrame([{'Case':k, 'Eligible announcements':v['events'], 'Evaluation origins':v['evaluation_events'], 'First event':v['first_event'], 'Last event':v['last_event']} for k,v in protocol['cohorts'].items()]))
print('Derived counts:', protocol['derived_expected_counts'])
print('Prediction rows compared:',comparison['forecast_rows_compared'])
print('Largest numerical/reference control change (percentage points):',comparison['control_max_abs_difference_pp'])
print('Text-added forecasts changed beyond tolerance:',comparison['text_forecasts_changed_over_tolerance'],'of',comparison['text_rows_compared'])'''),
md('''## Results
### Text-added versus numerical-only errors
The point estimates compare matched announcement forecasts. Whiskers show descriptive 95% circular moving-block bootstrap intervals; they are not evidence of a fresh untouched test.'''),
code('''families=['ridge','elastic_net','rbf_svr','random_forest']
labels=['Ridge','Elastic Net','RBF SVR','Random Forest']
fig, axes=plt.subplots(2,2,figsize=(11,7),sharex=True,constrained_layout=True)
for ax,(case,sector) in zip(axes.flat,[(c,s) for c in ['expanded_legacy_live','modern_live_only'] for s in ['banks','real_estate']]):
    d=paired[(paired.case==case)&(paired.sector==sector)&(paired.horizon=='first_session')].set_index('family').loc[families]
    y=np.arange(len(d)); est=d['MAE_difference_pp'].to_numpy(float)
    lo=d['MAE_difference_pp_low'].to_numpy(float); hi=d['MAE_difference_pp_high'].to_numpy(float)
    ax.hlines(y,lo,hi,color='#426788',lw=2); ax.scatter(est,y,color='#183b5b',zorder=3)
    ax.axvline(0,color='#555555',lw=1); ax.set_yticks(y,labels); ax.invert_yaxis()
    ax.set_title(('Expanded' if case.startswith('expanded') else 'Modern-live')+' • '+sector.replace('_',' ').title())
    ax.set_xlabel('Text minus numerical MAE (percentage points)')
fig.suptitle('First-session paired MAE differences • 95% descriptive block intervals')
fig.savefig(OUT/'primary_paired_mae.png',dpi=160,bbox_inches='tight')
plt.show()'''),
code('''primary=metrics[(metrics.horizon=='first_session') & (metrics.family.isin(['historical_mean','zero_return','ridge','elastic_net','rbf_svr','random_forest']))]
for (case,sector), g in primary.groupby(['case','sector'],sort=True):
    print(case, '—', sector, '(MAE/RMSE in percentage points)')
    display(g[['family','variant','test_events','MAE_pp','RMSE_pp','R2_OS','direction_accuracy','balanced_direction_accuracy']].round(4).reset_index(drop=True))'''),
md('''### Change caused by the corrected run
The full event-level comparison and all candidate/window/definition tables are saved beside this notebook. A near-zero control difference is expected; a changed text forecast is measured, not assumed to prove that the backend alone caused it, because the corrected build may carry compiler or dependency differences.'''),
code('''sel=changes[changes.variant.eq('text_added')]
fig,axes=plt.subplots(3,1,figsize=(11,13),sharex=True,constrained_layout=True)
for ax,horizon in zip(axes,['first_session','second_session','two_session']):
    items=sel[sel.horizon.eq(horizon)].sort_values(['case','sector','family'])
    names=(items['case'].str.replace('expanded_legacy_live','Expanded',regex=False).str.replace('modern_live_only','Modern',regex=False)+' / '+items['sector'].str.replace('_',' ',regex=False)+' / '+items['family'].str.replace('_',' ',regex=False))
    ax.barh(np.arange(len(items)),items['max_abs_change_pp'],color='#426788')
    ax.set_yticks(np.arange(len(items)),names,fontsize=9)
    ax.invert_yaxis(); ax.set_title(horizon.replace('_',' ').title())
    ax.set_xlabel('Maximum absolute forecast change (percentage points)')
fig.suptitle('Old versus corrected text-added forecasts • all model groups')
fig.savefig(OUT/'forecast_change_by_group.png',dpi=160,bbox_inches='tight')
plt.show()'''),
md('''## Takeaways
The following counts are computed from the saved corrected results. Their uncertainty and the inspected-history, source and index limitations above remain material. This is an exploratory predictive comparison, not a causal test.'''),
code('''p=paired[paired.horizon.eq('first_session')]
print('Primary comparisons with lower text-added MAE:', int((p.MAE_difference_pp < 0).sum()), 'of', len(p))
print('All-window comparisons with lower text-added MAE:', int((paired.MAE_difference_pp < 0).sum()), 'of', len(paired))
print('All-window descriptive MAE intervals containing zero:', int(((paired.MAE_difference_pp_low<=0)&(paired.MAE_difference_pp_high>=0)).sum()), 'of', len(paired))
print('Complete tables, forecasts, comparison files and the reproduction commands are in the run directory and README.')''')]
nb=nbformat.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'Thesis corrected runtime','language':'python','name':'thesis-corrected'},'language_info':{'name':'python'}})
nbformat.validate(nb)
client=NotebookClient(nb,timeout=180,kernel_name='thesis-corrected',resources={'metadata':{'path':str(ROOT)}})
client.execute()
nbformat.validate(nb)
nbformat.write(nb,OUT/'comparison.ipynb')
body,_=HTMLExporter().from_notebook_node(nb)
(OUT/'comparison.html').write_text(body,encoding='utf-8')
errors=[o for cell in nb.cells for o in cell.get('outputs',[]) if o.output_type=='error']
if errors: raise RuntimeError('Notebook has error outputs')
receipt={'status':'executed_top_to_bottom','kernel_executable':sys.executable,'code_cells':sum(c.cell_type=='code' for c in nb.cells),
         'errors':len(errors),'notebook_sha256':sha256(OUT/'comparison.ipynb'),'html_sha256':sha256(OUT/'comparison.html'),
         'figures':{p.name:sha256(p) for p in [OUT/'primary_paired_mae.png',OUT/'forecast_change_by_group.png']},
         'visual_inspection':'pending_separate_reading_size_check'}
atomic_json(OUT/'notebook_execution.json',receipt)
print(json.dumps(receipt,indent=2))
