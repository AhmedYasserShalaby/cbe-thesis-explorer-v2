# Corrected-backend same-specification comparison

This directory is a separate implementation derived from the 26 October saved study. Imports do not fit. The corrected runtime gate requires the backend owner's atomic `ready.json` and matching validator-owned `backend_acceptance.json`, checks their exact candidate binding, installed file hashes, imports, source/patch, native binary and arithmetic/public-API receipts, and refuses the original environment. The frozen protocol records all original settings and exact IDs, the accepted backend fingerprint, input and code hashes, and derived counts before fitting.

The following commands must be run from the thesis root with the exact accepted interpreter. The fitting command requires a new result/artifact directory and writes separately captured stdout and stderr. Never rerun the old entrypoints.

```sh
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python 05_analysis/model_comparison_corrected_2026-10-27/run_tests.py
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python 05_analysis/model_comparison_corrected_2026-10-27/experiment.py freeze
mkdir -p 06_results/model_comparison_corrected_2026-10-27/logs
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python -u 05_analysis/model_comparison_corrected_2026-10-27/experiment.py run > 06_results/model_comparison_corrected_2026-10-27/logs/run_001.stdout.log 2> 06_results/model_comparison_corrected_2026-10-27/logs/run_001.stderr.log
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python 05_analysis/model_comparison_corrected_2026-10-27/verify.py
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python 05_analysis/model_comparison_corrected_2026-10-27/compare_runs.py
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python 05_analysis/model_comparison_corrected_2026-10-27/author_notebook.py
# After actual inspection, write the visual_inspection.json receipt, then:
PYTHONHASHSEED=42 .venv_word2vec_corrected_2026-10-27/bin/python 05_analysis/model_comparison_corrected_2026-10-27/finalize.py
```

Do not repeat `freeze`, `run` or `finalize` into existing destinations. A future full numerical reproduction needs new result/model directories and the accepted unchanged runtime; the saved notebook reads results only. The saved run has since received independent computational acceptance; see `06_results/model_comparison_corrected_2026-10-27/ACCEPTED_STATUS.md` and the matching acceptance record. This is not a clean-environment reproduction claim.

Read `06_results/model_comparison_corrected_2026-10-27/ACCEPTED_STATUS.md` for the current accepted findings. Event-level, group-level, model and PC/encoder comparisons accompany the complete forecasts and metrics. No selected result is a fresh holdout; original clocks/vintages are unverified, the two cases overlap, old/live index definitions differ, and compiler/dependency differences must be considered when interpreting changes.
