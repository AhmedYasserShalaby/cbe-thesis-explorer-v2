# Research and AI assistance — corrected-backend rerun

27 October 2026: Codex (AI assistant) read the workspace context and correction contract, original 26 October protocol/run and code, Refinitiv data card and source reconciliation, and the independently reproduced Word2Vec defect. Began a separate same-specification implementation; the original sources and artifacts are read-only. This is a correctness rerun, not a search for favorable outputs. No empirical model has yet been fitted in this task. Backend readiness and independent validation are separate workers' gates; no acceptance is inferred from local preparation.

The independent backend acceptance and builder readiness matched and the runtime gate verified installed files, interpreter and imports, exact regression receipts and source/patch/binary hashes. The owner ran 21 synthetic failure/control tests and froze the unchanged original specification and split IDs before starting the bounded corrected fit. The AI assistant implemented the code; separate independent computational review of the completed empirical output is still required.

The existing corrected fit completed: 155 origins, 7,440 learned fits, 9,300 forecasts and 155 new encoder fits, with zero training-stderr bytes. No duplicate fitting was launched. Owner saved-output checks and the validator’s review remain pending.

The AI-assisted owner check recomputed the saved metrics/benchmarks and replayed 288 models; the full old/new grid and feature comparison then passed. Controls are exactly unchanged. The corrected build changed 298 of 3,720 text-added predictions beyond 1e-10 pp; the largest absolute change is 0.00913147 pp. This alone is not independent acceptance or proof that the patch, rather than any compiler/build difference, caused the changes.

The saved-result notebook was executed, its summary updated solely from the saved comparison tables, re-executed and visually inspected. Owner manifest version 1 hashed its own still-empty stdout file before printing its completion message; version 2 preserves v1 and binds the final log bytes. All 9,512 v2 artifact hashes were checked, with no empirical changes. The v2 manifest remains pending independent result acceptance.

Manifest version 3 places the preserved v1/v2 manifests in the explicit lineage rather than in the result-directory inventory, preserving exact membership for the independent checker. All 9,512 declared files and both prior manifest hashes match; numerical artifacts are unchanged.

The independent AI-assisted reviewer issued PASS_WITH_BOUNDS for manifest SHA-256 50adc12df0ca56b018de306a388f1e5f61ae1bd7918dd2bd71329e31a13b14cf. The acceptance and all referenced audit hashes were checked. This is computational acceptance within the retrospective bounds, not human academic approval or universal backend/source certification.
