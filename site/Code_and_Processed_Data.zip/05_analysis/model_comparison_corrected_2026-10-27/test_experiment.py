"""Focused synthetic tests. No real price data or historical model is fitted."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd

from data import validate_panel, grouped_splits, TARGETS, FEATURES
from experiment import run, estimator
from metrics import score, direction_stats, paired_statistics, paired_tables
from text_features import tokens, sentence_tokens, language_history, document_vector, FeatureManager
from utils import CODE, METHODOLOGY, RESULTS, ARTIFACTS, atomic_json, sha256, validate_hashes
from verify import compare_metric_table


def synthetic() -> tuple[pd.DataFrame, pd.DataFrame]:
    corpus, panel = [], []
    for index, date in enumerate(pd.date_range('2017-01-05', periods=9, freq='14D').strftime('%Y-%m-%d')):
        text = (f'The monetary policy committee holds stable interest rates. Inflation and market conditions remain stable {index}.'
                + ' inflation' * index)
        event = {'doc_id': f'synthetic_{index}', 'event_date': date, 'statement_text': text,
                 'statement_text_sha256': hashlib.sha256(text.encode()).hexdigest(),
                 'record_status': 'policy_statement_candidate', 'source_language': 'Official_English',
                 'source_url': 'synthetic://not-an-original-document'}
        corpus.append(event)
        day = pd.Timestamp(date)
        for sector in ['banks', 'real_estate']:
            panel.append({**event, 'sector': sector, 'sector_definition': 'legacy_2007',
                          'legacy_regime': 1, 'pre_return_start_date': str((day-pd.Timedelta(days=2)).date()),
                          'pre_return_end_date': str((day-pd.Timedelta(days=1)).date()),
                          'preceding_session_date': date,
                          'first_session_date': str((day+pd.Timedelta(days=3)).date()),
                          'second_session_date': str((day+pd.Timedelta(days=4)).date()),
                          'in_common_event_cohort': True, 'eligible_first_session': True,
                          'eligible_second_session': True, 'eligible_combined_two_session': True,
                          FEATURES[0]: 0.5 + index/10, FEATURES[1]: -0.1, FEATURES[2]: 0,
                          TARGETS['first_session']: 10.0, TARGETS['second_session']: -10.0,
                          TARGETS['two_session']: -1.0})
    return pd.DataFrame(panel), pd.DataFrame(corpus)


class DataAndSplitTests(unittest.TestCase):
    def test_common_grain_and_compounded_target(self):
        panel, corpus = synthetic()
        validate_panel(panel, corpus)
        panel.loc[0, TARGETS['two_session']] = 0  # Sum would be zero, compound is -1.
        with self.assertRaisesRegex(ValueError, 'compound'):
            validate_panel(panel, corpus)

    def test_feature_and_target_date_alignment(self):
        panel, corpus = synthetic()
        panel.loc[0, 'pre_return_end_date'] = panel.loc[0, 'event_date']
        with self.assertRaisesRegex(ValueError, 'Predictor'):
            validate_panel(panel, corpus)
        panel, corpus = synthetic()
        panel.loc[0, 'first_session_date'] = panel.loc[0, 'event_date']
        with self.assertRaisesRegex(ValueError, 'session ordering'):
            validate_panel(panel, corpus)

    def test_grouped_splits_and_all_horizon_label_availability(self):
        panel, _ = synthetic()
        first_eval_date = panel.loc[panel.doc_id.eq('synthetic_4'), 'event_date'].iloc[0]
        panel.loc[panel.doc_id.eq('synthetic_3'), 'second_session_date'] = first_eval_date
        plans = grouped_splits(panel, initial=3)
        plan = next(p for p in plans if p['doc_id'] == 'synthetic_4')
        self.assertNotIn('synthetic_3', plan['training_doc_ids'])
        self.assertEqual(plan['training_events'], 3)
        self.assertLess(plan['last_training_label_end'], plan['event_date'])
        for plan in plans:
            rows = panel.loc[panel.doc_id.isin(plan['training_doc_ids'])]
            self.assertTrue(rows.groupby('doc_id').size().eq(2).all())

    def test_duplicate_partial_missing_and_nonfinite_rejected(self):
        panel, corpus = synthetic()
        for damaged in [pd.concat([panel, panel.iloc[[0]]]), panel.iloc[1:].copy()]:
            with self.assertRaises(ValueError):
                validate_panel(damaged, corpus)
        panel.loc[0, FEATURES[0]] = np.nan
        with self.assertRaisesRegex(ValueError, 'Nonfinite'):
            validate_panel(panel, corpus)

    def test_crossing_boundary_and_legacy_mislabel_rejected(self):
        panel, corpus = synthetic()
        panel.loc[:1, 'second_session_date'] = '2020-01-02'
        with self.assertRaisesRegex(ValueError, 'boundary'):
            validate_panel(panel, corpus)
        panel, corpus = synthetic()
        panel.loc[0, 'legacy_regime'] = 0
        with self.assertRaisesRegex(ValueError, 'indicator'):
            validate_panel(panel, corpus)

    def test_text_hash_and_pair_membership_rejected(self):
        panel, corpus = synthetic()
        corpus.loc[0, 'statement_text'] += ' altered'
        with self.assertRaisesRegex(ValueError, 'hash'):
            validate_panel(panel, corpus)


class TextAndArtifactTests(unittest.TestCase):
    def test_tokenization_preserves_decimals_and_punctuation(self):
        self.assertEqual(tokens('Inflation: 12.5%!'), ['inflation', ':', '12.5', '%', '!'])
        self.assertEqual(len(sentence_tokens('Rate is 12.5 percent. Policy holds.')), 2)

    def test_future_current_admin_arabic_never_enter_language_history(self):
        _, corpus = synthetic()
        cutoff = corpus.event_date.iloc[5]
        original = language_history(corpus, cutoff)
        corpus.loc[corpus.event_date.ge(cutoff), 'statement_text'] = 'FUTURE_SENTINEL'
        pd.testing.assert_frame_equal(original, language_history(corpus, cutoff))
        corpus.loc[0, 'record_status'] = 'administrative_notice'
        corpus.loc[1, 'source_language'] = 'Official_Arabic'
        self.assertEqual(language_history(corpus, cutoff).doc_id.tolist(), ['synthetic_2', 'synthetic_3', 'synthetic_4'])

    def test_train_only_pca_coverage_and_validated_cache_bytes(self):
        panel, corpus = synthetic()
        config = json.loads((METHODOLOGY/'protocol_specification.json').read_text())['text']
        with tempfile.TemporaryDirectory(prefix='synthetic_', dir=CODE) as temporary:
            base = Path(temporary)
            manager = FeatureManager(corpus, config, {'synthetic': 'no-real-prices'}, base/'cache', {'synthetic_backend_sha256': 'fixture'})
            plan = grouped_splits(panel, 4)[0]
            pcs, current, receipt = manager.fold(plan, base/'fold')
            self.assertEqual(pcs.shape, (4, 4))
            self.assertEqual(current.shape, (1, 4))
            self.assertEqual(receipt['training_doc_ids'], plan['training_doc_ids'])
            self.assertNotIn(plan['doc_id'], receipt['training_doc_ids'])
            wv, _, model_path = manager.encoder(plan['event_date'], plan['training_doc_ids'])
            _, coverage = document_vector(wv, 'monetary unknown_synthetic_token')
            self.assertGreater(coverage['unknown_tokens'], 0)
            with self.assertRaisesRegex(ValueError, 'Zero'):
                document_vector(wv, 'zzzzzzsyntheticonly')
            with model_path.open('ab') as stream:
                stream.write(b'tamper')
            with self.assertRaisesRegex(ValueError, 'bytes mismatch'):
                manager.encoder(plan['event_date'], plan['training_doc_ids'])

    def test_hash_and_atomic_overwrite_guards(self):
        with tempfile.TemporaryDirectory(dir=CODE) as temporary:
            directory = Path(temporary)
            path = directory/'record.json'
            atomic_json(path, {'complete': True})
            validate_hashes({'record.json': sha256(path)}, root=directory)
            with self.assertRaises(FileExistsError):
                atomic_json(path, {'changed': True})
            with self.assertRaises(ValueError):
                validate_hashes({'record.json': '0'*64}, root=directory)

    def test_real_run_refuses_existing_output_before_fitting(self):
        with self.assertRaisesRegex(FileExistsError, 'existing'):
            run(RESULTS, ARTIFACTS/'never_created_by_test')


class EvaluationTests(unittest.TestCase):
    def test_independent_verifier_rejects_missing_and_nonfinite_metric_rows(self):
        group = pd.DataFrame({'case':['x']*3, 'sector':['banks']*3,
                              'horizon':['first_session']*3, 'family':['ridge']*3,
                              'variant':['numerical']*3,
                              'actual_pp':[1.,-1.,0.], 'prediction_pp':[0.,-1.,1.],
                              'historical_mean_pp':[.2,.1,.1]})
        keys = ['case','sector','horizon','family','variant']
        table = pd.DataFrame([{**dict(zip(keys,['x','banks','first_session','ridge','numerical'])),
                               **score(group.actual_pp,group.prediction_pp,group.historical_mean_pp)}])
        compare_metric_table(group, table, keys)
        with self.assertRaises(AssertionError):
            compare_metric_table(group, table.iloc[0:0], keys)
        table.loc[0,'MAE_pp'] = np.nan
        with self.assertRaises(AssertionError):
            compare_metric_table(group, table, keys)

    def test_zero_denominator_direction_zero_and_class_counts(self):
        record = score([0, 0], [0, 0], [0, 0])
        self.assertIsNone(record['R2_OS'])
        self.assertIsNone(record['direction_accuracy'])
        direction = direction_stats([1, -1, 0, 1], [0, -1, 1, 1])
        self.assertEqual(direction['actual_up'], 2)
        self.assertEqual(direction['actual_down'], 1)
        self.assertEqual(direction['actual_flat'], 1)
        self.assertEqual(direction['direction_correct'], 2)
        self.assertAlmostEqual(direction['direction_accuracy'], 2/3)
        self.assertAlmostEqual(direction['balanced_direction_accuracy'], .75)
        self.assertIsNone(direction_stats([1, 2], [1, 1])['balanced_direction_accuracy'])

    def test_expanding_mean_denominator_not_test_mean(self):
        record = score([1, 3], [2, 2], [0, 1])
        self.assertEqual(record['expanding_mean_SSE_pp2'], 5)
        self.assertAlmostEqual(record['R2_OS'], .6)

    def test_nonfinite_predictions_and_pairing_fail_closed(self):
        with self.assertRaises(ValueError):
            score([1], [np.nan], [0])
        rows = []
        for variant, doc in [('numerical', 'a'), ('text_added', 'b')]:
            rows.append({'case': 'x', 'sector': 'banks', 'horizon': 'first_session', 'family': 'ridge',
                         'variant': variant, 'doc_id': doc, 'event_date': '2020-01-01',
                         'actual_pp': 1, 'prediction_pp': 0, 'historical_mean_pp': 0,
                         'sector_definition': 'modern', 'training_cohort_sha256': 'same'})
        with self.assertRaisesRegex(ValueError, 'cohort'):
            paired_tables(pd.DataFrame(rows), {'replicates': 20, 'block_length': 5, 'seed': 42})

    def test_block_interval_is_paired_and_negative_means_improvement(self):
        result = paired_statistics([1, 2, 3], [0, 1, 2], [1, 2, 3], replicates=100)
        self.assertEqual(result['MAE_difference_pp'], -1)
        self.assertEqual(result['MAE_difference_pp_low'], -1)
        self.assertEqual(result['RMSE_difference_pp'], -1)

    def test_all_fixed_candidate_families_run_on_synthetic_train_only_features(self):
        specification = json.loads((METHODOLOGY/'protocol_specification.json').read_text())
        rng = np.random.default_rng(42)
        x, y = rng.normal(size=(40, 7)), rng.normal(size=40)
        for family, settings in specification['models'].items():
            model = estimator(family, settings).fit(x, y)
            self.assertTrue(np.isfinite(model.predict(x[:1])).all())


class CorrectedComparisonTests(unittest.TestCase):
    def test_grid_cohort_and_control_drift_fail_closed(self):
        from compare_runs import join_predictions, validate_controls
        row = {'case':'x','doc_id':'a','sector':'banks','horizon':'first_session',
               'family':'ridge','variant':'numerical','event_date':'2020-01-01',
               'sector_definition':'modern','training_cohort_sha256':'cohort', 'training_events':20,
               'last_training_label_end':'2019-12-30','preceding_session_date':'2019-12-31',
               'first_session_date':'2020-01-02','second_session_date':'2020-01-03',
               'target_label_end':'2020-01-02','actual_pp':1.,'historical_mean_pp':.2,'prediction_pp':.1}
        old = pd.DataFrame([row]); changed = old.copy()
        joined = join_predictions(old, changed, 1)
        self.assertEqual(validate_controls(joined)[1], 0)
        changed.loc[0,'doc_id']='b'
        with self.assertRaisesRegex(ValueError, 'grid'):
            join_predictions(old, changed, 1)
        changed=old.copy();changed.loc[0,'training_cohort_sha256']='other'
        with self.assertRaisesRegex(ValueError, 'cohort'):
            join_predictions(old, changed, 1)
        changed=old.copy();changed.loc[0,'prediction_pp']=.10001
        with self.assertRaisesRegex(ValueError, 'controls changed'):
            validate_controls(join_predictions(old, changed, 1))
        changed=old.copy();changed.loc[0,'prediction_pp']=float('nan')
        with self.assertRaisesRegex(ValueError, 'Nonfinite'):
            join_predictions(old, changed, 1)

    def test_absent_readiness_fails_closed(self):
        from unittest.mock import patch
        import runtime_gate
        with tempfile.TemporaryDirectory(dir=CODE) as temporary:
            base=Path(temporary)
            with patch.object(runtime_gate,'READY',base/'missing_ready.json'), patch.object(runtime_gate,'ACCEPTANCE',base/'missing_acceptance.json'):
                with self.assertRaisesRegex(RuntimeError, 'readiness'):
                    runtime_gate.verify_runtime()

    def test_wrong_interpreter_and_unaccepted_candidate_fail_closed(self):
        from unittest.mock import patch
        import runtime_gate
        with self.assertRaisesRegex(ValueError, 'Interpreter'):
            runtime_gate.verify_candidate({'python_executable':'/unapproved/python', 'python_version':'not-the-runtime'})
        with tempfile.TemporaryDirectory(dir=CODE) as temporary:
            base=Path(temporary)
            ready=base/'ready.json'; acceptance=base/'acceptance.json'; candidate=base/'candidate.json'
            ready.write_text(json.dumps({'ready_for_corrected_rerun':True}))
            acceptance.write_text(json.dumps({'accepted':False}))
            candidate.write_text('{}')
            with patch.object(runtime_gate,'READY',ready), patch.object(runtime_gate,'ACCEPTANCE',acceptance), patch.object(runtime_gate,'CANDIDATE',candidate):
                with self.assertRaisesRegex(RuntimeError, 'did not accept'):
                    runtime_gate.verify_runtime()

    def test_backend_fingerprint_and_cohort_enter_cache_identity(self):
        panel, corpus = synthetic()
        config=json.loads((METHODOLOGY/'protocol_specification.json').read_text())['text']
        plan=grouped_splits(panel,4)[0]
        with tempfile.TemporaryDirectory(dir=CODE) as temporary:
            base=Path(temporary)
            first=FeatureManager(corpus,config,{'synthetic':'fixture'},base/'cache',{'binary':'a'})
            _, first_receipt, _=first.encoder(plan['event_date'],plan['training_doc_ids'])
            _, cohort_receipt, _=first.encoder(plan['event_date'],plan['training_doc_ids'][:-1])
            second=FeatureManager(corpus,config,{'synthetic':'fixture'},base/'cache',{'binary':'b'})
            _, backend_receipt, _=second.encoder(plan['event_date'],plan['training_doc_ids'])
            self.assertNotEqual(first_receipt['key_sha256'],cohort_receipt['key_sha256'])
            self.assertNotEqual(first_receipt['key_sha256'],backend_receipt['key_sha256'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
