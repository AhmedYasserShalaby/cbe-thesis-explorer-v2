"""Reconcile every saved forecast, metric and text feature with the retained run; never fit."""
from __future__ import annotations
import csv
import gzip
import json
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from gensim.models import KeyedVectors
from utils import ROOT, RESULTS, METHODOLOGY, sha256, atomic_json, relative

OLD = ROOT/'06_results/model_comparison_2026-10-26/run_001'
OLD_ART = ROOT/'05_analysis/models/model_comparison_2026-10-26/run_001'
KEYS = ['case', 'doc_id', 'sector', 'horizon', 'family', 'variant']
GROUP = ['case', 'sector', 'horizon', 'family', 'variant']
CONTROL_TOL_PP = 1e-10  # Well below the displayed precision; allows ordinary float arithmetic variation.


def read_csv(p):
    return pd.read_csv(p, float_precision='round_trip', keep_default_na=False)


def magnitude(a):
    a = np.asarray(a, float)
    if not np.isfinite(a).all():
        raise ValueError('Nonfinite comparison input')
    return float(np.linalg.norm(a)), float(np.max(np.abs(a))) if a.size else 0.0


def compare_table(name, keys, out):
    before, after = read_csv(OLD/name), read_csv(out/name)
    if before.duplicated(keys).any() or after.duplicated(keys).any():
        raise ValueError(f'Duplicate metric keys: {name}')
    joined = before.merge(after, on=keys, how='outer', suffixes=('_old', '_corrected'), indicator=True, validate='one_to_one')
    if not joined['_merge'].eq('both').all():
        raise ValueError(f'Metric grid changed: {name}')
    for col in before.columns.difference(keys):
        a, b = col+'_old', col+'_corrected'
        if a not in joined or b not in joined:
            continue
        oldn, newn = pd.to_numeric(joined[a], errors='coerce'), pd.to_numeric(joined[b], errors='coerce')
        if ((oldn.notna() | joined[a].eq('')) & (newn.notna() | joined[b].eq(''))).all():
            joined[col+'_change'] = newn-oldn
    joined.drop(columns='_merge').to_csv(out/('old_new_'+name), index=False, float_format='%.17g')
    return len(joined)


def join_predictions(old, new, expected_count):
    if old.duplicated(KEYS).any() or new.duplicated(KEYS).any():
        raise ValueError('Duplicate prediction keys')
    joined = old.merge(new, on=KEYS, suffixes=('_old','_corrected'), how='outer', indicator=True, validate='one_to_one')
    if len(joined) != expected_count or not joined['_merge'].eq('both').all():
        raise ValueError('Old and corrected prediction grids differ')
    for col in ['event_date','sector_definition','training_cohort_sha256','training_events','last_training_label_end',
                'preceding_session_date','first_session_date','second_session_date','target_label_end']:
        if not joined[col+'_old'].eq(joined[col+'_corrected']).all():
            raise ValueError(f'Control cohort or target metadata changed: {col}')
    for col in ['actual_pp','historical_mean_pp']:
        if not np.allclose(joined[col+'_old'].astype(float), joined[col+'_corrected'].astype(float), atol=CONTROL_TOL_PP, rtol=0):
            raise ValueError(f'Control actual or historical mean changed: {col}')
    joined['prediction_change_pp'] = joined.prediction_pp_corrected.astype(float)-joined.prediction_pp_old.astype(float)
    if not np.isfinite(joined['prediction_change_pp']).all():
        raise ValueError('Nonfinite forecast changes')
    return joined



def validate_controls(joined):
    controls = joined[joined.variant.isin(['numerical','reference'])]
    if controls.empty:
        raise ValueError('No numerical/reference controls')
    maximum = float(controls.prediction_change_pp.abs().max())
    if not np.isfinite(maximum) or maximum > CONTROL_TOL_PP:
        raise ValueError(f'Numerical/reference controls changed beyond {CONTROL_TOL_PP}: {maximum} pp; investigate before attribution')
    return controls, maximum


def compare(out: Path):
    out = out.resolve()
    if not out.is_relative_to(RESULTS.resolve()):
        raise ValueError('Results must remain in corrected results directory')
    frozen = json.loads((METHODOLOGY/'frozen_protocol.json').read_text())
    new_art = ROOT / json.loads((out/'computation_manifest.json').read_text())['artifact_directory']
    old, new = read_csv(OLD/'predictions.csv'), read_csv(out/'predictions.csv')
    joined = join_predictions(old, new, frozen['derived_expected_counts']['forecasts'])
    joined.drop(columns='_merge').to_csv(out/'old_new_predictions.csv',index=False,float_format='%.17g')
    group = joined.groupby(GROUP, sort=True)['prediction_change_pp'].agg(
        observations='size', mean_change_pp='mean', max_abs_change_pp=lambda x: np.max(np.abs(x)),
        mean_abs_change_pp=lambda x: np.mean(np.abs(x)), changed_over_1e_10=lambda x: (np.abs(x)>CONTROL_TOL_PP).sum()).reset_index()
    group.to_csv(out/'forecast_changes_by_group.csv',index=False,float_format='%.17g')
    controls, controls_max = validate_controls(joined)
    metrics = {}
    for file, keys in [('metrics.csv',GROUP), ('metrics_by_definition.csv',GROUP+['sector_definition']),
                       ('direction_baselines.csv',['case','sector','horizon','direction_baseline']),
                       ('paired_text_differences.csv',['case','sector','horizon','family']),
                       ('paired_text_differences_by_definition.csv',['case','sector','horizon','family','sector_definition'])]:
        metrics[file] = compare_table(file, keys, out)
    fold_rows, doc_rows = [], []
    token_path = out/'encoder_token_changes.csv.gz'
    with gzip.open(token_path,'wt',newline='',encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(['case','event_date','token','status','old_norm','corrected_norm','delta_l2','delta_max_abs','cosine_similarity'])
        for case, plans in frozen['splits'].items():
            for plan in plans:
                old_dir = OLD_ART/case/plan['event_date']
                new_dir = new_art/case/plan['event_date']
                om, nm = [json.loads((d/'feature_manifest.json').read_text()) for d in (old_dir,new_dir)]
                if om['training_doc_ids'] != nm['training_doc_ids'] or om['training_doc_ids'] != plan['training_doc_ids']:
                    raise ValueError('Text feature cohorts differ')
                oa, na = [np.load(d/'features.npz',allow_pickle=False) for d in (old_dir,new_dir)]
                if oa['training_doc_ids'].tolist() != na['training_doc_ids'].tolist():
                    raise ValueError('Text vectors are not paired by document')
                ow, nw = [KeyedVectors.load(str(ROOT/m['encoder_path'])) for m in (om,nm)]
                shared = sorted(set(ow.index_to_key)&set(nw.index_to_key))
                union = sorted(set(ow.index_to_key)|set(nw.index_to_key))
                token_delta_max, token_changed = 0., 0
                for word in union:
                    if word not in ow or word not in nw:
                        writer.writerow([case,plan['event_date'],word,'old_only' if word in ow else 'corrected_only','','','','',''])
                        continue
                    a, b = np.asarray(ow[word],float), np.asarray(nw[word],float)
                    l2, maxabs = magnitude(b-a)
                    an, bn = float(np.linalg.norm(a)), float(np.linalg.norm(b))
                    cosine = float(a@b/(an*bn)) if an and bn else ''
                    writer.writerow([case,plan['event_date'],word,'both',an,bn,l2,maxabs,cosine])
                    token_delta_max = max(token_delta_max,maxabs)
                    token_changed += maxabs > 0
                for doc, av, bv, ap, bp, kind in list(zip(plan['training_doc_ids'],oa['training_vectors'],na['training_vectors'],oa['training_components'],na['training_components'],['training']*len(plan['training_doc_ids']))) + [(plan['doc_id'],oa['test_vector'],na['test_vector'],oa['test_components'][0],na['test_components'][0],'test')]:
                    l2, maxabs = magnitude(bv-av)
                    delta = np.asarray(bp)-np.asarray(ap)
                    magnitude(delta)
                    row = {'case':case,'event_date':plan['event_date'],'doc_id':doc,'role':kind,
                           'document_vector_delta_l2':l2,'document_vector_delta_max_abs':maxabs}
                    for i in range(4):
                        row[f'PC{i+1}_old'] = float(ap[i]); row[f'PC{i+1}_corrected'] = float(bp[i]); row[f'PC{i+1}_change'] = float(delta[i])
                    doc_rows.append(row)
                op, npca = [joblib.load(d/'training_pca.joblib') for d in (old_dir,new_dir)]
                row = {'case':case,'event_date':plan['event_date'],'old_vocabulary':len(ow),'corrected_vocabulary':len(nw),
                       'shared_vocabulary':len(shared),'vocabulary_union':len(union),'tokens_changed':token_changed,
                       'token_component_max_abs_change':token_delta_max,
                       'old_encoder_sha256':om['encoder_sha256'],'corrected_encoder_sha256':nm['encoder_sha256'],
                       'old_test_known_fraction':om['test_coverage']['known_token_fraction'],
                       'corrected_test_known_fraction':nm['test_coverage']['known_token_fraction'],
                       'old_pca_variance_sum':sum(om['pca_explained_variance_ratio']),
                       'corrected_pca_variance_sum':sum(nm['pca_explained_variance_ratio'])}
                for i in range(4):
                    row[f'PC{i+1}_loading_cosine'] = float(op.components_[i]@npca.components_[i])
                    row[f'PC{i+1}_old_variance_ratio'] = float(op.explained_variance_ratio_[i])
                    row[f'PC{i+1}_corrected_variance_ratio'] = float(npca.explained_variance_ratio_[i])
                fold_rows.append(row)
    pd.DataFrame(doc_rows).to_csv(out/'document_vector_pc_changes.csv.gz',index=False,compression='gzip',float_format='%.17g')
    pd.DataFrame(fold_rows).to_csv(out/'encoder_pca_changes_by_fold.csv',index=False,float_format='%.17g')
    text = joined[joined.variant.eq('text_added')]
    report = {'status':'PASS','forecast_rows_compared':len(joined),'control_rows_compared':len(controls),
              'control_max_abs_difference_pp':controls_max,'control_tolerance_pp':CONTROL_TOL_PP,
              'text_rows_compared':len(text),'text_max_abs_forecast_difference_pp':float(text.prediction_change_pp.abs().max()),
              'text_forecasts_changed_over_tolerance':int(text.prediction_change_pp.abs().gt(CONTROL_TOL_PP).sum()),
              'folds_compared':len(fold_rows),'document_vector_rows_compared':len(doc_rows),
              'metric_rows_compared':metrics,'token_change_table':relative(token_path),
              'model_pickle_byte_equality_not_required':True,
              'pca_component_sign_caveat':'Raw PC and loading differences include arbitrary component orientation; compare forecasts and saved transforms as well.',
              'attribution_limit':'Observed differences may also reflect compiler, binary or dependency changes; no clean-environment replication claimed.'}
    atomic_json(out/'old_new_comparison.json',report)
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=RESULTS/'run_001')
    compare(parser.parse_args().output)
