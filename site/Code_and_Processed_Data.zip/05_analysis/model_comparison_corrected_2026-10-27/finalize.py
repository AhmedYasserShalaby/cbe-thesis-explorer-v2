"""Publish the owner's manifest only after saved computation, self-check and actual visual inspection."""
from __future__ import annotations
import json, re, sys
from pathlib import Path
import pandas as pd
from utils import ROOT, CODE, RESULTS, ARTIFACTS, METHODOLOGY, sha256, relative, atomic_json, validate_hashes
from experiment import check_originals
from runtime_gate import verify_runtime

OUT=RESULTS/'run_001'
MANIFEST=RESULTS/'run_manifest.json'
if MANIFEST.exists(): raise FileExistsError('Preserve the existing run manifest')
frozen_path=METHODOLOGY/'frozen_protocol.json'
frozen=json.loads(frozen_path.read_text())
if verify_runtime()!=frozen['backend_binding']: raise ValueError('Runtime binding changed')
validate_hashes(frozen['input_hashes']);validate_hashes(frozen['executable_source_hashes'])
original,old_run=check_originals()
compute=json.loads((OUT/'computation_manifest.json').read_text())
verify=json.loads((OUT/'verification.json').read_text())
compare=json.loads((OUT/'old_new_comparison.json').read_text())
tests=json.loads((RESULTS/'synthetic_tests.json').read_text())
notebook=json.loads((OUT/'notebook_execution.json').read_text())
visual=json.loads((OUT/'visual_inspection.json').read_text())
for label,obj in [('verification',verify),('comparison',compare),('tests',tests),('visual',visual)]:
    if obj['status']!='PASS': raise ValueError(f'{label} did not pass')
if notebook['status']!='executed_top_to_bottom' or notebook['errors']!=0: raise ValueError('Notebook not executed cleanly')
if sha256(OUT/'comparison.ipynb')!=notebook['notebook_sha256'] or sha256(OUT/'comparison.html')!=notebook['html_sha256']:
    raise ValueError('Notebook changed after execution')
if visual['notebook_sha256']!=notebook['notebook_sha256'] or visual['html_sha256']!=notebook['html_sha256']:
    raise ValueError('Visual inspection refers to different notebook bytes')
for name,digest in notebook['figures'].items():
    if sha256(OUT/name)!=digest or visual['figures'].get(name)!=digest: raise ValueError('Figure differs from visual inspection')
logs=RESULTS/'logs'
stdout=logs/'run_001.stdout.log';stderr=logs/'run_001.stderr.log'
err=stderr.read_text(encoding='utf-8',errors='replace')
ignored=len(re.findall(r'Exception ignored in:',err))
our_dot=len(re.findall(r"Exception ignored in:\s*['\"]gensim\.models\.word2vec_inner\.our_dot_float",err))
python_warning_lines=sum(bool(re.search(r'\b(?:UserWarning|RuntimeWarning|DeprecationWarning|FutureWarning|ConvergenceWarning):',line)) for line in err.splitlines())
warning_rows=json.loads((OUT/'warnings.json').read_text())
if ignored: raise ValueError(f'{ignored} native/ignored exceptions in captured training stderr; investigate')
if compute['learned_model_fits']!=frozen['derived_expected_counts']['learned_fits'] or compute['prediction_rows']!=frozen['derived_expected_counts']['forecasts']:
    raise ValueError('Count mismatch')
paired=pd.read_csv(OUT/'paired_text_differences.csv')
primary=paired.loc[paired.horizon.eq('first_session')]
text_changes=compare['text_forecasts_changed_over_tolerance']
readme=f'''# Corrected-backend forecast comparison — 27 October 2026

**Computational work complete; independent run review pending.** The corrected run uses the unchanged original frozen data, event IDs, grouped splits, model/feature settings and metrics, with newly trained corrected-backend encoders and newly fitted training-only PCA/scalers/models. No earlier learned artifact was reused. The previous study and its manifests remain intact. This is a retrospective comparison of previously inspected historical outcomes, not an untouched holdout or real-time certification.

{compute['evaluation_origins']} evaluation origins produced {compute['learned_model_fits']} fitted candidates and {compute['prediction_rows']} forecasts. All {compare['control_rows_compared']} numerical/reference forecasts were compared with the prior run; their maximum absolute change was {compare['control_max_abs_difference_pp']:.12g} percentage points (tolerance {compare['control_tolerance_pp']:.1g}). {text_changes} of {compare['text_rows_compared']} text-added forecasts changed beyond that tolerance; maximum absolute change was {compare['text_max_abs_forecast_difference_pp']:.8g} percentage points.

Text-added MAE was lower in {int((primary.MAE_difference_pp<0).sum())}/{len(primary)} first-session model/sector/case comparisons and {int((paired.MAE_difference_pp<0).sum())}/{len(paired)} across all predefined windows. {int(((paired.MAE_difference_pp_low<=0)&(paired.MAE_difference_pp_high>=0)).sum())}/{len(paired)} all-window descriptive 95% block intervals include zero. These counts are descriptive and use overlapping cases and inspected history. See the full paired tables rather than interpreting this as an untouched or multiplicity-adjusted significance test. Negative text-minus-numerical values indicate lower text loss.

All original release clocks and historical text vintages remain unverified; the price/session evidence and actual index-definition boundaries remain as documented. Observed rate decisions are not policy surprises. No causality, trading profitability, measured capital constraint or general text-gain claim follows. The corrected build and dependency/compiler differences mean observed changes cannot automatically be attributed solely to the source patch. Model pickle byte identity is not required. No clean-environment retraining or human academic approval is claimed.

Full saved outputs: `run_001/predictions.csv`, `metrics.csv`, `metrics_by_definition.csv`, `direction_baselines.csv`, `paired_text_differences*.csv`, `old_new_predictions.csv`, `forecast_changes_by_group.csv`, `old_new_*.csv`, `encoder_token_changes.csv.gz`, `document_vector_pc_changes.csv.gz`, `encoder_pca_changes_by_fold.csv`. The executed `run_001/comparison.ipynb`/HTML and figures read only saved artifacts. Raw captured training stdout/stderr are in `logs/`; there were {ignored} ignored native exceptions and {len(warning_rows)} captured estimator warnings. No observations or source values were enriched.

Frozen protocol: `../../03_methodology/model_comparison_corrected_2026-10-27/frozen_protocol.json`. Exact environment, code, input and artifact hashes and commands are in `run_manifest.json`. The independent validator owns the separate `04_data/verification/word2vec_corrected_review_2026-10-27/acceptance.json` and may request repairs; check it for the reviewed manifest hash before treating this run as accepted.
'''
(RESULTS/'RESULTS.md').write_text(readme,encoding='utf-8')
paths=[]
for folder in [OUT,ARTIFACTS/'run_001',ARTIFACTS/'encoder_cache',RESULTS/'logs']:
    paths.extend(p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.partial'))
paths.extend([RESULTS/'RESULTS.md',RESULTS/'synthetic_tests.json',frozen_path,METHODOLOGY/'FROZEN_PROTOCOL.md',METHODOLOGY/'protocol_specification.json'])
artifacts={relative(p):{'sha256':sha256(p),'bytes':p.stat().st_size} for p in sorted(set(paths))}
manifest={'status':'completed_self_checked_pending_independent_review','independent_run_review':'pending_validator_acceptance',
          'original_run_manifest':relative(ROOT/'06_results/model_comparison_2026-10-26/run_manifest.json'),
          'original_run_manifest_sha256':frozen['original_run_manifest_sha256'],'original_artifacts_verified_unchanged':len(old_run['all_actual_artifact_hashes']),
          'frozen_protocol':relative(frozen_path),'frozen_protocol_sha256':sha256(frozen_path),
          'dataset_manifest':frozen['dataset_manifest_path'],'dataset_manifest_sha256':frozen['dataset_manifest_sha256'],
          'input_and_source_hashes':frozen['input_hashes'],'executable_source_hashes':frozen['executable_source_hashes'],
          'runtime_binding':frozen['backend_binding'],'actual_environment':compute['environment'],
          'counts':frozen['derived_expected_counts'],'computation':compute,'self_verification':verify,
          'old_new_comparison':compare,'synthetic_tests':tests,'notebook_execution':notebook,'visual_inspection':visual,
          'training_output_capture':{'stdout_path':relative(stdout),'stdout_sha256':sha256(stdout),'stderr_path':relative(stderr),'stderr_sha256':sha256(stderr),
               'ignored_exception_count':ignored,'our_dot_float_ignored_exception_count':our_dot,'python_warning_lines_in_stderr':python_warning_lines,
               'estimator_warnings_captured_separately':len(warning_rows)},
          'all_actual_artifact_hashes':artifacts,'total_hashed_artifacts':len(artifacts),
          'previous_learned_artifacts_reused':False,'clean_environment_retraining_claim':False,'untouched_test_claim':False,
          'real_time_release_certified':False,'causal_or_profitable_trading_claim':False,'external_upload_or_submission':False,
          'limits':['Original clocks and historical text vintages unverified','Legacy and modern-live index definitions differ','Previously inspected test outcomes','Small overlapping cases and descriptive intervals','Compiler and dependency differences are possible confounds'],
          'commands':{'tests':f'PYTHONHASHSEED=42 {sys.executable} {relative(CODE/"run_tests.py")}',
                      'freeze':f'PYTHONHASHSEED=42 {sys.executable} {relative(CODE/"experiment.py")} freeze',
                      'run':f'PYTHONHASHSEED=42 {sys.executable} {relative(CODE/"experiment.py")} run',
                      'verify':f'PYTHONHASHSEED=42 {sys.executable} {relative(CODE/"verify.py")}',
                      'compare':f'PYTHONHASHSEED=42 {sys.executable} {relative(CODE/"compare_runs.py")}',
                      'notebook':f'PYTHONHASHSEED=42 {sys.executable} {relative(CODE/"author_notebook.py")}'}}
atomic_json(MANIFEST,manifest)
print(json.dumps({'status':manifest['status'],'manifest':relative(MANIFEST),'sha256':sha256(MANIFEST),'hashed_artifacts':len(artifacts),'ignored_exception_count':ignored},indent=2))
