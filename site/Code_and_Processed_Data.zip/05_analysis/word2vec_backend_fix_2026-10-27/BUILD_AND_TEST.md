# Isolated Gensim 4.4.0 correction

The candidate is `.venv_word2vec_corrected_2026-10-27/bin/python` in this workspace. The unpatched control is `.venv_word2vec_control_2026-10-27/bin/python`. `candidate.json` is the immutable review handoff; it does **not** authorize a model rerun by itself. The independent validator owns `04_data/verification/word2vec_corrected_review_2026-10-27/backend_acceptance.json`; `ready.json` can be issued only after a matching acceptance. The source and patch are local; neither the original environment nor empirical inputs/results were intentionally altered.

## Source and changes

- [PyPI Gensim 4.4.0 source distribution](https://pypi.org/project/gensim/4.4.0/) SHA-256 `a3f5b626da5518e79a479140361c663089fe7998df8ba52d56e1ded71ac5bdf5`. The retained tarball and PyPI metadata are in this directory.
- Release tag `4.4.0` is annotated tag object `f95d6315e3ac8dea64e27301ad14a98beea2a233`, targeting commit `ee2642b4fa26e689ba4595067504668bc7a89016`. The sdist has generated `fastss.c` but no `fastss.pyx`; the [tag's file at that exact commit](https://raw.githubusercontent.com/piskvorky/gensim/ee2642b4fa26e689ba4595067504668bc7a89016/gensim/similarities/fastss.pyx), SHA-256 `28ef4b96570b64b674959f7900cc8786ab22df0c5871b6b9c9ee75a8a0241d1e`, was added to *both* source builds solely so its Python 3.13-compatible C could be regenerated.
- `gensim-4.4.0-blas-noexcept.patch` changes exactly the `sdot_ptr` and `dsdot_ptr` declarations from `except -1 nogil` to `noexcept nogil`. All `.pyx`/`.pxd` files in the two prepared source trees were compared: only `word2vec_inner.pxd` differs. [Issue 3665](https://github.com/piskvorky/gensim/issues/3665) and [PR 3668](https://github.com/piskvorky/gensim/pull/3668) were open when checked on 27 October 2026; the proposal is not an official release.
- The 4.4.0 tarball's old generated C failed on the original Python 3.13 C API. All ten C/C++ extensions were regenerated with the same Cython 3.3.0 in each build. The successful builds used Apple clang 21.0.0, Xcode macOS SDK 26.5, setuptools 80.9.0, wheel 0.45.1 and uv 0.9.25. The initial build's SDK 27 linker failure and next attempt's Python C API failure are retained in `build_control_stderr.txt` and `build_control_retry_stderr.txt`; no global tool or package was changed.
- `requirements-model.txt` records the 67 installed model/notebook dependencies pinned from the original environment. All distribution-recorded runtime files of 15 core model/notebook packages, including NumPy, SciPy, scikit-learn, pandas and their native binaries, matched the original and control byte-for-byte; see `dependency_identity.json`. The isolated runtimes add pinned Cython/setuptools/wheel/pytest/testfixtures and omit unrelated original packages. Gensim's rebuilt binaries necessarily differ from the original wheel; matching-source unpatched controls address this confound.

## Commands

Run from the workspace root. All of the following use local files or official PyPI; package installation is confined to the named virtual environment. The recorded successful commands were:

```bash
BASE=/Users/ahmedyasser/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13
SDKROOT=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX26.5.sdk
uv venv --python "$BASE" --no-python-downloads .venv_word2vec_corrected_2026-10-27
uv venv --python "$BASE" --no-python-downloads .venv_word2vec_control_2026-10-27
uv pip install --python .venv_word2vec_corrected_2026-10-27/bin/python --link-mode copy -r 05_analysis/word2vec_backend_fix_2026-10-27/requirements-model.txt 'Cython==3.3.0' 'setuptools==80.9.0' 'wheel==0.45.1' 'pytest==8.4.2'
uv pip install --python .venv_word2vec_control_2026-10-27/bin/python --link-mode copy -r 05_analysis/word2vec_backend_fix_2026-10-27/requirements-model.txt 'Cython==3.3.0' 'setuptools==80.9.0' 'wheel==0.45.1' 'pytest==8.4.2'
uv pip install --python .venv_word2vec_corrected_2026-10-27/bin/python --link-mode copy 'testfixtures==8.3.0'
uv pip install --python .venv_word2vec_control_2026-10-27/bin/python --link-mode copy 'testfixtures==8.3.0'
```

The archive was separately extracted to `source/unpatched` and `source/patched`, the identical released `fastss.pyx` copied to both, and the two-line patch applied only to `source/patched`. In each source tree, `regenerate_cython.py` was run with its corresponding virtual-environment interpreter. Successful builds set the SDK and one-thread limits, then used `uv pip install --no-cache --no-build-isolation --no-deps --verbose` on the corresponding local source tree. Full command forms, including this preparation, are captured in the non-overwriting rebuild script:

```bash
bash 05_analysis/word2vec_backend_fix_2026-10-27/rebuild_isolated.sh my_new_check patched
bash 05_analysis/word2vec_backend_fix_2026-10-27/rebuild_isolated.sh my_control_check unpatched
```

Each command refuses an existing name and writes its environment, source and regression receipts only under this role's `rebuild/` directory. Rebuilding can produce different extension bytes because compiler build paths and toolchain details enter the artifacts; compare behavior and record fresh hashes rather than replacing the reviewed candidate. The original generated environment and its own receipts remain authoritative for the independent gate.

The patched rebuild command was executed as `reproducibility_check`: all 144 regression cases passed and captured native stderr was empty. Its Word2Vec extension SHA-256 was `7a52efd36c74d7c2dc3d0dc1eaedd123a894369f3ec917978b4764d40dc0271b`, different from the reviewed candidate's `9ea9ca8c490720ec63839da0abb71a79b44fad1d9d7d6b610a033c47c95b1c35`; this demonstrates why a new build must be independently fingerprinted instead of silently substituted. Rebuild command stdout/stderr are under `04_data/verification/word2vec_backend_fix_2026-10-27/rebuild_check_*`, with the new environment and test JSON under `rebuild/reproducibility_check/`.

The performed regression command, with `PYTHON` set to each of the original, control and corrected interpreters and `LABEL` set accordingly, was:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=42 "$PYTHON" 05_analysis/word2vec_backend_fix_2026-10-27/regression_math.py \
  > "04_data/verification/word2vec_backend_fix_2026-10-27/regression_${LABEL}_stdout.json" \
  2> "04_data/verification/word2vec_backend_fix_2026-10-27/regression_${LABEL}_stderr.txt"
```

The original/control exit code is **1, expected** because the assertions identify wrong numeric outputs; the corrected exit code is 0. The focused upstream command was:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
NUMEXPR_NUM_THREADS=1 PYTHONHASHSEED=42 PYTHONDONTWRITEBYTECODE=1 \
TMPDIR="$PWD/04_data/verification/word2vec_backend_fix_2026-10-27/upstream_tmp" \
.venv_word2vec_corrected_2026-10-27/bin/python -m pytest -q -s --pyargs gensim.test.test_word2vec
```

The actual runs redirected stdout and stderr to the versioned verification directory. The first suite run had 79 pass, 4 skip and one failed nondeterministic 4-worker neighbor-ranking test (rank 6 versus <6). The corresponding individual test subsequently passed once in the unpatched control and once in the corrected build. A full corrected-suite retry reported **80 passed, 4 skipped**, with two captured deprecation warnings; native stderr was empty on both runs. The first failure is retained and remains a real limitation on the suite's repeatability. The upstream test itself intentionally uses four training workers; BLAS threads were limited to one, and the thesis algorithm uses one training worker.

## What the arithmetic checks establish

The active `FAST_VERSION=1` path calls the float-return pointer derived from SciPy `_fblas.sdot`; `otool` shows that binary links Apple Accelerate. Its SHA-256 is identical in all three environments. `regression_math.py` tests 60 float32 dot products over widths 1, 2, 4, 8 and 100 and three positive-stride combinations, including exact −1, −0.5, 0 and +1. Python double-precision `math.fsum` supplies the independent arithmetic oracle. Only the 15 exact −1 cases fail in both original and control; all 60 pass corrected.

The synthetic two-word public `Word2Vec.score` cases cover CBOW and skip-gram, widths 1/4/100 and dot products ±2/±1/±0.5/0. Opposing Huffman codes imply equal total log scores under a sign flip; 6 of 18 symmetry cases fail only at magnitude 1 on the two bugged runtimes. The independent ideal log-sigmoid sum is checked with tolerance 0.04 because Gensim's finite, discretized lookup table differs from the continuous sigmoid; the symmetry check uses 1e-6 and does not depend on that tolerance.

The public `Word2Vec.train` cases use CBOW negative sampling with controlled two-word vocabulary/weights and a forced negative draw that is skipped for the first positive target. The first context update is independently predicted as `1 + alpha * (1 - sigmoid(dot)) * dot`. Six exact −1 cases (three widths, both CBOW mean modes) fail in both original and unpatched builds and pass corrected; all nearby controls pass within 0.001 for the finite lookup table. These are synthetic tests, not thesis model fitting. Corrected C-level stderr is empty for the 144-case run; original and control stderr contains the reproduced exception text.

The probes do not test the alternate double-return ABI, other platforms, or every possible input. The empirical magnitude of the thesis effect is a separate question. The inventory and `check_runtime_inventory.py` bind package bytes excluding disposable bytecode caches, plus the interpreter and `pyvenv.cfg`; see `runtime_inventory.json` and the verification receipts for the detailed hashes.
