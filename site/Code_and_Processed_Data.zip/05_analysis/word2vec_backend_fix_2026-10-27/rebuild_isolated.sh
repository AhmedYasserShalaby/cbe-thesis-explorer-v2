#!/bin/bash
# Rebuild in this role's own rebuild/ directory. Never overwrites an existing runtime.
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "$0")" && pwd)"
WORKSPACE_DIR="$(cd "$BACKEND_DIR/../.." && pwd)"
NAME="${1:-}"
if [[ ! "$NAME" =~ ^[a-zA-Z0-9_-]+$ ]]; then
  echo "Usage: $0 NEW_REBUILD_NAME [patched|unpatched]" >&2
  exit 2
fi
VARIANT="${2:-patched}"
if [[ "$VARIANT" != patched && "$VARIANT" != unpatched ]]; then
  echo "Variant must be patched or unpatched" >&2
  exit 2
fi
OUT="$BACKEND_DIR/rebuild/$NAME"
if [[ -e "$OUT" ]]; then
  echo "Refusing to overwrite $OUT" >&2
  exit 2
fi
BASE_PYTHON="/Users/ahmedyasser/.local/share/uv/python/cpython-3.13.5-macos-aarch64-none/bin/python3.13"
SDKROOT="/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX26.5.sdk"
export SDKROOT OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 UV_CONCURRENT_BUILDS=1 MAKEFLAGS=-j1 PYTHONHASHSEED=42
[[ -x "$BASE_PYTHON" && -d "$SDKROOT" ]] || { echo 'Required interpreter or SDK is unavailable' >&2; exit 2; }

test "$(shasum -a 256 "$BACKEND_DIR/gensim-4.4.0.tar.gz" | cut -d' ' -f1)" = a3f5b626da5518e79a479140361c663089fe7998df8ba52d56e1ded71ac5bdf5
test "$(shasum -a 256 "$BACKEND_DIR/fastss-4.4.0-commit.pyx" | cut -d' ' -f1)" = 28ef4b96570b64b674959f7900cc8786ab22df0c5871b6b9c9ee75a8a0241d1e
mkdir -p "$OUT/source"
tar -xzf "$BACKEND_DIR/gensim-4.4.0.tar.gz" -C "$OUT/source" --strip-components=1
cp "$BACKEND_DIR/fastss-4.4.0-commit.pyx" "$OUT/source/gensim/similarities/fastss.pyx"
if [[ "$VARIANT" == patched ]]; then
  patch -d "$OUT/source" -p1 < "$BACKEND_DIR/gensim-4.4.0-blas-noexcept.patch"
fi
uv venv --python "$BASE_PYTHON" --no-python-downloads "$OUT/venv"
uv pip install --python "$OUT/venv/bin/python" --link-mode copy -r "$BACKEND_DIR/requirements-model.txt" \
  'Cython==3.3.0' 'setuptools==80.9.0' 'wheel==0.45.1' 'pytest==8.4.2' 'testfixtures==8.3.0'
(cd "$OUT/source" && "$OUT/venv/bin/python" "$BACKEND_DIR/regenerate_cython.py")
uv pip install --python "$OUT/venv/bin/python" --link-mode copy --no-cache --no-build-isolation --no-deps --verbose "$OUT/source"
set +e
PYTHONDONTWRITEBYTECODE=1 "$OUT/venv/bin/python" "$BACKEND_DIR/regression_math.py" > "$OUT/regression_stdout.json" 2> "$OUT/regression_stderr.txt"
RESULT=$?
set -e
printf 'regression_exit=%s\n' "$RESULT" > "$OUT/exit_status.txt"
if [[ "$VARIANT" == patched && "$RESULT" != 0 ]]; then exit "$RESULT"; fi
if [[ "$VARIANT" == unpatched && "$RESULT" == 0 ]]; then
  echo 'Unpatched negative control unexpectedly passed; inspect its outputs.' >&2
  exit 1
fi
echo "Build and captured regression: $OUT; check all receipts and compare bytes before use."
