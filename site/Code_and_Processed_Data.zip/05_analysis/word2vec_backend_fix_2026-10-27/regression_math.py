#!/usr/bin/env python3
"""Bounded mathematical checks: C wrapper plus public Word2Vec score and train.

Run in a separate, thread-limited process; capture OS-level stdout and stderr.
The expected values use Python arithmetic and the sigmoid, not Gensim's table.
Gensim's float32 lookup table introduces a small documented approximation.
The negative controls are intentionally expected to exit nonzero.
"""
import ctypes as ct
import hashlib
import json
import math
import platform
import sys
from pathlib import Path

import gensim
import numpy as np
import scipy
from gensim.models import Word2Vec, word2vec_inner
from scipy.linalg import _fblas
from threadpoolctl import threadpool_info


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def capsule_address(capsule):
    name = ct.pythonapi.PyCapsule_GetName
    name.argtypes, name.restype = [ct.py_object], ct.c_char_p
    ptr = ct.pythonapi.PyCapsule_GetPointer
    ptr.argtypes, ptr.restype = [ct.py_object, ct.c_char_p], ct.c_void_p
    signature = name(capsule)
    return signature.decode() if signature else None, ptr(capsule, signature)


def scalar_cases():
    sig, address = capsule_address(word2vec_inner.__pyx_capi__['our_dot_float'])
    integer, real = ct.POINTER(ct.c_int), ct.POINTER(ct.c_float)
    function = ct.CFUNCTYPE(ct.c_float, integer, real, integer, real, integer)(address)
    results = []
    for width in (1, 2, 4, 8, 100):
        for inc_x, inc_y in ((1, 1), (2, 3), (3, 2)):
            for target in (-1.0, -0.5, 0.0, 1.0):
                used = min(width, 4)
                x_values = [1.0 / used] * used + [0.0] * (width - used)
                y_values = [target] * used + [0.0] * (width - used)
                # Exercise arithmetic beyond the first four lanes with exact cancellation.
                for i in range(4, width - 1, 2):
                    x_values[i:i + 2] = [0.25, -0.25]
                    y_values[i:i + 2] = [1.0, 1.0]
                x = (ct.c_float * (1 + (width - 1) * inc_x))()
                y = (ct.c_float * (1 + (width - 1) * inc_y))()
                for i in range(width):
                    x[i * inc_x], y[i * inc_y] = x_values[i], y_values[i]
                expected = math.fsum(float(x[i * inc_x]) * float(y[i * inc_y]) for i in range(width))
                assert expected == target
                n, sx, sy = ct.c_int(width), ct.c_int(inc_x), ct.c_int(inc_y)
                actual = float(function(ct.byref(n), x, ct.byref(sx), y, ct.byref(sy)))
                results.append({'width': width, 'inc_x': inc_x, 'inc_y': inc_y,
                                'dtype': 'float32', 'expected': expected, 'actual': actual,
                                'pass': actual == expected})
    return sig, results


def scoring_cases():
    results = []
    for sg in (0, 1):
        for width in (1, 4, 100):
            for dot in (-2.0, -1.0, -0.5, 0.0, 0.5, 1.0, 2.0):
                model = Word2Vec(vector_size=width, window=1, min_count=1, workers=1,
                                 sg=sg, hs=1, negative=0, sample=0, seed=42)
                model.build_vocab([['alpha', 'beta']])
                codes = [model.wv.get_vecattr(word, 'code') for word in ('alpha', 'beta')]
                points = [model.wv.get_vecattr(word, 'point') for word in ('alpha', 'beta')]
                assert [len(c) for c in codes] == [1, 1]
                assert int(codes[0][0]) + int(codes[1][0]) == 1
                assert int(points[0][0]) == int(points[1][0])
                model.wv.vectors[:] = 0.0
                model.syn1[:] = 0.0
                count = min(width, 4)
                model.wv.vectors[:, :count] = dot / count
                model.syn1[int(points[0][0]), :count] = 1.0
                actual = float(model.score([['alpha', 'beta']], total_sentences=1, chunksize=1)[0])
                expected = -math.log1p(math.exp(-dot)) - math.log1p(math.exp(dot))
                results.append({'sg': sg, 'width': width, 'dot': dot, 'expected_log_sigmoid_sum': expected,
                                'actual': actual, 'abs_error': abs(actual - expected),
                                'tolerance_for_lookup_table': 0.04,
                                'pass': abs(actual - expected) < 0.04})
    return results


def training_cases():
    results = []
    alpha = 0.1
    for cbow_mean in (0, 1):
        for width in (1, 4, 100):
            for dot in (-1.0, -0.5, 0.0, 1.0):
                model = Word2Vec(vector_size=width, window=1, min_count=1, workers=1,
                                 sg=0, hs=0, negative=1, sample=0, seed=42,
                                 sorted_vocab=0, shrink_windows=False, cbow_mean=cbow_mean)
                sentence = ['alpha', 'beta']
                model.build_vocab([sentence])
                assert model.wv.key_to_index == {'alpha': 0, 'beta': 1}
                model.wv.vectors[:] = 0.0
                model.syn1neg[:] = 0.0
                model.wv.vectors[1, 0] = 1.0
                model.syn1neg[0, 0] = dot
                # Force each negative draw to alpha. For the first positive target,
                # alpha, that draw is skipped; beta's input vector is updated once.
                model.cum_table[:] = np.uint32(2**31 - 1)
                model.train([sentence], total_examples=1, epochs=1,
                            start_alpha=alpha, end_alpha=alpha)
                actual = float(model.wv['beta'][0])
                sigmoid = 1.0 / (1.0 + math.exp(-dot))
                expected = 1.0 + alpha * (1.0 - sigmoid) * dot
                results.append({'cbow_mean': cbow_mean, 'width': width, 'dot': dot,
                                'expected_updated_context': expected, 'actual': actual,
                                'abs_error': abs(actual - expected),
                                'tolerance_for_lookup_table': 0.001,
                                'pass': abs(actual - expected) < 0.001})
    return results


signature, direct = scalar_cases()
scores, training = scoring_cases(), training_cases()
symmetry = []
for sg in (0, 1):
    for width in (1, 4, 100):
        for magnitude in (0.5, 1.0, 2.0):
            positive = next(r['actual'] for r in scores if (r['sg'], r['width'], r['dot']) == (sg, width, magnitude))
            negative = next(r['actual'] for r in scores if (r['sg'], r['width'], r['dot']) == (sg, width, -magnitude))
            symmetry.append({'sg': sg, 'width': width, 'magnitude': magnitude,
                             'positive_score': positive, 'negative_score': negative,
                             'expected_difference': 0.0, 'difference': abs(positive - negative),
                             'pass': abs(positive - negative) < 1e-6})
fblas_signature, _ = capsule_address(_fblas.sdot._cpointer)
counts = {name: {'total': len(rows), 'passed': sum(row['pass'] for row in rows),
                 'failed': sum(not row['pass'] for row in rows)}
          for name, rows in [('direct_float32', direct), ('public_score', scores),
                             ('public_score_sign_symmetry', symmetry), ('public_cbow_train', training)]}
report = {'python': sys.version, 'python_executable': sys.executable, 'platform': platform.platform(),
          'gensim': gensim.__version__, 'numpy': np.__version__, 'scipy': scipy.__version__,
          'word2vec_module': word2vec_inner.__file__, 'word2vec_sha256': digest(word2vec_inner.__file__),
          'scipy_fblas_module': _fblas.__file__, 'scipy_fblas_sha256': digest(_fblas.__file__),
          'gensim_float_wrapper_signature': signature, 'scipy_sdot_capsule_signature': fblas_signature,
          'FAST_VERSION': word2vec_inner.FAST_VERSION, 'threadpools': threadpool_info(),
          'dtype_scope': 'Gensim Word2Vec/SDOT input arrays are float32; the independent oracle uses Python double precision. The alternate double-return ABI is not selected here.',
          'counts': counts, 'direct_float32': direct, 'public_score': scores,
          'public_score_sign_symmetry': symmetry, 'public_cbow_train': training}
print(json.dumps(report, indent=2, allow_nan=False))
sys.exit(0 if word2vec_inner.FAST_VERSION == 1 and all(v['failed'] == 0 for v in counts.values()) else 1)
