"""Small deterministic I/O helpers; importing this module never fits or writes."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CODE = Path(__file__).resolve().parent
METHODOLOGY = ROOT / '03_methodology/model_comparison_2026-10-26'
RESULTS = ROOT / '06_results/model_comparison_2026-10-26'
ARTIFACTS = ROOT / '05_analysis/models/model_comparison_2026-10-26'


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def atomic_json(path: Path, value, *, replace: bool = False) -> None:
    """Publish complete bytes; default refuses any previous destination."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.partial-{os.getpid()}')
    payload = json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False,
                         allow_nan=False) + '\n'
    with temporary.open('x', encoding='utf-8') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        if replace:
            os.replace(temporary, path)
        else:
            os.link(temporary, path)  # Atomic creation also refuses overwrite races.
    finally:
        temporary.unlink(missing_ok=True)


def relative(path: Path) -> str:
    return str(path.resolve().relative_to(ROOT))


def source_hashes() -> dict[str, str]:
    return {relative(p): sha256(p) for p in sorted(CODE.glob('*.py'))}


def environment() -> dict:
    names = ['numpy', 'pandas', 'scipy', 'scikit-learn', 'gensim', 'joblib',
             'threadpoolctl', 'nbformat', 'nbclient', 'nbconvert', 'ipykernel',
             'jupyter-client', 'pyarrow', 'matplotlib']
    return {'python': sys.version, 'executable': sys.executable,
            'platform': platform.platform(), 'machine': platform.machine(),
            'packages': {name: importlib.metadata.version(name) for name in names},
            'thread_environment': {k: os.environ.get(k) for k in
                                   ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                                    'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS',
                                    'NUMEXPR_NUM_THREADS', 'PYTHONHASHSEED']}}


def validate_hashes(expected: dict[str, str], root: Path = ROOT) -> None:
    for name, expected_hash in expected.items():
        path = (root / name).resolve()
        if not path.is_relative_to(root.resolve()):
            raise ValueError(f'Input outside workspace: {name}')
        if not path.is_file() or sha256(path) != expected_hash:
            raise ValueError(f'Source bytes changed or missing: {name}')


def historical_preservation_hashes() -> dict[str, str]:
    """Separate preservation inventory, never a source of new model features."""
    folders = ['04_data/processed', '05_analysis/models', '06_results',
               '05_analysis/baseline_tools', '05_analysis/embedding_tools',
               '05_analysis/review_tools', '05_analysis/notebooks']
    paths = []
    for folder in folders:
        for path in (ROOT/folder).rglob('*'):
            if not path.is_file() or path.name == '.DS_Store' or '__pycache__' in path.parts:
                continue
            if 'model_comparison_2026-10-26' in path.parts or 'refinitiv_only_2026-10-26' in path.parts:
                continue
            paths.append(path)
    return {relative(p): sha256(p) for p in sorted(set(paths))}
