"""Execute focused synthetic tests and save an exact non-overwriting receipt."""
from __future__ import annotations
import argparse
import time
import unittest
from pathlib import Path
from utils import CODE, RESULTS, atomic_json, source_hashes, environment

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, default=RESULTS/'synthetic_tests.json')
    args = parser.parse_args()
    if args.report.exists():
        raise FileExistsError('Preserve the existing test receipt; choose a new report path')
    started = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(CODE), pattern='test_experiment.py'))
    atomic_json(args.report, {'status': 'PASS' if result.wasSuccessful() else 'FAIL',
                             'tests_run': result.testsRun, 'failures': len(result.failures),
                             'errors': len(result.errors), 'skipped': len(result.skipped),
                             'elapsed_seconds': time.monotonic()-started,
                             'command': ['.venv_thesis_data/bin/python', '05_analysis/model_comparison_2026-10-26/run_tests.py'],
                             'source_hashes_at_tests': source_hashes(), 'environment': environment(),
                             'scope': 'Synthetic controls only; no actual price/outcome model fitted'})
    raise SystemExit(0 if result.wasSuccessful() else 1)
