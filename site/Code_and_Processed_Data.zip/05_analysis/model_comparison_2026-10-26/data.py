"""Strict hash-pinned Refinitiv handover loader and common grouped split plan."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from utils import ROOT, sha256, relative, validate_hashes

SECTORS = ('banks', 'real_estate')
HORIZONS = ('first_session', 'second_session', 'two_session')
TARGETS = {'first_session': 'first_session_return_pct',
           'second_session': 'second_session_return_pct',
           'two_session': 'combined_two_session_return_pct'}
FEATURES = ['pre_event_sector_return_pct', 'pre_event_egx30_return_pct',
            'reported_rate_change_bps']
EXPECTED_MAPPING = {
    'event_id': 'doc_id', 'meeting_date': 'event_date', 'text': 'statement_text',
    'text_sha256': 'statement_text_sha256', 'source_url': 'source_url',
    'sector': 'sector', 'definition': 'sector_definition',
    'policy_change_bps': 'reported_rate_change_bps',
    'lagged_sector_return_pct': FEATURES[0], 'lagged_egx30_return_pct': FEATURES[1],
    'prior_feature_start': 'pre_return_start_date',
    'prior_feature_end': 'pre_return_end_date',
    'preceding_session': 'preceding_session_date',
    'first_session': 'first_session_date', 'second_session': 'second_session_date',
    'first_target_pct': TARGETS['first_session'],
    'second_target_pct': TARGETS['second_session'],
    'combined_target_pct': TARGETS['two_session'],
    'first_eligible': 'eligible_first_session', 'second_eligible': 'eligible_second_session',
    'combined_eligible': 'eligible_combined_two_session',
    'common_cohort': 'in_common_event_cohort'}


def boolean(series: pd.Series) -> pd.Series:
    text = series.astype(str).str.lower()
    if not text.isin(['true', 'false', '1', '0']).all():
        raise ValueError(f'Invalid/missing boolean field: {series.name}')
    return text.isin(['true', '1'])


def declared_hashes(value) -> dict[str, str]:
    """Read only explicit path/hash declarations, including nested source receipts."""
    found = {}
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            found[value['path']] = value['sha256']
        if isinstance(value.get('source_file'), str) and isinstance(value.get('sha256'), str):
            found[value['source_file']] = value['sha256']
        for key in ['input_hashes', 'source_hashes', 'raw_source_hashes']:
            if isinstance(value.get(key), dict):
                for path, digest in value[key].items():
                    if isinstance(digest, str) and len(digest) == 64:
                        found[path] = digest
        for item in value.values():
            if isinstance(item, (dict, list)):
                for path, digest in declared_hashes(item).items():
                    if path in found and found[path] != digest:
                        raise ValueError(f'Conflicting manifest hashes: {path}')
                    found[path] = digest
    elif isinstance(value, list):
        for item in value:
            for path, digest in declared_hashes(item).items():
                if path in found and found[path] != digest:
                    raise ValueError(f'Conflicting manifest hashes: {path}')
                found[path] = digest
    return found


def artifact_path(hashes: dict, stem: str) -> Path:
    paths = [ROOT / name for name in hashes if Path(name).stem == stem]
    if len(paths) != 1:
        raise ValueError(f'Need one manifest-declared {stem} artifact, found {paths}')
    return paths[0]


@dataclass
class Snapshot:
    manifest_path: Path
    manifest: dict
    hashes: dict
    panel: pd.DataFrame
    corpus: pd.DataFrame
    daily: pd.DataFrame


def validate_panel(panel: pd.DataFrame, corpus: pd.DataFrame) -> None:
    required = ['doc_id', 'event_date', 'sector', 'sector_definition', 'legacy_regime',
                'statement_text', 'statement_text_sha256', 'pre_return_start_date',
                'pre_return_end_date', 'preceding_session_date', 'first_session_date',
                'second_session_date', 'in_common_event_cohort', 'eligible_first_session',
                'eligible_second_session', 'eligible_combined_two_session'] + FEATURES + list(TARGETS.values())
    if not set(required).issubset(panel.columns):
        raise ValueError(f'Missing panel fields: {set(required)-set(panel.columns)}')
    if panel.duplicated(['doc_id', 'sector']).any():
        raise ValueError('Duplicate announcement-sector rows')
    if corpus.doc_id.duplicated().any() or corpus.doc_id.isna().any():
        raise ValueError('Duplicate/missing corpus IDs')
    if not panel.doc_id.isin(corpus.doc_id).all():
        raise ValueError('Unmatched corpus IDs')
    for frame in [panel, corpus]:
        real = frame.statement_text.map(lambda t: hashlib.sha256(str(t).encode()).hexdigest())
        if not real.eq(frame.statement_text_sha256).all():
            raise ValueError('Statement text hash mismatch')
    lookup = corpus.set_index('doc_id')
    for name in ['event_date', 'statement_text_sha256']:
        if not panel[name].eq(panel.doc_id.map(lookup[name])).all():
            raise ValueError(f'Panel/corpus mismatch: {name}')
    common = panel.loc[boolean(panel.in_common_event_cohort)].copy()
    if common.empty:
        raise ValueError('Empty common cohort')
    for _, group in panel.groupby('doc_id'):
        if boolean(group.in_common_event_cohort).nunique() != 1:
            raise ValueError('Partial announcement common eligibility')
    if not common.groupby('doc_id').sector.apply(lambda s: set(s) == set(SECTORS) and len(s) == 2).all():
        raise ValueError('Both sectors required for every common announcement')
    if not common.groupby('doc_id').event_date.nunique().eq(1).all():
        raise ValueError('Inconsistent announcement dates')
    if common[['doc_id', 'event_date']].drop_duplicates().event_date.duplicated().any():
        raise ValueError('Multiple statements on one date need explicit combined treatment')
    numeric = common[FEATURES + list(TARGETS.values()) + ['legacy_regime']].to_numpy(float)
    if not np.isfinite(numeric).all():
        raise ValueError('Nonfinite common inputs/targets')
    for name in ['eligible_first_session', 'eligible_second_session', 'eligible_combined_two_session']:
        if not boolean(common[name]).all():
            raise ValueError('Ineligible target in common cohort')
    if not (common.pre_return_start_date < common.pre_return_end_date).all():
        raise ValueError('Feature dates reversed')
    if not (common.pre_return_end_date < common.event_date).all():
        raise ValueError('Predictor date not strictly earlier than statement date')
    if not (common.preceding_session_date <= common.event_date).all():
        raise ValueError('Preceding price after statement date')
    if not ((common.event_date < common.first_session_date) &
            (common.first_session_date < common.second_session_date)).all():
        raise ValueError('Target session ordering')
    # Exclude any return/predictor that straddles the documented definition break.
    first = common.pre_return_start_date
    last = common.second_session_date
    crosses = (first < '2020-01-02') & (last >= '2020-01-02')
    if crosses.any():
        raise ValueError('Common cohort crosses legacy/live definition boundary')
    if not common.legacy_regime.isin([0, 1]).all():
        raise ValueError('Invalid definition indicator')
    if not common.legacy_regime.eq((common.second_session_date < '2020-01-02').astype(int)).all():
        raise ValueError('Legacy indicator inconsistent with live boundary')
    compounded = 100 * ((1 + common[TARGETS['first_session']] / 100) *
                        (1 + common[TARGETS['second_session']] / 100) - 1)
    if not np.allclose(compounded, common[TARGETS['two_session']], atol=2e-10, rtol=0):
        raise ValueError('Combined target does not compound')
    # Equal cohort/session definitions across sectors: the announcement is the split unit.
    for name in ['event_date', 'sector_definition', 'legacy_regime', 'first_session_date',
                 'second_session_date', 'pre_return_start_date', 'pre_return_end_date']:
        if not common.groupby('doc_id')[name].nunique().eq(1).all():
            raise ValueError(f'Cross-sector alignment mismatch: {name}')


def load_snapshot(manifest_path: Path) -> Snapshot:
    expected = ROOT / '04_data/processed/refinitiv_only_2026-10-26/dataset_manifest.json'
    if manifest_path.resolve() != expected.resolve():
        raise ValueError('Only the authorized versioned Refinitiv manifest is accepted')
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('ready_for_retrospective_modeling') is not True:
        raise ValueError('Atomic manifest is not ready for retrospective modeling')
    if manifest.get('status') != 'validated_retrospective_static_dataset':
        raise ValueError('Unvalidated manifest status')
    if manifest.get('validation', {}).get('failed_checks') or not manifest.get('validation', {}).get('passed_checks'):
        raise ValueError('Manifest does not declare passing validation')
    mapping = manifest.get('mapping', manifest.get('column_mapping', {}))
    if mapping and any(mapping.get(k) != v for k, v in EXPECTED_MAPPING.items()):
        raise ValueError('Dataset mapping differs from frozen loader schema')
    hashes = declared_hashes(manifest)
    if not hashes:
        raise ValueError('Manifest contains no explicit hashed inputs')
    hashes = {relative(ROOT/name): digest for name, digest in hashes.items()}
    hashes[relative(manifest_path)] = sha256(manifest_path)
    validate_hashes(hashes)
    source_manifest_path = artifact_path(hashes, 'source_manifest')
    inherited = declared_hashes(json.loads(source_manifest_path.read_text()))
    for name, digest in inherited.items():
        normalized = relative(ROOT/name)
        if normalized in hashes and hashes[normalized] != digest:
            raise ValueError('Declared source has conflicting hashes')
        hashes[normalized] = digest
    validate_hashes(hashes)
    panel_path = artifact_path(hashes, 'event_sector_modeling')
    # Names bound to the actual handover before freezing, never old-panel fallbacks.
    corpus_path = artifact_path(hashes, 'original_text_inventory')
    daily_path = artifact_path(hashes, 'daily_prices')
    panel = pd.read_csv(panel_path, keep_default_na=False)
    corpus = pd.read_csv(corpus_path, keep_default_na=False)
    daily = pd.read_csv(daily_path, keep_default_na=False)
    # Full-inventory rows intentionally retain missing numeric cells. Coerce only
    # declared numeric fields; never impute or turn missing prices into zeros.
    numeric_fields = FEATURES + list(TARGETS.values()) + ['legacy_regime']
    numeric_fields += [name for name in panel if name.endswith('_sector_close') or name.endswith('_egx30_close')]
    for name in numeric_fields:
        panel[name] = pd.to_numeric(panel[name].replace('', np.nan), errors='raise')
    validate_panel(panel, corpus)
    profiles = manifest.get('raw_sources', [])
    if {(p['instrument'], p['ric']) for p in profiles} != {('banks', '.EGBANK'), ('real_estate', '.EGREAL'), ('egx30', '.EGX30')}:
        raise ValueError('Unexpected price source instruments')
    if manifest.get('learned_text_features_in_static_data') is not False:
        raise ValueError('Static data may contain globally learned text features')
    if not panel.source_price_provider.eq('Refinitiv_matching_RIC_exports_only').all():
        raise ValueError('Unexpected price-provider panel lineage')
    return Snapshot(manifest_path, manifest, hashes, panel, corpus, daily)


def case_frame(snapshot: Snapshot, case: str) -> pd.DataFrame:
    frame = snapshot.panel.loc[boolean(snapshot.panel.in_common_event_cohort)].copy()
    if case == 'modern_live_only':
        frame = frame.loc[(frame.legacy_regime == 0) & (frame.pre_return_start_date >= '2020-01-02')]
    elif case != 'expanded_legacy_live':
        raise ValueError(f'Unknown case: {case}')
    return frame.sort_values(['event_date', 'doc_id', 'sector']).reset_index(drop=True)


def grouped_splits(frame: pd.DataFrame, initial: int) -> list[dict]:
    events = frame[['doc_id', 'event_date']].drop_duplicates().sort_values(['event_date', 'doc_id'])
    if events.event_date.duplicated().any():
        raise ValueError('Non-unique date origin')
    plans = []
    for event in events.itertuples(index=False):
        # A common history across ALL horizons: latest (second) label must be known.
        legal = frame.loc[(frame.event_date < event.event_date) &
                          (frame.second_session_date < event.event_date)]
        ids = legal[['doc_id', 'event_date']].drop_duplicates().sort_values(['event_date', 'doc_id'])
        if len(ids) < initial:
            continue
        if not legal.groupby('doc_id').size().eq(2).all():
            raise ValueError('Split does not group both sectors')
        plans.append({'fold': len(plans) + 1, 'doc_id': event.doc_id,
                      'event_date': event.event_date,
                      'training_doc_ids': ids.doc_id.tolist(),
                      'training_events': len(ids),
                      'last_training_label_end': legal.second_session_date.max(),
                      'forecast_first_session_date': frame.loc[frame.doc_id.eq(event.doc_id), 'first_session_date'].iloc[0]})
    if not plans:
        raise ValueError('No legal outer evaluations after declared initial history')
    return plans
