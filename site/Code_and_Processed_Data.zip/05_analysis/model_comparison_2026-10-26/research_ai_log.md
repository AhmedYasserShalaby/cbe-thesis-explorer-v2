# Research and AI assistance — expanded comparison

## 26 October 2026 — implementation begun

AI assistance: Codex read SESSION_CONTEXT, AGENTS, README, shared contract, meeting plan, current evaluation note, retained numerical/embedding source, review findings and safe checker. No historical fitting module was imported or run. The Data notebook/validation skills guide the new reproducible notebook and checks. No outside text encoder or API is used.

User authorization explicitly permits this bounded new local comparison and supersedes earlier no-fit restrictions for this version. Fixed prototype settings and first-session ranking are analyst choices, not supervisor-selected settings. All existing historical test outcomes have been inspected; the new comparison cannot supply an untouched test. Timing/vintage uncertainty remains.

Dependency at start: Data's validated atomic Refinitiv-only manifest is not yet present. Implementation and synthetic checks proceed independently. No numerical result is claimed at this stage.

## Protocol binding and fitting start

Published early settings in `03_methodology/model_comparison_2026-10-26/protocol_specification.json` and `PROTOCOL.md`. Before any actual price/outcome fit, published `frozen_protocol.json` and `FROZEN_PROTOCOL.md` with the validated Data manifest (`0a92956bf44404b11f3ab7502e1af690a0e7e84456d6f2eca52dbd9c006dee73`), 389 declared source/input hashes, exact eligible IDs, grouped expanding splits, code hashes and package versions. Separately inventoried protected historical processed/model/result/code/notebook bytes for post-run comparison; those hashes are preservation evidence, not new prediction inputs.

Actual common cohort derives from the new manifest: 155 announcements, including 99 legacy and 56 modern-live; 119 expanded evaluation origins, 24 November 2011–24 September 2026. Modern-live-only sensitivity has 56 announcements and 36 origins, 19 May 2022–24 September 2026. Initial complete training histories are 36 and 20 events. Original-release clocks remain unverified. There is no Refinitiv modern-2019 backcast.

Seventeen focused synthetic tests pass. The first synthetic PCA fixture had effectively identical vocabulary-averaged documents, producing undefined explained variance; the fixture was given controlled variation and explicit finite-PCA checks were added. Full-inventory missing numeric strings also required explicit numeric parsing in the loader, preserving missingness without imputation. These defects were corrected and tests/alignment checks rerun BEFORE protocol freezing or any real fit. Independent prefit daily-table replay reconciled 2,170 common price links and 1,550 target/lag ratios.

Started the authorized actual run in fresh `run_001` result/artifact directories after freezing. Fixed model configurations, no validation/search budget, no external inference. The planned 7,440 learned fits / 9,300 forecasts are not completion claims; computation and independent verification are pending.

## Completed run and final evidence

Actual computation completed in approximately 146 seconds: 7,440 learned model fits, 9,300 forecasts including both references, 119 new dated encoders and 36 legal byte-validated shared-cutoff cache hits. All predefined model families, sectors, horizons, variants and cases retained. No outer-test tuning/search or result-driven removal. The 17-test synthetic suite and code/input hashes were frozen before actual fitting.

Independent verifier PASS: 930 expanding-history benchmark calculations; 120 main and 180 definition metric rows; 60 direction-baseline rows; 120 paired statistics/interval rows; complete 9,300-row grid and all 7,440 model-choice/byte hashes. All 155 fold feature spaces and 620 scalers/matrices reconcile. Independent target/session replay checks 2,170 daily-table links and 1,550 targets/predictor ratios. Independently reconstructed 288 stored-model forecasts (72/family) from linear coefficients, explicit RBF kernels or forest-node traversal, max discrepancy 4.55e-15pp. This is sampled model replay, not all-estimator mathematical rederivation.

Gensim emitted C-backend stderr labels during actual fitting. A separately saved bounded diagnostic compares all 119 new finite word-vector arrays with previously independently audited same-history/vocabulary arrays (exact equality) and retrains only three frozen-input encoders (first/middle/last; exact equality). Earlier learned vectors are validation references only, never new outcome-fitting inputs. No forecast/encoder/model was replaced. The diagnostic itself also printed stderr labels while its Python hook recorded no exception objects. The cause remains unresolved and is explicitly documented, rather than interpreting the empty ordinary warning list as clean stderr.

Main finding: text MAE decreases in 3/16 first-session primary pairs and 12/48 all-window pairs; 47/48 descriptive MAE intervals span zero. Zero reference beats all learned variants on primary MAE/RMSE in all four case/sector comparisons. The modern-live Real Estate forest's negative paired interval remains a single descriptive, unadjusted comparison and its magnitude errors still exceed zero/mean references. No guaranteed text gain or untouched-test claim. All prior inspected/negative findings remain preserved.

The seven-cell saved-output notebook executed top-to-bottom. Actual in-app-browser inspection found wide primary-table clipping; presentation-only per-sector tables/short headers repaired it, with before-copies retained and all cells executed/rendered again. Final nine data tables fit 1280×720 viewport; two final figures viewed both in the notebook and image viewer. Frozen fitting/evaluation code, predictions and metric bytes stayed unchanged. Presentation/audit scripts and sources are saved/hash-pinned as result artifacts.

Atomically published `06_results/model_comparison_2026-10-26/run_manifest.json` (SHA-256 cc3a685f1bd330ff173053318a4db339800a4ec317c9cce79440fdbc267045f8). Final check passes all 9,424 artifact hashes, 389 declared input/source hashes and frozen executable hashes. Separate preservation evidence confirms 2,920 prior processed/model/result/code/notebook files unchanged; declared raw sources also match. Actual environment and exact commands recorded. No clean-environment installation/full retraining reproduction, source-clock/vintage certification, email, upload or submission by this workstream. Parent owns shared root context/global logs; completed status and links are in models_status.md.
