"""Complete candidate/definition metrics and paired announcement-block intervals."""
from __future__ import annotations

import numpy as np
import pandas as pd


def direction_stats(actual, prediction) -> dict:
    actual = np.asarray(actual, float)
    prediction = np.asarray(prediction, float)
    if not np.isfinite(actual).all() or not np.isfinite(prediction).all():
        raise ValueError('Nonfinite directional inputs')
    signs, guessed = np.sign(actual), np.sign(prediction)
    up, down, nonzero = signs > 0, signs < 0, signs != 0
    correct = signs == guessed
    up_recall = float(correct[up].mean()) if up.any() else None
    down_recall = float(correct[down].mean()) if down.any() else None
    return {'actual_up': int(up.sum()), 'actual_down': int(down.sum()),
            'actual_flat': int((signs == 0).sum()),
            'predicted_flat': int((guessed == 0).sum()),
            'direction_scored': int(nonzero.sum()),
            'direction_correct': int(correct[nonzero].sum()),
            'direction_accuracy': float(correct[nonzero].mean()) if nonzero.any() else None,
            'up_recall': up_recall, 'down_recall': down_recall,
            'balanced_direction_accuracy': ((up_recall + down_recall) / 2
                                            if up_recall is not None and down_recall is not None else None)}


def score(actual, prediction, benchmark) -> dict:
    actual, prediction, benchmark = [np.asarray(a, float) for a in [actual, prediction, benchmark]]
    if not len(actual) or not (len(actual) == len(prediction) == len(benchmark)):
        raise ValueError('Empty/unequal score arrays')
    if not all(np.isfinite(a).all() for a in [actual, prediction, benchmark]):
        raise ValueError('Nonfinite scoring inputs')
    errors = prediction - actual
    sse = float(np.dot(errors, errors))
    base_errors = benchmark - actual
    denominator = float(np.dot(base_errors, base_errors))
    return {'test_events': len(actual), 'MAE_pp': float(np.abs(errors).mean()),
            'RMSE_pp': float(np.sqrt(np.mean(errors ** 2))),
            'model_SSE_pp2': sse, 'expanding_mean_SSE_pp2': denominator,
            'R2_OS': 1 - sse / denominator if denominator != 0 else None,
            'R2_OS_status': 'defined' if denominator != 0 else 'undefined_zero_benchmark_SSE',
            **direction_stats(actual, prediction)}


def metric_tables(predictions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows, definitions, baselines = [], [], []
    keys = ['case', 'sector', 'horizon', 'family', 'variant']
    for group_keys, group in predictions.groupby(keys, sort=True):
        rows.append(dict(zip(keys, group_keys)) | score(group.actual_pp, group.prediction_pp, group.historical_mean_pp))
    for group_keys, group in predictions.groupby(keys + ['sector_definition'], sort=True):
        definitions.append(dict(zip(keys + ['sector_definition'], group_keys)) |
                           score(group.actual_pp, group.prediction_pp, group.historical_mean_pp))
    for group_keys, group in predictions.loc[predictions.family.eq('historical_mean')].groupby(keys[:3], sort=True):
        for label, prediction in [('always_up', np.ones(len(group))), ('always_down', -np.ones(len(group))),
                                  ('past_training_majority', group.training_majority_sign.to_numpy()),
                                  ('historical_mean', group.historical_mean_pp.to_numpy()),
                                  ('zero_return', np.zeros(len(group)))]:
            baselines.append(dict(zip(keys[:3], group_keys)) | {'direction_baseline': label} |
                             direction_stats(group.actual_pp, prediction))
    return pd.DataFrame(rows), pd.DataFrame(definitions), pd.DataFrame(baselines)


def paired_statistics(actual, numerical, text, *, replicates=2000, block_length=5, seed=42) -> dict:
    actual, numerical, text = [np.asarray(a, float) for a in [actual, numerical, text]]
    if not len(actual) or len(actual) != len(numerical) or len(actual) != len(text):
        raise ValueError('Unequal paired arrays')
    if not all(np.isfinite(a).all() for a in [actual, numerical, text]):
        raise ValueError('Nonfinite paired input')
    numeric_loss, text_loss = (numerical - actual) ** 2, (text - actual) ** 2
    absolute_delta = np.sqrt(text_loss) - np.sqrt(numeric_loss)
    squared_delta = text_loss - numeric_loss
    n, block = len(actual), min(block_length, len(actual))
    rng = np.random.default_rng(seed)
    starts = rng.integers(0, n, size=(replicates, int(np.ceil(n / block))))
    indices = ((starts[:, :, None] + np.arange(block)) % n).reshape(replicates, -1)[:, :n]
    boot_mae = absolute_delta[indices].mean(axis=1)
    boot_mse = squared_delta[indices].mean(axis=1)
    boot_rmse = np.sqrt(text_loss[indices].mean(axis=1)) - np.sqrt(numeric_loss[indices].mean(axis=1))
    output = {'test_events': n, 'block_length': block, 'replicates': replicates, 'seed': seed,
              'uncertainty': 'descriptive_95pct_circular_announcement_block_percentiles'}
    for label, estimate, bootstrap in [
        ('MAE_difference_pp', absolute_delta.mean(), boot_mae),
        ('MSE_difference_pp2', squared_delta.mean(), boot_mse),
        ('RMSE_difference_pp', np.sqrt(text_loss.mean()) - np.sqrt(numeric_loss.mean()), boot_rmse)]:
        low, high = np.quantile(bootstrap, [0.025, 0.975])
        output[label] = float(estimate)
        output[label + '_low'] = float(low)
        output[label + '_high'] = float(high)
    return output


def paired_tables(predictions: pd.DataFrame, settings: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    learned = predictions.loc[predictions.variant.isin(['numerical', 'text_added'])]
    keys = ['case', 'sector', 'horizon', 'family']
    tables = []
    for by_definition in [False, True]:
        grouping = keys + (['sector_definition'] if by_definition else [])
        rows = []
        for group_keys, group in learned.groupby(grouping, sort=True):
            numeric = group.loc[group.variant.eq('numerical')].sort_values(['event_date', 'doc_id'])
            text = group.loc[group.variant.eq('text_added')].sort_values(['event_date', 'doc_id'])
            for name in ['doc_id', 'event_date', 'actual_pp', 'training_cohort_sha256', 'historical_mean_pp']:
                if not np.array_equal(numeric[name].to_numpy(), text[name].to_numpy()):
                    raise ValueError(f'Paired cohort differs: {name}')
            if numeric.doc_id.duplicated().any():
                raise ValueError('Repeated paired announcements')
            rows.append(dict(zip(grouping, group_keys)) |
                        paired_statistics(numeric.actual_pp, numeric.prediction_pp, text.prediction_pp,
                                          replicates=settings['replicates'], block_length=settings['block_length'],
                                          seed=settings['seed']))
        tables.append(pd.DataFrame(rows))
    return tables[0], tables[1]
