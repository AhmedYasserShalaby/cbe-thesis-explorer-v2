# Expanded Refinitiv-only comparison

This directory owns a separate bounded 26 October experiment. Imports never fit. The preserved historical fitting CLI is not called or imported. Actual fitting uses only Data's validated atomic manifest and its hash-pinned declared files. Do not run older canonical fitters to reproduce this version.

From `/Users/ahmedyasser/Documents/ChatGPT/Thesis`:

```sh
PYTHONHASHSEED=42 .venv_thesis_data/bin/python -m unittest discover -s 05_analysis/model_comparison_2026-10-26 -p test_experiment.py -v
# Once, after code/tests and validated data are ready, BEFORE fitting:
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/experiment.py freeze
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/experiment.py run --output 06_results/model_comparison_2026-10-26/run_001 --artifacts 05_analysis/models/model_comparison_2026-10-26/run_001
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/verify.py --output 06_results/model_comparison_2026-10-26/run_001
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/deliver.py author --output 06_results/model_comparison_2026-10-26/run_001
```

Freeze and run refuse existing destinations. To reproduce a completed run, retain the frozen protocol and use new `run_002` result/artifact directories in the `run` and `verify` commands. Exact bytes/cohorts/settings/dependency versions are validated. Do not re-freeze or replace the existing protocol. The companion notebook itself is rerunnable without fitting; the README and notebook give explicit commands for model refitting. Reauthoring the main summary/notebook is a one-time original-run delivery action, also protected against accidental overwrite.

Files:

- `data.py`: manifest/source hashes, original text fingerprints, explicit numerical parsing, complete common cohorts, definition boundary and grouped expanding splits.
- `text_features.py`: retained past-only CBOW settings; unknown-token diagnostics; full-byte-validated encoder cache; shared per-fold PCA and matrices.
- `experiment.py`: protocol binding and fixed Ridge/Elastic Net/RBF SVR/conservative Random Forest; both variants for every family, sector and horizon; all fitted models, scalers, choices and predictions.
- `metrics.py`: magnitude/direction metrics, actual expanding-history denominator, complete paired event-block intervals.
- `verify.py`: independent arithmetic without the scoring helpers, all benchmarks/metric tables/intervals, source target/feature date alignment, all feature/PCA/scaler checks, representative independent estimator arithmetic.
- `deliver.py`: verified results record, complete tables, executed notebook/HTML/figures, final manifest publication after actual visual inspection.
- `test_experiment.py`: focused synthetic leakage, split, compounding, hash/cache, zero, nonfinite and comparison-failure checks; synthetic fitted examples are not empirical results.
- `run_tests.py`: runs the synthetic suite and saves a non-overwriting JSON receipt (`--report` selects a new receipt path).

The actual run also contains `backend_audit.py`/JSON and `BACKEND_NOTE.md`: after C-backend stderr messages, all 119 new encoder arrays matched previously audited same-history vectors, and three controlled retrains reproduced exactly. Prior vectors were validation references only. The cause of the stderr labels remains unresolved; the empty ordinary Python warning list does not certify clean C stderr.

`run_001/finalize_notebook.py` adds the verified simple-reference finding/runtime note and re-executes the notebook. `run_001/polish_notebook.py` repairs observed table clipping using shorter display headers/per-sector tables, shows both fixed references in the figure, and re-executes/renders again. These are saved presentation-only build steps; they do not change any frozen fitting/evaluation source or numerical result. Before-copies remain in the run directory. The final notebook's seven code cells can be rerun directly without refitting. Final `visual_inspection.json` records the actual viewer/figure checks after these changes.

The original diagnostic/presentation build, after `verify.py` and `deliver.py author`, used these exact additional commands. They preserve their existing receipts/before-copies and refuse repeating into those destinations; use the saved notebook directly for normal result review.

```sh
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 06_results/model_comparison_2026-10-26/run_001/backend_audit.py
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 06_results/model_comparison_2026-10-26/run_001/finalize_notebook.py
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 06_results/model_comparison_2026-10-26/run_001/polish_notebook.py
# After recording actual visual inspection and successful test receipt:
PYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/deliver.py publish --output 06_results/model_comparison_2026-10-26/run_001
```

Default results: `/Users/ahmedyasser/Documents/ChatGPT/Thesis/06_results/model_comparison_2026-10-26/run_001/`. Learned artifacts and validated caches are in the separate ignored `05_analysis/models/model_comparison_2026-10-26/` tree. The final `06_results/model_comparison_2026-10-26/run_manifest.json` is published atomically only after actual fitting, independent verification, notebook execution, tests and visual QA. No publication or upload command is implemented.

The local `.venv_thesis_data` dependencies are recorded exactly in the frozen protocol/run manifest. A fresh clean-environment retraining has not been performed. The original clocks/vintages, incomplete body/source certification, legacy/live comparability, inspected historical outcomes and small dependent samples remain limitations. Prior negative/mixed outputs remain intact.
