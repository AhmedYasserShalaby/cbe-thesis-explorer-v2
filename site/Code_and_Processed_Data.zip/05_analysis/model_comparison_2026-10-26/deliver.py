"""Author executed notebook/results and atomically publish a verified run manifest.

No fitting on import or execution. Notebook is a reproducible saved-output
companion; exact explicit commands reproduce fitting into new directories.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import nbformat
from nbclient import NotebookClient
from nbconvert import HTMLExporter
from jupyter_client import KernelManager
import pandas as pd

from utils import ROOT, CODE, METHODOLOGY, RESULTS, ARTIFACTS, sha256, relative, atomic_json, validate_hashes, environment


def markdown_table(frame):
    def cell(value):
        if pd.isna(value):
            return 'undefined'
        if isinstance(value, float):
            return f'{value:.5f}'
        return str(value)
    lines = ['| ' + ' | '.join(frame.columns) + ' |',
             '| ' + ' | '.join(['---']*len(frame.columns)) + ' |']
    lines += ['| ' + ' | '.join(cell(v) for v in row) + ' |' for row in frame.itertuples(index=False, name=None)]
    return '\n'.join(lines)


def author(output):
    verification = json.loads((output/'verification.json').read_text())
    if verification['status'] != 'PASS':
        raise ValueError('Refusing results authoring without successful independent verification')
    frozen = json.loads((METHODOLOGY/'frozen_protocol.json').read_text())
    computation = json.loads((output/'computation_manifest.json').read_text())
    metrics = pd.read_csv(output/'metrics.csv')
    pairs = pd.read_csv(output/'paired_text_differences.csv')
    primary = pairs.loc[pairs.horizon.eq('first_session')]
    negative = int((pairs.MAE_difference_pp < 0).sum())
    primary_negative = int((primary.MAE_difference_pp < 0).sum())
    spans = int(((pairs.MAE_difference_pp_low <= 0) & (pairs.MAE_difference_pp_high >= 0)).sum())
    prefix = (f'The bounded comparison ran {computation["learned_model_fits"]:,} learned-model fits at '
              f'{computation["evaluation_origins"]} case/announcement origins, with '
              f'{computation["prediction_rows"]:,} sector/window/candidate forecasts including references. '
              f'Text lowered MAE in {primary_negative}/{len(primary)} primary first-session pairs and '
              f'{negative}/{len(pairs)} pairs across all predefined windows. '
              f'{spans}/{len(pairs)} descriptive MAE-difference intervals include zero. '
              'These counts summarize fixed comparisons, not independent hypothesis tests or a selected winning design.')
    # Values are generated from verified saved outputs, never draft predictions.
    body = '# Refinitiv-only expanded model comparison — 26 October 2026\n\n**Share with caveats.** ' + prefix
    body += '\n\n'
    for case, record in frozen['cohorts'].items():
        initial = frozen['specification']['cohorts'][case]['initial_training_events']
        body += (f"{case}: {record['events']} common announcements, definitions {record['counts_by_definition']}; "
                 f"{record['evaluation_events']} scored origins {record['first_evaluation_date']}–{record['last_evaluation_date']} "
                 f"after {initial} prior complete labels. ")
    body += 'Exact IDs are in the frozen protocol. These are actual derived counts; no 2019 legacy values were relabeled as modern backcasts.\n\n'
    body += 'First-session paired differences (text minus numerical; negative means smaller MAE):\n\n'
    body += markdown_table(primary[['case', 'sector', 'family', 'test_events', 'MAE_difference_pp', 'MAE_difference_pp_low', 'MAE_difference_pp_high']])
    body += '\n\nComplete candidate tables include both references and every numerical/text variant, all three windows, both sectors/cases, MAE/RMSE (pp), expanding-mean R2_OS/denominator and direction/class counts. Definition tables keep legacy/live results separate. Second-session and combined windows were predefined secondary analyses at the same initial forecast origin; no realized first-session input was used. All learned settings were fixed; tuning budget was zero.\n\n'
    body += (f'Verification independently recalculated all {verification["main_metric_rows_independently_recomputed"]} headline metric rows, '
             f'{verification["definition_metric_rows_independently_recomputed"]} per-definition rows, '
             f'{verification["direction_baseline_rows_independently_recomputed"]} direction baselines and '
             f'{verification["paired_rows_and_intervals_independently_recomputed"]} paired rows/intervals from saved predictions. '
             f'All {verification["model_choices_and_byte_hashes_checked"]:,} model settings/byte hashes were checked. '
             f'{verification["learned_processing"]["independent_model_replays"]} first/middle/last-fold predictions were independently reconstructed from stored linear coefficients, RBF kernels or forest nodes; this is a bounded sample of model replays. '
             'All fold matrices/PCA/scalers, source hashes, grouped cohorts, date-only label availability and target ratios were checked. Synthetic tests exercise failure cases.\n\n')
    body += 'Original full-statement release clocks remain unverified for all 174 policy candidates; saved texts are not independently captured historical vintages. All existing historical tests were inspected before this study; changed sources/targets do not create an untouched test. Small dependent samples, different legacy/live definitions, fixed prototype settings, incomplete body/source certification and multiple comparisons remain material. No causal effect, trading profit, measured capital-constraint mechanism or guaranteed text benefit is established. Earlier negative/mixed findings remain preserved.\n\n'
    body += 'Files: `run_001/predictions.csv`, `metrics.csv`, `metrics_by_definition.csv`, `direction_baselines.csv`, `paired_text_differences.csv`, `paired_text_differences_by_definition.csv`, `model_choices.csv`, `fold_audits.json`, `text_coverage.csv` and `verification.json` under the run directory; `comparison.ipynb` is executed and `comparison.html` is its portable preview. Reproduction commands are in the code README. No upload or submission was performed by this workstream.\n'
    with (RESULTS/'RESULTS.md').open('x') as stream:
        stream.write(body)
    full_tables = '# Complete frozen candidate tables\n\nMAE and RMSE are percentage points (lower better); R2_OS/direction are unitless (higher better). Actual exact-zero outcomes are excluded only from directional denominators; predicted zero is a miss for nonzero outcomes. Undefined balanced direction requires a missing up/down class; undefined R2_OS requires zero expanding-mean benchmark SSE.\n\n'
    for case in frozen['cohorts']:
        for horizon in frozen['specification']['horizons']:
            for sector in ['banks', 'real_estate']:
                table = metrics.loc[metrics.case.eq(case) & metrics.horizon.eq(horizon) & metrics.sector.eq(sector)]
                full_tables += f'## {case} / {sector} / {horizon}\n\n'
                full_tables += markdown_table(table[['family', 'variant', 'test_events', 'MAE_pp', 'RMSE_pp', 'R2_OS', 'expanding_mean_SSE_pp2', 'direction_accuracy', 'balanced_direction_accuracy', 'actual_up', 'actual_down', 'actual_flat']]) + '\n\n'
    with (output/'candidate_tables.md').open('x') as stream:
        stream.write(full_tables)
    nb = nbformat.v4.new_notebook()
    nb.metadata = {'kernelspec': {'name': 'python3', 'display_name': 'Python 3 (thesis environment)', 'language': 'python'},
                   'language_info': {'name': 'python', 'version': sys.version.split()[0]}}
    md, code = nbformat.v4.new_markdown_cell, nbformat.v4.new_code_cell
    nb.cells = [
        md('# Refinitiv-only forecast comparison\n\n## tl;dr\n\n' + prefix + '\n\n**Retrospective exploratory evidence.** All existing historical tests were inspected. Original release clocks/vintages remain unverified. First session is primary; other windows are secondary. Read complete tables before drawing conclusions.'),
        md('## Context & Methods\n\nTwo sectors, three close-to-close targets and four fixed learned families, each numerical-only versus numerical plus identical common text features. Expanding same-cohort historical mean and zero references. Word2Vec is trained only on earlier original-English policy dates; four PCA components and scaling use only outcome-training observations. All three labels must end before the current statement date. No random split or tuning search.\n\n### Key Assumptions\n\nDate-based alignment assumes relevant full text was available before the first eligible session. No exact historical open/release clock is fabricated. Legacy/live definitions remain distinct. Modern-only sensitivity starts in the live 2020 regime. Descriptive intervals use paired circular blocks of five announcement units (2,000 seeded replications); sectors/windows are not independent extra observations.\n\nThis notebook rechecks and presents saved results without refitting. The fully executable experiment and exact new-directory rerun commands are below.'),
        md('### 1. Setup and frozen sources'),
        code("from pathlib import Path\nimport json, hashlib, sys\nimport numpy as np\nimport pandas as pd\nimport matplotlib.pyplot as plt\nfrom IPython.display import display\nROOT = next(p for p in [Path.cwd(), *Path.cwd().parents] if (p/'AGENTS.md').exists())\nCODE = ROOT/'05_analysis/model_comparison_2026-10-26'\nRUN = ROOT/" + repr(relative(output)) + "\nsys.path.insert(0, str(CODE))\nfrom utils import validate_hashes\nfrom verify import compare_metric_table\nprotocol_path = ROOT/'03_methodology/model_comparison_2026-10-26/frozen_protocol.json'\nprotocol = json.loads(protocol_path.read_text())\nvalidate_hashes(protocol['input_hashes'])\nvalidate_hashes(protocol['executable_source_hashes'])\nverification = json.loads((RUN/'verification.json').read_text())\nassert verification['status'] == 'PASS'\nplt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':False,'figure.dpi':120})\ncolors = {'numerical':'#235789','text_added':'#B26B16','reference':'#42484E'}\nprint('Frozen manifest:', protocol['dataset_manifest_sha256'])\nprint('Source/input hashes checked:', len(protocol['input_hashes']))"),
        md('## Data\n\n### 2. Actual announcement counts and dates'),
        code("cohorts = pd.DataFrame([{k:v for k,v in record.items() if k not in ['event_records','counts_by_definition']} | {'case':case} for case,record in protocol['cohorts'].items()])\ndisplay(cohorts[['case','events','sector_rows','first_event','last_event','evaluation_events','first_evaluation_date','last_evaluation_date']])\nprint('Definition counts:', {case:record['counts_by_definition'] for case,record in protocol['cohorts'].items()})\npredictions = pd.read_csv(RUN/'predictions.csv', float_precision='round_trip')\nmetrics = pd.read_csv(RUN/'metrics.csv', float_precision='round_trip')\ndefinitions = pd.read_csv(RUN/'metrics_by_definition.csv', float_precision='round_trip')\npairs = pd.read_csv(RUN/'paired_text_differences.csv', float_precision='round_trip')\ncoverage = pd.read_csv(RUN/'text_coverage.csv')\nprint('Saved candidate forecasts:', len(predictions), '; independent event count is not multiplied by sectors/windows/models.')"),
        md('### 3. Recompute metrics independently\n\nThe separate verifier uses its own arithmetic, checks expanding benchmarks against each saved training cohort, and replays sampled stored models. This cell independently reconciles both complete metric tables again.'),
        code("keys = ['case','sector','horizon','family','variant']\ncompare_metric_table(predictions, metrics, keys)\ncompare_metric_table(predictions, definitions, keys+['sector_definition'])\nassert np.isfinite(predictions[['actual_pp','prediction_pp','historical_mean_pp']].to_numpy()).all()\ndisplay(pd.Series({k:v for k,v in verification.items() if isinstance(v,(str,int,bool))},name='Verification'))"),
        md('## Results\n\n### 4. First-session primary comparisons\n\nEach table contains every candidate. MAE/RMSE are pp; R2_OS uses the saved expanding-history benchmark denominator. Direction excludes actual exact zeros only and treats predicted zeros as misses for nonzero outcomes.'),
        code("for case in protocol['cohorts']:\n    print(case, '— first session')\n    display(metrics.loc[metrics.case.eq(case)&metrics.horizon.eq('first_session'), ['sector','family','variant','test_events','MAE_pp','RMSE_pp','R2_OS','direction_accuracy','balanced_direction_accuracy','actual_up','actual_down','actual_flat']].round(4))"),
        md('### 5. All predefined windows in the expanded analysis\n\nBars compare numerical/text variants of each family; the dashed line is the same-cohort expanding-mean MAE. The separate zero reference and all exact metrics remain in the tables.'),
        code("families = ['ridge','elastic_net','rbf_svr','random_forest']\nlabels = ['Ridge','Elastic Net','RBF SVR','Random Forest']\nwindows = ['first_session','second_session','two_session']\nwindow_labels = ['First session (primary)','Second session only','Combined two sessions']\nfig, axes = plt.subplots(3,2,figsize=(12,11),layout='constrained')\nfor i,(window,title) in enumerate(zip(windows,window_labels)):\n    for j,sector in enumerate(['banks','real_estate']):\n        ax = axes[i,j]\n        group = metrics.loc[metrics.case.eq('expanded_legacy_live')&metrics.sector.eq(sector)&metrics.horizon.eq(window)]\n        x = np.arange(4)\n        for offset,variant,hatch in [(-.18,'numerical',''),(.18,'text_added','//')]:\n            values = [group.loc[group.family.eq(family)&group.variant.eq(variant),'MAE_pp'].iloc[0] for family in families]\n            ax.bar(x+offset,values,width=.34,color=colors[variant],label=variant.replace('_',' '),hatch=hatch,edgecolor='#30363B',linewidth=.5)\n        reference = group.loc[group.family.eq('historical_mean'),'MAE_pp'].iloc[0]\n        ax.axhline(reference,color=colors['reference'],linestyle='--',linewidth=1.3,label='expanding mean')\n        ax.set_xticks(x,labels,rotation=0,fontsize=9)\n        ax.set_ylim(bottom=0)\n        ax.set_ylabel('MAE (percentage points)')\n        ax.set_title(f'{sector.replace(\"_\",\" \").title()} · {title} · n={int(group.test_events.iloc[0])}')\n        ax.grid(axis='y',color='#D7DBDE',linewidth=.5)\n        ax.set_axisbelow(True)\n        if i==0 and j==0: ax.legend(fontsize=9)\nfig.suptitle('Expanded legacy/live comparison: all fixed families and horizons',fontsize=15)\nfig.savefig(RUN/'all_windows_MAE.png',bbox_inches='tight')\nplt.show()"),
        md('### 6. Incremental text value and uncertainty\n\nNegative differences favor text. Intervals are descriptive 95% paired announcement-block percentiles. They do not provide untouched-test, causal or multiplicity-adjusted significance evidence.'),
        code("first = pairs.loc[pairs.horizon.eq('first_session')]\nfig,axes = plt.subplots(2,2,figsize=(12,7.5),layout='constrained')\nfor i,case in enumerate(['expanded_legacy_live','modern_live_only']):\n    for j,sector in enumerate(['banks','real_estate']):\n        ax=axes[i,j]\n        group=first.loc[first.case.eq(case)&first.sector.eq(sector)].set_index('family').loc[families]\n        center=group.MAE_difference_pp.to_numpy()\n        low=group.MAE_difference_pp_low.to_numpy()\n        high=group.MAE_difference_pp_high.to_numpy()\n        ax.errorbar(center,np.arange(4),xerr=np.vstack([center-low,high-center]),fmt='o',color=colors['text_added'],ecolor='#4D5963',capsize=4)\n        ax.axvline(0,color='#42484E',linestyle='--',linewidth=1)\n        ax.set_yticks(np.arange(4),labels)\n        ax.invert_yaxis()\n        ax.set_xlabel('Text minus numerical MAE (pp)')\n        ax.set_title(f'{case.replace(\"_\",\" \")} · {sector.replace(\"_\",\" \")} · n={int(group.test_events.iloc[0])}')\n        ax.grid(axis='x',color='#D7DBDE',linewidth=.5)\nfig.suptitle('First-session text comparisons with descriptive paired intervals',fontsize=14)\nfig.savefig(RUN/'primary_text_differences.png',bbox_inches='tight')\nplt.show()\ndisplay(first[['case','sector','family','test_events','MAE_difference_pp','MAE_difference_pp_low','MAE_difference_pp_high','RMSE_difference_pp']].round(5))"),
        md('### 7. Definitions, class frequencies and vocabulary coverage\n\nThe modern-only sensitivity uses a different training history and later evaluation period. It is not a like-for-like causal comparison of definitions. Complete per-definition, secondary-window and direction baseline tables are saved alongside this notebook.'),
        code("display(definitions.loc[definitions.horizon.eq('first_session') & definitions.family.eq('ridge'), ['case','sector','sector_definition','variant','test_events','MAE_pp','RMSE_pp','R2_OS']].round(5))\ndirection = pd.read_csv(RUN/'direction_baselines.csv')\ndisplay(direction.loc[direction.horizon.eq('first_session'), ['case','sector','direction_baseline','actual_up','actual_down','actual_flat','direction_accuracy','balanced_direction_accuracy']].round(4))\ndisplay(coverage.groupby('case').agg(evaluation_origins=('doc_id','size'),minimum_known_fraction=('known_token_fraction','min'),median_known_fraction=('known_token_fraction','median'),minimum_vocabulary=('vocabulary_size','min'),maximum_vocabulary=('vocabulary_size','max')).round(4))"),
        md('## Takeaways\n\n' + prefix + '\n\nInterpret individual sector/window/family differences together with the complete magnitude, direction and definition tables. Do not select a favorable model or window after observing these outcomes. Policy changes are observed decisions, not measured surprises. Legacy/live continuity is not established by adding an indicator. These data do not measure capital constraints or establish tradable profits.\n\nPrior negative/mixed experiments remain preserved. No paid or external text inference was used, and no source-clock certainty or untouched-test status was created by this run.'),
        md('### Exact reproduction commands\n\nFrom the Thesis root, use the retained `.venv_thesis_data` versions in the run manifest. Existing destinations are refused. The frozen source/input hashes must still match.\n\n```sh\nPYTHONHASHSEED=42 .venv_thesis_data/bin/python -m unittest discover -s 05_analysis/model_comparison_2026-10-26 -p test_experiment.py -v\nPYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/experiment.py run --output 06_results/model_comparison_2026-10-26/run_002 --artifacts 05_analysis/models/model_comparison_2026-10-26/run_002\nPYTHONHASHSEED=42 .venv_thesis_data/bin/python 05_analysis/model_comparison_2026-10-26/verify.py --output 06_results/model_comparison_2026-10-26/run_002\n```\n\nThe notebook itself is an executed saved-output companion and can be rerun without fitting. Source bytes, input hashes, configuration, cohorts and dependencies govern cache reuse. The environment is recorded; no clean-environment installation or independent full retraining reproduction is claimed.')
    ]
    nbformat.validate(nb)
    path = output/'comparison.ipynb'
    if path.exists():
        raise FileExistsError('Refusing existing notebook')
    nbformat.write(nb, path)
    manager = KernelManager(kernel_name='python3')
    manager.kernel_spec.argv = [sys.executable, '-m', 'ipykernel_launcher', '-f', '{connection_file}']
    client = NotebookClient(nb, km=manager, timeout=180, resources={'metadata': {'path': str(ROOT)}})
    try:
        client.execute()
    finally:
        if manager.has_kernel:
            manager.shutdown_kernel(now=True)
    nbformat.validate(nb)
    nbformat.write(nb, path)
    html, _ = HTMLExporter(template_name='lab').from_notebook_node(nb)
    with (output/'comparison.html').open('x') as stream:
        stream.write(html)
    atomic_json(output/'notebook_execution.json', {
        'status': 'executed_top_to_bottom', 'notebook_sha256': sha256(path),
        'code_cells': sum(c.cell_type == 'code' for c in nb.cells),
        'executed_code_cells': sum(c.cell_type == 'code' and c.execution_count is not None for c in nb.cells),
        'error_outputs': sum(o.output_type == 'error' for c in nb.cells if c.cell_type == 'code' for o in c.outputs),
        'visual_inspection': 'pending_actual_viewer_and_png_review',
        'runtime_python': sys.executable, 'html_preview': relative(output/'comparison.html')})
    print(f'Authored results and executed notebook: {path}', flush=True)


def publish(output):
    frozen = json.loads((METHODOLOGY/'frozen_protocol.json').read_text())
    computation = json.loads((output/'computation_manifest.json').read_text())
    verification = json.loads((output/'verification.json').read_text())
    notebook = json.loads((output/'notebook_execution.json').read_text())
    inspection = json.loads((output/'visual_inspection.json').read_text())
    tests = json.loads((RESULTS/'synthetic_tests.json').read_text())
    if verification['status'] != 'PASS' or tests['failures'] or tests['errors']:
        raise ValueError('Verification/tests do not pass')
    if notebook['status'] != 'executed_top_to_bottom' or notebook['error_outputs']:
        raise ValueError('Notebook not successfully executed')
    if inspection['status'] != 'PASS':
        raise ValueError('Actual visual inspection not passed')
    validate_hashes(frozen['input_hashes'])
    validate_hashes(frozen['executable_source_hashes'])
    preservation_path = ROOT/frozen['historical_preservation_path']
    if sha256(preservation_path) != frozen['historical_preservation_sha256']:
        raise ValueError('Historical preservation inventory changed')
    preservation = json.loads(preservation_path.read_text())
    validate_hashes(preservation)
    atomic_json(output/'historical_preservation_after.json', {
        'status': 'PASS', 'files_verified_unchanged': len(preservation),
        'before_inventory_path': relative(preservation_path),
        'before_inventory_sha256': sha256(preservation_path),
        'scope': 'Prior processed datasets, learned artifacts, results, main numerical/embedding/review code and notebooks; separately declared raw sources also hash-checked'})
    artifact_dir = ROOT/computation['artifact_directory']
    artifact_paths = list(artifact_dir.rglob('*'))
    encoder_paths = set()
    for feature_path in artifact_dir.rglob('feature_manifest.json'):
        feature = json.loads(feature_path.read_text())
        encoder_paths.update([ROOT/feature['encoder_path'], ROOT/feature['encoder_receipt_path']])
    result_paths = list(output.rglob('*')) + [RESULTS/'RESULTS.md', RESULTS/'synthetic_tests.json', preservation_path]
    method_paths = [p for p in METHODOLOGY.iterdir() if p.is_file()]
    files = sorted(set(p for p in artifact_paths+list(encoder_paths)+result_paths+method_paths if p.is_file()))
    manifest = {'status': 'completed_verified_retrospective_comparison',
                'dataset_manifest': frozen['dataset_manifest_path'],
                'dataset_manifest_sha256': frozen['dataset_manifest_sha256'],
                'frozen_protocol': relative(METHODOLOGY/'frozen_protocol.json'),
                'frozen_protocol_sha256': sha256(METHODOLOGY/'frozen_protocol.json'),
                'run_directory': relative(output), 'artifact_directory': relative(artifact_dir),
                'input_and_source_hashes': frozen['input_hashes'],
                'executable_source_hashes': frozen['executable_source_hashes'],
                'actual_environment': computation['environment'],
                'commands': {'fit': computation['command'],
                             'freeze': ['.venv_thesis_data/bin/python', relative(CODE/'experiment.py'), 'freeze'],
                             'verify': ['.venv_thesis_data/bin/python', relative(CODE/'verify.py'), '--output', relative(output)],
                             'notebook': ['.venv_thesis_data/bin/python', relative(CODE/'deliver.py'), 'author', '--output', relative(output)],
                             'tests': tests['command']},
                'counts': {k: computation[k] for k in ['prediction_rows','learned_model_fits','evaluation_origins','encoder_fits','encoder_cache_hits','warning_count']},
                'cohorts': frozen['cohorts'], 'synthetic_tests': tests,
                'independent_verification': verification,
                'notebook_execution': notebook, 'visual_inspection': inspection,
                'all_actual_artifact_hashes': {relative(p): {'sha256': sha256(p), 'bytes': p.stat().st_size} for p in files},
                'total_hashed_artifacts': len(files),
                'elapsed_fitting_seconds': computation['elapsed_seconds'],
                'limitations': frozen['specification']['limitations'],
                'all_existing_historical_tests_previously_inspected': True,
                'real_time_release_certified': False, 'untouched_test_claim': False,
                'causal_or_profitable_trading_claim': False,
                'clean_environment_retraining_claim': False,
                'earlier_results_preserved': True, 'external_upload_or_submission': False}
    manifest['prior_files_verified_unchanged'] = len(preservation)
    atomic_json(RESULTS/'run_manifest.json', manifest)
    print(f'Atomic verified manifest: {RESULTS/"run_manifest.json"}; {len(files)} hashed artifacts', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['author', 'publish'])
    parser.add_argument('--output', type=Path, default=RESULTS/'run_001')
    args = parser.parse_args()
    {'author': author, 'publish': publish}[args.command](args.output.resolve())
