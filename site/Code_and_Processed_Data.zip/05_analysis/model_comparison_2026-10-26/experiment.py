"""Freeze, run, verify and publish a bounded Refinitiv-only comparison.

No fitting or writing on import. Every real run requires the bound frozen
protocol; output and learned-artifact directories must be new.
"""
from __future__ import annotations

# Set before importing any numerical library; threadpoolctl also limits native pools.
import os
for _name in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
              'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ[_name] = '1'

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import ElasticNet, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from threadpoolctl import threadpool_limits

from data import ROOT, FEATURES, SECTORS, TARGETS, HORIZONS, load_snapshot, case_frame, grouped_splits
from metrics import metric_tables, paired_tables
from text_features import FeatureManager
from utils import (CODE, METHODOLOGY, RESULTS, ARTIFACTS, atomic_json, canonical_hash,
                   sha256, relative, source_hashes, validate_hashes, environment)
from utils import historical_preservation_hashes

MANIFEST = ROOT / '04_data/processed/refinitiv_only_2026-10-26/dataset_manifest.json'
PROTOCOL = METHODOLOGY / 'frozen_protocol.json'


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def freeze() -> None:
    if PROTOCOL.exists():
        raise FileExistsError('Protocol already frozen; previous bytes are preserved')
    snapshot = load_snapshot(MANIFEST)
    specification_path = METHODOLOGY / 'protocol_specification.json'
    specification = json.loads(specification_path.read_text())
    plans, cohorts = {}, {}
    for case, settings in specification['cohorts'].items():
        frame = case_frame(snapshot, case)
        plans[case] = grouped_splits(frame, settings['initial_training_events'])
        events = frame[['doc_id', 'event_date', 'sector_definition']].drop_duplicates()
        cohorts[case] = {'events': len(events), 'sector_rows': len(frame),
                         'first_event': events.event_date.min(), 'last_event': events.event_date.max(),
                         'event_records': events.to_dict('records'),
                         'counts_by_definition': events.groupby('sector_definition').size().to_dict(),
                         'evaluation_events': len(plans[case]),
                         'first_evaluation_date': plans[case][0]['event_date'],
                         'last_evaluation_date': plans[case][-1]['event_date']}
    frozen = {'status': 'frozen_before_any_real_fit', 'frozen_at_utc': utc_now(),
              'specification_path': relative(specification_path),
              'specification_sha256': sha256(specification_path),
              'specification': specification,
              'dataset_manifest_path': relative(MANIFEST),
              'dataset_manifest_sha256': sha256(MANIFEST),
              'input_hashes': snapshot.hashes,
              'executable_source_hashes': source_hashes(),
              'environment_at_freeze': environment(),
              'cohorts': cohorts, 'splits': plans,
              'old_models_or_results_reused': False,
              'all_existing_historical_tests_previously_inspected': True}
    preservation = historical_preservation_hashes()
    atomic_json(RESULTS/'historical_preservation_before.json', preservation)
    frozen['historical_preservation_path'] = relative(RESULTS/'historical_preservation_before.json')
    frozen['historical_preservation_sha256'] = sha256(RESULTS/'historical_preservation_before.json')
    frozen['historical_files_in_preservation_inventory'] = len(preservation)
    frozen['content_sha256'] = canonical_hash(frozen)
    atomic_json(PROTOCOL, frozen)
    readable = (METHODOLOGY / 'PROTOCOL.md').read_text()
    readable += '\n\n## Input/cohort binding frozen before fitting\n\n'
    readable += f"Frozen UTC: {frozen['frozen_at_utc']}. Dataset manifest SHA-256: `{frozen['dataset_manifest_sha256']}`. "
    readable += f"Protocol content fingerprint: `{frozen['content_sha256']}`. No fit preceded this binding.\n\n"
    for case, cohort in cohorts.items():
        readable += (f"- {case}: {cohort['events']} eligible announcements / {cohort['sector_rows']} sector rows; "
                     f"{cohort['first_event']}–{cohort['last_event']}; {cohort['evaluation_events']} expanding evaluation origins, "
                     f"{cohort['first_evaluation_date']}–{cohort['last_evaluation_date']}; definitions: "
                     f"{cohort['counts_by_definition']}.\n")
    readable += '\nExact eligible IDs, fold training IDs, cutoffs, all declared input/source hashes and installed package versions are in `frozen_protocol.json`. No chronological validation/search is performed because all configurations are fixed before fitting. The initial training schedules are 36 and 20 eligible complete announcements, respectively.\n'
    with (METHODOLOGY / 'FROZEN_PROTOCOL.md').open('x') as stream:
        stream.write(readable)
    print(json.dumps({'frozen_protocol': relative(PROTOCOL), 'cohorts': {k: {n: v for n, v in d.items() if n != 'event_records'} for k, d in cohorts.items()}}, indent=2))


def load_frozen() -> tuple[dict, object]:
    frozen = json.loads(PROTOCOL.read_text())
    copy = {k: v for k, v in frozen.items() if k != 'content_sha256'}
    if canonical_hash(copy) != frozen['content_sha256']:
        raise ValueError('Frozen protocol fingerprint changed')
    validate_hashes(frozen['input_hashes'])
    validate_hashes(frozen['executable_source_hashes'])
    if sha256(ROOT / frozen['specification_path']) != frozen['specification_sha256']:
        raise ValueError('Protocol specification changed after freezing')
    if environment()['packages'] != frozen['environment_at_freeze']['packages']:
        raise ValueError('Dependency versions differ from frozen environment')
    snapshot = load_snapshot(ROOT / frozen['dataset_manifest_path'])
    if snapshot.hashes != frozen['input_hashes']:
        raise ValueError('Declared dataset sources changed after freezing')
    for case, settings in frozen['specification']['cohorts'].items():
        current = grouped_splits(case_frame(snapshot, case), settings['initial_training_events'])
        if current != frozen['splits'][case]:
            raise ValueError('Actual grouped split plan differs from frozen protocol')
    return frozen, snapshot


def estimator(family: str, settings: dict):
    cls = {'ridge': Ridge, 'elastic_net': ElasticNet,
           'rbf_svr': SVR, 'random_forest': RandomForestRegressor}[family]
    return cls(**settings)


def run(output: Path, artifacts: Path) -> None:
    output, artifacts = output.resolve(), artifacts.resolve()
    if not output.is_relative_to(RESULTS.resolve()) or not artifacts.is_relative_to(ARTIFACTS.resolve()):
        raise ValueError('Run outputs must stay in the owned result/model directories')
    if output.exists() or artifacts.exists():
        raise FileExistsError('Refusing an existing result/artifact directory; use a new run name')
    frozen, snapshot = load_frozen()
    output.mkdir(parents=True, exist_ok=False)
    artifacts.mkdir(parents=True, exist_ok=False)
    settings = frozen['specification']
    run_spec = {'status': 'running', 'started_at_utc': utc_now(),
                'protocol_path': relative(PROTOCOL), 'protocol_sha256': sha256(PROTOCOL),
                'protocol_content_sha256': frozen['content_sha256'],
                'command': ['.venv_thesis_data/bin/python', relative(CODE / 'experiment.py'),
                            'run', '--output', relative(output), '--artifacts', relative(artifacts)],
                'artifact_directory': relative(artifacts), 'environment': environment(),
                'input_hashes': frozen['input_hashes'],
                'source_hashes': frozen['executable_source_hashes']}
    atomic_json(output / 'run_started.json', run_spec)
    features = FeatureManager(snapshot.corpus, settings['text'], frozen['input_hashes'],
                              ARTIFACTS / 'encoder_cache')
    predictions, coverage_rows, choice_rows, fold_audits = [], [], [], []
    warning_rows = []
    started = time.monotonic()
    with threadpool_limits(limits=1):
        for case, plans in frozen['splits'].items():
            frame = case_frame(snapshot, case)
            numeric_names = FEATURES + settings['cohorts'][case]['additional_numerical_features']
            for plan in plans:
                cutoff = plan['event_date']
                training = frame.loc[frame.doc_id.isin(plan['training_doc_ids'])]
                test = frame.loc[frame.doc_id.eq(plan['doc_id'])]
                fold_dir = artifacts / case / cutoff
                pcs, test_pcs, feature_metadata = features.fold(plan, fold_dir)
                coverage_rows.append({'case': case, 'doc_id': plan['doc_id'], 'event_date': cutoff,
                                      **feature_metadata['test_coverage'],
                                      'language_training_documents': feature_metadata['encoder_training_documents'],
                                      'vocabulary_size': feature_metadata['encoder_vocabulary_size'],
                                      'pca_variance_sum': sum(feature_metadata['pca_explained_variance_ratio'])})
                fold_audit = {'case': case, **plan, 'numeric_features': numeric_names,
                              'feature_manifest_path': relative(fold_dir / 'feature_manifest.json'),
                              'feature_manifest_sha256': sha256(fold_dir / 'feature_manifest.json'),
                              'encoder_training_last_date': feature_metadata['encoder_training_last_date'],
                              'pca_training_last_event': feature_metadata['pca_training_last_event']}
                for sector in SECTORS:
                    train_s = training.loc[training.sector.eq(sector)].set_index('doc_id').loc[plan['training_doc_ids']]
                    test_s = test.loc[test.sector.eq(sector)]
                    if len(test_s) != 1 or len(train_s) != plan['training_events']:
                        raise ValueError('Missing sector in grouped training/test cohort')
                    x_numeric = train_s[numeric_names].to_numpy(float)
                    xt_numeric = test_s[numeric_names].to_numpy(float)
                    matrices = {'numerical': (x_numeric, xt_numeric),
                                'text_added': (np.column_stack([x_numeric, pcs]), np.column_stack([xt_numeric, test_pcs]))}
                    scaled = {}
                    for variant, (x, xt) in matrices.items():
                        names = numeric_names + ([f'text_PC{i+1}' for i in range(4)] if variant == 'text_added' else [])
                        scaler = StandardScaler().fit(x)
                        scaled[variant] = (scaler.transform(x), scaler.transform(xt), names)
                        joblib.dump(scaler, fold_dir / f'{sector}_{variant}_scaler.joblib', compress=3)
                        np.savez_compressed(fold_dir / f'{sector}_{variant}_predictors.npz',
                                            training_raw=x, test_raw=xt,
                                            training_scaled=scaled[variant][0], test_scaled=scaled[variant][1])
                    for horizon in HORIZONS:
                        y = train_s[TARGETS[horizon]].to_numpy(float)
                        actual = float(test_s[TARGETS[horizon]].iloc[0])
                        mean = float(y.mean())
                        up, down = int((y > 0).sum()), int((y < 0).sum())
                        common = {'case': case, 'fold': plan['fold'], 'doc_id': plan['doc_id'],
                                  'event_date': cutoff, 'sector': sector, 'horizon': horizon,
                                  'sector_definition': test_s.sector_definition.iloc[0],
                                  'actual_pp': actual, 'historical_mean_pp': mean,
                                  'training_events': len(y), 'training_up': up, 'training_down': down,
                                  'training_flat': int((y == 0).sum()),
                                  'training_majority_sign': 1 if up >= down else -1,
                                  'training_cohort_sha256': canonical_hash(plan['training_doc_ids']),
                                  'last_training_label_end': plan['last_training_label_end'],
                                  'preceding_session_date': test_s.preceding_session_date.iloc[0],
                                  'first_session_date': test_s.first_session_date.iloc[0],
                                  'second_session_date': test_s.second_session_date.iloc[0],
                                  'target_label_end': test_s.first_session_date.iloc[0] if horizon == 'first_session' else test_s.second_session_date.iloc[0],
                                  'retrospective_release_clock_unverified': True,
                                  'fold_artifact_directory': relative(fold_dir)}
                        for family, value in [('historical_mean', mean), ('zero_return', 0.0)]:
                            predictions.append({**common, 'family': family, 'variant': 'reference',
                                                'prediction_pp': value, 'model_artifact_path': ''})
                        for family, candidate in settings['models'].items():
                            for variant, (x, xt, names) in scaled.items():
                                model = estimator(family, candidate)
                                with warnings.catch_warnings(record=True) as caught:
                                    warnings.simplefilter('always')
                                    model.fit(x, y)
                                for warning in caught:
                                    warning_rows.append({'case': case, 'event_date': cutoff,
                                                         'sector': sector, 'horizon': horizon,
                                                         'family': family, 'variant': variant,
                                                         'category': warning.category.__name__,
                                                         'message': str(warning.message)})
                                    if issubclass(warning.category, ConvergenceWarning):
                                        raise ValueError(f'Candidate did not converge: {warning.message}')
                                prediction = float(model.predict(xt)[0])
                                if not np.isfinite(prediction):
                                    raise ValueError('Nonfinite learned prediction')
                                model_path = fold_dir / f'{sector}_{horizon}_{family}_{variant}.joblib'
                                joblib.dump(model, model_path, compress=3)
                                predictions.append({**common, 'family': family, 'variant': variant,
                                                    'prediction_pp': prediction,
                                                    'model_artifact_path': relative(model_path)})
                                choice_rows.append({'case': case, 'event_date': cutoff, 'sector': sector,
                                                    'horizon': horizon, 'family': family, 'variant': variant,
                                                    'settings_json': json.dumps(candidate, sort_keys=True),
                                                    'settings_sha256': canonical_hash(candidate),
                                                    'features_json': json.dumps(names),
                                                    'candidate_configurations': 1, 'search_fits': 0,
                                                    'training_events': len(y),
                                                    'training_cohort_sha256': common['training_cohort_sha256'],
                                                    'model_path': relative(model_path),
                                                    'model_sha256': sha256(model_path)})
                fold_audits.append(fold_audit)
                if plan['fold'] % 10 == 0 or plan['fold'] == len(plans):
                    print(f"{case}: {plan['fold']}/{len(plans)} announcement origins; elapsed {time.monotonic()-started:.1f}s", flush=True)
                    atomic_json(output / 'progress.json', {'case': case, 'completed_origins': len(fold_audits),
                                                         'predictions_so_far': len(predictions),
                                                         'elapsed_seconds': time.monotonic()-started,
                                                         'status': 'running_not_verified'}, replace=True)
    predictions = pd.DataFrame(predictions)
    if not np.isfinite(predictions[['actual_pp', 'prediction_pp', 'historical_mean_pp']].to_numpy()).all():
        raise ValueError('Nonfinite final predictions')
    predictions.to_csv(output / 'predictions.csv', index=False, float_format='%.17g')
    pd.DataFrame(choice_rows).to_csv(output / 'model_choices.csv', index=False)
    pd.DataFrame(coverage_rows).to_csv(output / 'text_coverage.csv', index=False)
    atomic_json(output / 'fold_audits.json', fold_audits)
    atomic_json(output / 'warnings.json', warning_rows)
    metrics, definition_metrics, direction = metric_tables(predictions)
    paired, paired_definition = paired_tables(predictions, settings['paired_comparison'])
    for name, table in [('metrics.csv', metrics), ('metrics_by_definition.csv', definition_metrics),
                        ('direction_baselines.csv', direction), ('paired_text_differences.csv', paired),
                        ('paired_text_differences_by_definition.csv', paired_definition)]:
        table.to_csv(output / name, index=False, float_format='%.17g')
    run_spec.update({'status': 'fitted_awaiting_independent_verification', 'finished_at_utc': utc_now(),
                     'elapsed_seconds': time.monotonic()-started, 'prediction_rows': len(predictions),
                     'learned_model_fits': len(choice_rows), 'evaluation_origins': len(fold_audits),
                     'encoder_fits': features.encoder_fits, 'encoder_cache_hits': features.encoder_hits,
                     'warning_count': len(warning_rows), 'cohorts': frozen['cohorts']})
    atomic_json(output / 'computation_manifest.json', run_spec)
    print(json.dumps({k: run_spec[k] for k in ['status', 'elapsed_seconds', 'prediction_rows', 'learned_model_fits', 'encoder_fits', 'encoder_cache_hits']}, indent=2), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('freeze')
    runner = sub.add_parser('run')
    runner.add_argument('--output', type=Path, default=RESULTS / 'run_001')
    runner.add_argument('--artifacts', type=Path, default=ARTIFACTS / 'run_001')
    args = parser.parse_args()
    if args.command == 'freeze':
        freeze()
    elif args.command == 'run':
        run(args.output, args.artifacts)


if __name__ == '__main__':
    main()
